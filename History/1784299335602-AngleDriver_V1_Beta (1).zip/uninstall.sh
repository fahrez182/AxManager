#!/bin/sh

# Remove Angle global settings
settings delete global angle_gl_driver_all_angle
settings delete global angle_gl_driver_selection_values
settings delete global angle_debug_package
settings delete global angle_gl_driver_selection_pkgs

# Reset properties to default/unset
unset_props() {
  setprop ro.zygote.disable_gl_preload 0
  setprop debug.hwui.renderer ""
  setprop debug.gpud.gl.renderer ""
  setprop debug.stagefright.renderengine.backend ""
  setprop debug.hwui.shadow.renderer ""
  setprop debug.renderengine.backend ""
  setprop debug.composition.type ""
  setprop debug.angle.rules ""
  setprop debug.angle.markers 0
  setprop debug.angle.capture.enabled 0
  setprop debug.angle.capture.out_dir ""
  setprop debug.angle.capture.frame_start 0
  setprop debug.angle.capture.label ""
  setprop debug.angle.capture.trigger 0
  setprop debug.angle.capture.frame_end 0
  setprop debug.angle.backend 0
  setprop debug.angle.enable_vulkan_api_dump_layer 0
  setprop debug.angle.validation 0
  setprop debug.gles.angle 0
  setprop debug.angle.overlay ""
  setprop debug.angle.feature_overrides_enabled ""
  setprop debug.angle.enabled 0
  setprop debug.angle.use-angle false
  setprop debug.angle.driver ""
  setprop debug.angle.translator ""
  setprop debug.angle.default_platform ""
  setprop debug.angle.vulkan 0
  setprop debug.angle.gles 0
  setprop debug.angle.force_angle 0
  setprop debug.angle.renderer ""
  setprop debug.angle.backend ""
  setprop debug.egl.angle ""
}
unset_props > /dev/null 2>&1

# Revoke WRITE_SECURE_SETTINGS permission
pm revoke com.android.angle android.permission.WRITE_SECURE_SETTINGS

pm uninstall com.android.angle

cmd notification post -S bigtext -t ' Angle Driver - Module' 'Tag' 'DELETE!!' > /dev/null 2>&1