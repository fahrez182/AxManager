#!/bin/sh
echo ""
echo "
─█▀▀█ ░█▄─░█ ░█▀▀█ ░█─── ░█▀▀▀ 
░█▄▄█ ░█░█░█ ░█─▄▄ ░█─── ░█▀▀▀ 
░█─░█ ░█──▀█ ░█▄▄█ ░█▄▄█ ░█▄▄▄"
echo ""
echo "
░█▀▀▄ ░█▀▀█ ▀█▀ ░█──░█ ░█▀▀▀ ░█▀▀█ 
░█─░█ ░█▄▄▀ ░█─ ─░█░█─ ░█▀▀▀ ░█▄▄▀ 
░█▄▄▀ ░█─░█ ▄█▄ ──▀▄▀─ ░█▄▄▄ ░█─░█ V1 Beta"
echo ""
sleep 2
sleep 0.5
echo " ▎DEVICE INFO 📱"
sleep 0.5
echo " ▎DEVICE = $(getprop ro.product.model)"
echo " ▎BRAND  = $(getprop ro.product.system.brand)"
echo " ▎MODEL  = $(getprop ro.build.product)"
echo " ▎KERNEL = $(uname -r)"
echo " ▎GPU    = $(getprop ro.hardware.egl)"
echo " ▎CPU    = $(getprop ro.hardware)"
echo " ▎ANDROID VERSION = $(getprop ro.build.version.release)"
echo " ( use at your own risk! don't comment if something is broken )"
sleep 2
echo ""
echo " ▶ Proces.........  "
echo ""
sleep 2
echo " ▶ Wait.....  "
echo ""
sleep 5

progress_list="
[■□□□□□□□□□]
[■■□□□□□□□□]
[■■■□□□□□□□]
[■■■■□□□□□□]
[■■■■■□□□□□]
[■■■■■■□□□□]
[■■■■■■■□□□]
[■■■■■■■■□□]
[■■■■■■■■■□]
[■■■■■■■■■■]
"

echo "$progress_list" | while IFS= read -r p; do
  echo " $p"
  sleep 1
done

sleep 0.5

echo " ▶ Installing Angle APK.....  "
echo ""
sleep 1

cp "$MODPATH/angle.apk" /data/local/tmp/angle.apk
rm -f "$MODPATH/angle.apk"
pm install -r -g /data/local/tmp/angle.apk
if [ $? -eq 0 ]; then
    echo " ▶ APK installed successfully"
else
    echo " ▶ APK install failed"
fi

echo ""
sleep 1

echo " ▶ Adding Settings.....  "
echo ""
sleep 2

# Enable Angle

settings put global angle_gl_driver_selection_values angle
settings put global angle_debug_package com.android.angle
settings put global angle_gl_driver_selection_pkgs android,com.android.phone,com.sh.smart.caller,com.transsion.smartpanel,com.transsion.microintelligence,by4a.setedit22,wk.lfxef,com.debug.loggerui,flar2.devcheck,ru.andr7e.deviceinfohw,net.bat.store,com.dts.freefireth,com.transsion.nephilim,com.android.systemui,com.dts.freefiremax,com.mobilelegends.mi,com.proximabeta.mf.uamo,com.proximabeta.mf.liteuamo,com.netease.newspike,com.activision.callofduty.warzone,com.garena.game.codm,com.carxtech.sr,com.miraclegames.farlight84,com.ea.gp.fifamobile,com.dts.freefireth,com.miHoYo.GenshinImpact,com.HoYoverse.hkrpgoversea,com.levelinfinite.sgameGlobal,com.tencent.iglite,com.tencent.ig,com.GlobalSoFunny.Sausage,com.netmarble.sololv,com.kurogame.wutheringwaves.global,com.blizzard.diablo.immortal,com.roblox.client,com.mobilelegends.hwag,com.AlfaBravo.CombatMaster,com.mobile.legends,com.ss.android.ugc.trill,com.mojang.minecraftpe,com.activision.callofduty.shooter,com.miHoYo.GenshinImpact

echo " ▶ Adding Props.....  "
echo ""
sleep 2

#Tweaks
tweak_angle() {
setprop ro.zygote.disable_gl_preload 1 
setprop ro.gfx.angle.supported true
setprop debug.hwui.renderer skiagl
setprop debug.gpud.gl.renderer skiagl
setprop debug.stagefright.renderengine.backend skiagl
setprop debug.hwui.shadow.renderer skiagl
setprop debug.renderengine.backend skiagl
setprop debug.composition.type gpu
setprop debug.angle.rules /data/local/tmp/a4a_rules.json
setprop debug.angle.markers 1 
setprop debug.angle.capture.enabled 1 
setprop debug.angle.capture.out_dir foo 
setprop debug.angle.capture.frame_start 0 
setprop debug.angle.capture.label bar 
setprop debug.angle.capture.trigger 20 
setprop debug.angle.capture.frame_end 200 
setprop debug.angle.backend 2 
setprop debug.angle.enable_vulkan_api_dump_layer 1 
setprop debug.angle.validation 1 
setprop debug.gles.angle 1 
setprop debug.angle.overlay FPS:Vulkan*PipelineCache*
setprop debug.angle.feature_overrides_enabled preferLinearFilterForYUV:mapUnspecifiedColorSpaceToPassThrough
setprop debug.angle.enabled 1
setprop debug.angle.use-angle true
setprop debug.angle.driver angle
setprop debug.angle.overlay 1
setprop debug.angle.translator gl
setprop debug.angle.default_platform vulkan
setprop debug.angle.vulkan 1
setprop debug.angle.gles 1
setprop debug.angle.force_angle 1
setprop debug.angle.renderer egl
setprop debug.angle.backend vulkan
setprop debug.egl.angle egl
}
tweak_angle > /dev/null 2>&1 

echo " ▶ Grant Permission For Angle.....  "
echo ""
pm grant com.android.angle android.permission.WRITE_SECURE_SETTINGS
sleep 2
rm -f /data/local/tmp/angle.apk
echo ""
sleep 1
sleep 2
echo ""
echo " ▶ Module Succesfully Flashed "
sleep 1
echo ""
cmd notification post -S bigtext -t '🚀 Angle Driver - Module' 'Tag' 'ACTIVATED!!' > /dev/null 2>&1
echo ""
echo " Done....... "
echo " Thanks For Using My Module! "
sleep 1
echo "Telegram: @opensourcemagiskmodule"
sleep 2
am start -a android.intent.action.VIEW -d "https://t.me/opensourcemagiskmodule" >/dev/null 2>&1
echo ""
