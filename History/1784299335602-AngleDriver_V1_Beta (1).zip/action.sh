#!/bin/sh
am start -n com.android.angle/com.android.angle.MainActivity