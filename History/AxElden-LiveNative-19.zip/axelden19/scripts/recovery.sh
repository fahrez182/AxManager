#!/system/bin/sh
ROOT="${AXELDEN_DIR:-${TMPDIR:-/data/local/tmp}/axelden-live}"
# Reset only AxElden runtime state; never touches game or Android system data.
rm -f "$ROOT/stop" "$ROOT/status.txt.tmp."* 2>/dev/null
[ -f "$ROOT/status.txt" ] && mv "$ROOT/status.txt" "$ROOT/status.previous" 2>/dev/null
 echo 'AxElden runtime state recovered; logs and user configuration preserved.'
