#!/system/bin/sh
ROOT="${AXELDEN_DIR:-${TMPDIR:-/data/local/tmp}/axelden-live}"
[ -r "$ROOT/status.txt" ] && cat "$ROOT/status.txt" || { echo 'AxElden: no status yet'; exit 1; }
