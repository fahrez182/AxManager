#!/system/bin/sh
DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
"$DIR/stop.sh"
sleep 1
"$DIR/service.sh"
