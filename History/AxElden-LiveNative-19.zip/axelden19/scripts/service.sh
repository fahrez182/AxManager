#!/system/bin/sh
# AxElden live, read-only Android monitor. No game-process access.
ROOT="${AXELDEN_DIR:-${TMPDIR:-/data/local/tmp}/axelden-live}"
INTERVAL="${AXELDEN_INTERVAL:-5}"
MIN_BATTERY="${AXELDEN_MIN_BATTERY:-15}"
mkdir -p "$ROOT" || exit 1
PIDFILE="$ROOT/service.pid"; LOG="$ROOT/service.log"; STATUS="$ROOT/status.txt"
[ -f "$PIDFILE" ] && old=$(cat "$PIDFILE" 2>/dev/null) && kill -0 "$old" 2>/dev/null && { echo "already-running pid=$old"; exit 0; }
rm -f "$ROOT/stop"
(
 echo $$ > "$PIDFILE"
 while [ ! -f "$ROOT/stop" ]; do
  ts=$(date '+%Y-%m-%dT%H:%M:%S' 2>/dev/null || date)
  battery=unknown
  for f in /sys/class/power_supply/battery/capacity /sys/class/power_supply/Battery/capacity; do [ -r "$f" ] && { battery=$(cat "$f" 2>/dev/null); break; }; done
  thermal=unknown
  for f in /sys/class/thermal/thermal_zone*/temp; do
   if [ -r "$f" ]; then thermal=$(cat "$f" 2>/dev/null); case "$thermal" in ''|*[!0-9]*) thermal=unknown;; esac; break; fi
  done
  load=$(cat /proc/loadavg 2>/dev/null || echo unknown)
  mem=$(awk '/MemAvailable/ {print $2" kB"}' /proc/meminfo 2>/dev/null)
  state=running; sleep_for=$INTERVAL
  case "$battery" in ''|*[!0-9]*) ;; *) [ "$battery" -lt "$MIN_BATTERY" ] && { state=paused-low-battery; sleep_for=30; };; esac
  case "$thermal" in unknown) ;; *) [ "$thermal" -ge 55000 ] && { state=throttled-hot; sleep_for=20; };; esac
  tmp="$STATUS.tmp.$$"
  { echo "timestamp=$ts"; echo "state=$state"; echo "battery_percent=$battery"; echo "thermal_raw=$thermal"; echo "loadavg=$load"; echo "mem_available=$mem"; echo "interval_seconds=$sleep_for"; } > "$tmp" && mv "$tmp" "$STATUS"
  echo "$ts state=$state battery=$battery thermal=$thermal load=$load" >> "$LOG"
  # Keep logs bounded to the latest 500 lines.
  if [ "$(wc -l < "$LOG" 2>/dev/null)" -gt 500 ]; then tail -n 500 "$LOG" > "$LOG.tmp" && mv "$LOG.tmp" "$LOG"; fi
  sleep "$sleep_for"
 done
 rm -f "$PIDFILE"
) >/dev/null 2>&1 &
echo "started pid=$! root=$ROOT"
