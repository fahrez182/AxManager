#!/system/bin/sh
ROOT="${AXELDEN_DIR:-${TMPDIR:-/data/local/tmp}/axelden-live}"
mkdir -p "$ROOT" && : > "$ROOT/stop" && echo 'stop requested'
