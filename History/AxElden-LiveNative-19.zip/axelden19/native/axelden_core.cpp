#include "axelden_core.h"
#include <algorithm>
#if defined(__ARM_NEON) || defined(__aarch64__)
#include <arm_neon.h>
#endif
extern "C" float axelden_smooth(float sample, float previous, float alpha) {
    alpha = std::clamp(alpha, 0.0f, 1.0f);
    return previous + alpha * (sample - previous);
}
extern "C" void axelden_batch_scale(const float* input, float* output, std::size_t count, float scale) {
    if (!input || !output) return;
#if defined(__ARM_NEON) || defined(__aarch64__)
    const float32x4_t factor = vdupq_n_f32(scale);
    std::size_t i = 0;
    for (; i + 4 <= count; i += 4) vst1q_f32(output + i, vmulq_f32(vld1q_f32(input + i), factor));
    for (; i < count; ++i) output[i] = input[i] * scale;
#else
    for (std::size_t i = 0; i < count; ++i) output[i] = input[i] * scale;
#endif
}
extern "C" const char* axelden_version() { return "AxElden LiveNative 19.0"; }
