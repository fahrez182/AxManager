#pragma once
#include <cstddef>
#ifdef __cplusplus
extern "C" {
#endif
float axelden_smooth(float sample, float previous, float alpha);
void axelden_batch_scale(const float* input, float* output, std::size_t count, float scale);
const char* axelden_version();
#ifdef __cplusplus
}
#endif
