# AxElden LiveNative 19.0

A real, long-running, read-only Android system monitor plus a small C++17 native utility library. It does not attach to, inject into, inspect, or modify any game process. It does not alter aiming, recoil, weapon behavior, FOV, anti-cheat, or game files.

## Shell runtime

Run with Android's `/system/bin/sh` in an environment where the selected runtime directory is writable:

```sh
sh scripts/service.sh
sh scripts/status.sh
sh scripts/stop.sh
sh scripts/restart.sh
sh scripts/recovery.sh
```

The monitor loops until stopped. It slows polling when battery is below `AXELDEN_MIN_BATTERY` (default 15%) or a readable thermal-zone value reaches 55,000 (typically millidegrees Celsius; device semantics vary). It only reads `/proc` and `/sys/class`; it never writes system thermal, CPU, GPU, NPU, or power controls. Sensor and thermal nodes may be unavailable without privileged access.

Optional environment variables: `AXELDEN_DIR`, `AXELDEN_INTERVAL` (default 5 seconds), `AXELDEN_MIN_BATTERY` (default 15).

## Native build

This folder is a standalone CMake library. Integrate its `native/` directory with the app's existing Android Gradle/CMake setup and build for `arm64-v8a`. Do not replace the project's whole CMakeLists; add the subdirectory or merge the target carefully.

## Important limits

The shell scripts are executable, but actual Android APK integration and on-device behavior have not been tested here. The C++ library must be built with Android NDK for device use. This project is not a game mod or game-process plugin.
