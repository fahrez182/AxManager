package frb.axeron.manager.core

import android.content.Context
import org.json.JSONObject
import java.io.File
import java.io.IOException

/**
 * Durable, bounded diagnostics output for AxManager's own monitoring pipeline.
 * Writes only app-private cache files; it does not collect identifiers or game data.
 */
class AxEldenDiagnosticsStore(context: Context) {
    private val directory = File(context.applicationContext.cacheDir, "axelden-diagnostics")
    private val latestFile = File(directory, "latest_snapshot.json")
    private val historyFile = File(directory, "history.jsonl")
    private val lock = Any()

    data class WriteResult(val latestPath: String, val historyPath: String, val timestampMs: Long)

    @Throws(IOException::class)
    fun record(snapshotJson: String): WriteResult = synchronized(lock) {
        val parsed = JSONObject(snapshotJson)
        if (!directory.exists() && !directory.mkdirs()) {
            throw IOException("Cannot create AxElden diagnostics directory")
        }
        val normalized = parsed.toString()
        atomicWrite(latestFile, normalized)
        historyFile.appendText(normalized + "\n", Charsets.UTF_8)
        trimHistory(maxBytes = 512 * 1024L, keepLines = 400)
        WriteResult(latestFile.absolutePath, historyFile.absolutePath,
            parsed.optLong("timestamp_ms", System.currentTimeMillis()))
    }

    fun latestFile(): File? = latestFile.takeIf { it.isFile && it.length() > 0L }
    fun historyFile(): File? = historyFile.takeIf { it.isFile && it.length() > 0L }

    private fun atomicWrite(target: File, content: String) {
        val temp = File(directory, target.name + ".tmp")
        temp.writeText(content, Charsets.UTF_8)
        if (target.exists() && !target.delete()) {
            temp.delete()
            throw IOException("Cannot replace ${target.name}")
        }
        if (!temp.renameTo(target)) {
            temp.copyTo(target, overwrite = true)
            temp.delete()
        }
    }

    private fun trimHistory(maxBytes: Long, keepLines: Int) {
        if (!historyFile.exists() || historyFile.length() <= maxBytes) return
        val lines = historyFile.readLines(Charsets.UTF_8).takeLast(keepLines)
        val temp = File(directory, "history.jsonl.tmp")
        temp.writeText(lines.joinToString(separator = "\n", postfix = if (lines.isEmpty()) "" else "\n"), Charsets.UTF_8)
        if (historyFile.delete()) temp.renameTo(historyFile) else temp.delete()
    }
}
