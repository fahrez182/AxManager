package frb.axeron.manager.core

import android.content.Context
import android.view.Window
import org.json.JSONObject
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Combines device telemetry and network state for an AxManager monitoring session.
 * Works while the user monitors either an offline or online game, but intentionally
 * does not inspect, hook, inject into, or change the game process.
 *
 * Hardened additions: idempotent lifecycle, callback isolation, and no stale
 * snapshots delivered after stop/close.
 */
class AxEldenGameSessionMonitor(context: Context) {
    data class SessionSnapshot(
        val mode: String,
        val network: AxEldenNetworkMonitor.Snapshot,
        val device: AxEldenMonitor.Result
    ) {
        fun toJson(): String = JSONObject().apply {
            put("schema_version", 1)
            put("timestamp_ms", device.timestampMs)
            put("session_mode", mode)
            put("network", JSONObject(network.toJson()))
            put("device", JSONObject(device.toJson()))
            put("game_process_access", false)
        }.toString()
    }

    private val network = AxEldenNetworkMonitor(context)
    private val device = AxEldenMonitor(context.applicationContext)
    private val active = AtomicBoolean(false)
    private val closed = AtomicBoolean(false)

    /** A fail-closed network gate for AxManager-owned API work. */
    fun maySendApiRequest(): Boolean = active.get() && !closed.get() && network.maySendApiRequest()

    /** Attach only AxManager's own Window if its UI frame timing is wanted. */
    fun attachAxManagerWindow(window: Window) {
        if (!closed.get()) device.attachOwnWindow(window)
    }

    /** Release the frame-metrics listener while AxManager is not visible. */
    fun detachAxManagerWindow() {
        if (!closed.get()) device.detachOwnWindow()
    }

    @Synchronized fun start(onSnapshot: (SessionSnapshot) -> Unit) {
        if (closed.get() || !active.compareAndSet(false, true)) return
        try {
            network.start()
            device.start metricsCallback@{ metrics ->
                if (!active.get() || closed.get()) return@metricsCallback
                val net = network.current()
                val mode = when (net.state) {
                    AxEldenNetworkMonitor.State.ONLINE -> "ONLINE_MONITORING"
                    AxEldenNetworkMonitor.State.OFFLINE -> "OFFLINE_MONITORING"
                    AxEldenNetworkMonitor.State.LOCAL_ONLY -> "LOCAL_NETWORK_MONITORING"
                    AxEldenNetworkMonitor.State.UNVALIDATED -> "NETWORK_UNVALIDATED_MONITORING"
                    AxEldenNetworkMonitor.State.UNKNOWN -> "NETWORK_UNKNOWN_MONITORING"
                }
                try { onSnapshot(SessionSnapshot(mode, net, metrics)) } catch (_: Exception) {
                    // Consumer/UI failures must not terminate the telemetry worker.
                }
            }
        } catch (e: RuntimeException) {
            active.set(false)
            network.stop()
            throw e
        }
    }

    @Synchronized fun stop() {
        active.set(false)
        device.stop()
        network.stop()
    }

    @Synchronized fun close() {
        if (!closed.compareAndSet(false, true)) return
        active.set(false)
        device.close()
        network.close()
    }
}
