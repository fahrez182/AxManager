# AxElden merged runtime — integration notes (v21)

This project combines the AxElden work from the earlier LiveNative, AI Monitor,
FrameMetrics, SecureRuntime, NetworkMonitor, GameSessionMonitor, and Hardened
iterations. Existing AxManager modules and legacy AxElden entry points are retained.

## Active entry point

`AxActivity` owns one `AxEldenGameSessionMonitor` for the visible activity lifecycle:

- `onStart`: attach frame metrics to AxManager's own `Window`, then start monitoring.
- `onStop`: stop scheduled sampling and detach the frame listener.
- `onDestroy`: close the monitor and its worker resources.

`AxEldenGameSessionMonitor` combines the device sample with read-only Android network
state. `maySendApiRequest()` is a fail-closed helper for optional AxManager-owned API
work: it is true only while the session is active and Android reports validated Internet.
It does not intercept or gate unrelated app/game network traffic.

## Included capabilities

- JNI/native read-only sampling of `/proc` and `/sys`: memory, CPU load delta, uptime,
  load average, battery and best-effort thermal sensor readings.
- Android thermal status and battery APIs as platform-level signals.
- Frame duration, average frame time, estimated FPS and jank percentage for
  **AxManager's own window only** (API 24+).
- Network state: validated online, offline, local-only, unvalidated, or unknown.
- Conservative hysteresis profiles (`BALANCED` / `PROTECT`) that adjust only
  AxManager's own optional sampling cadence.
- Idempotent start/stop/close, callback isolation, and bounded retry interval after
  sample failures.
- A structured JSON snapshot for every monitoring cycle, including explicit per-source
  availability flags (`source_status`) and a native sampler error field when JNI is
  unavailable.
- Persistent, bounded JSON output: `latest_snapshot.json` and `history.jsonl` are
  written under the app-private cache directory `cache/axelden-diagnostics/`.
- Full JSON is also emitted to Android Logcat under `AxEldenSession`; output file paths
  are logged under `AxEldenOutput`.

## Native libraries and compatibility

The CMake file retains the project's original native targets and both AxElden native
entry points (`axelden` and `axelden_monitor`). `AxEldenLiveNative` remains available
for compatibility and supplies legacy uptime/load/battery/thermal readings; the active
monitor uses `axelden_monitor` for its primary sample. `AxEldenSecureRuntime` remains
available as a standalone helper, but do not start it alongside the session monitor
unless a separate consumer specifically needs its additional callbacks.

The manifest includes `ACCESS_NETWORK_STATE`. No existing project files or modules were
removed by this merge.

## Boundaries

All monitoring is read-only and scoped to AxManager or documented Android APIs. This
implementation does not inject into, hook, inspect, patch, or control another process;
it does not alter online-game state or anti-cheat behavior. The FPS metric is not the FPS
of a separate game. Thermal-zone values are vendor-dependent and are treated as
best-effort telemetry, not calibrated measurements.

## Verification status

The archive structure, JNI symbol presence, source wiring, and native C++ source structure
were statically inspected. An Android Gradle/NDK build and on-device lifecycle, thermal,
network, and frame-metrics validation still require an Android SDK/NDK toolchain and a test
device; do not treat this archive as a verified APK. Sensors that Android or the device
vendor does not expose are marked `false` in `source_status` rather than fabricated.
