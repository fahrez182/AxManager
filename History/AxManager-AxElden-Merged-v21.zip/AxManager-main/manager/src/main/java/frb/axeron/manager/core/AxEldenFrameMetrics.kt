package frb.axeron.manager.core

import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.view.FrameMetrics
import android.view.Window
import androidx.annotation.RequiresApi
import java.io.Closeable
import java.util.ArrayDeque
import kotlin.math.roundToInt

/**
 * Measures frames rendered by AxManager's own Window only (API 24+).
 * It does not read or control FPS of other apps or games.
 */
@RequiresApi(Build.VERSION_CODES.N)
class AxEldenFrameMetrics(
    private val window: Window,
    private val onSample: (Sample) -> Unit,
    private val capacity: Int = 120
) : Closeable {

    data class Sample(
        val fps: Int,
        val averageFrameMs: Double,
        val jankPercent: Double,
        val displayRefreshHz: Float,
        val framesInWindow: Int
    )

    private val thread = HandlerThread("AxElden-FrameMetrics").apply { start() }
    private val handler = Handler(thread.looper)
    private val frameTimes = ArrayDeque<Pair<Long, Boolean>>(capacity.coerceAtLeast(30))
    private var totalFrameNs = 0L
    private var jankyFrames = 0
    private var attached = false

    private val listener = Window.OnFrameMetricsAvailableListener { _, metrics, _ ->
        val totalNs = metrics.getMetric(FrameMetrics.TOTAL_DURATION)
        if (totalNs <= 0L) return@OnFrameMetricsAvailableListener
        val refresh = window.decorView.display?.refreshRate ?: 0f
        val platformDeadlineNs = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            metrics.getMetric(FrameMetrics.DEADLINE)
        } else -1L
        val frameBudgetNs = if (platformDeadlineNs > 0L) platformDeadlineNs
            else if (refresh > 0f) (1_000_000_000.0 / refresh).toLong() else -1L
        val isJanky = frameBudgetNs > 0L && totalNs > frameBudgetNs
        if (frameTimes.size == capacity.coerceAtLeast(30)) {
            val old = frameTimes.removeFirst()
            totalFrameNs -= old.first
            if (old.second) jankyFrames--
        }
        frameTimes.addLast(totalNs to isJanky)
        totalFrameNs += totalNs
        if (isJanky) jankyFrames++

        val count = frameTimes.size
        if (count < 10) return@OnFrameMetricsAvailableListener
        val averageNs = totalFrameNs.toDouble() / count
        val fps = if (averageNs > 0.0) (1_000_000_000.0 / averageNs).roundToInt() else 0
        val jank = if (count > 0) (jankyFrames.coerceIn(0, count) * 100.0 / count) else 0.0
        try {
            onSample(Sample(fps, averageNs / 1_000_000.0, jank, refresh, count))
        } catch (_: Exception) {
            // A consumer callback must not break frame collection.
        }
    }

    fun start() {
        if (attached) return
        attached = true
        window.addOnFrameMetricsAvailableListener(listener, handler)
    }

    override fun close() {
        if (!attached) return
        attached = false
        try { window.removeOnFrameMetricsAvailableListener(listener) } catch (_: RuntimeException) { }
        thread.quitSafely()
    }
}
