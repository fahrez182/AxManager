package frb.axeron.manager

import android.os.Binder
import frb.axeron.manager.adb.OtgTargetMonitor
import android.os.Bundle
import android.os.Process
import frb.axeron.api.core.AxeronSettings
import androidx.core.os.BundleCompat
import frb.axeron.api.Axeron
import frb.axeron.ktx.workerHandler
import frb.axeron.provider.AxeronProvider
import frb.axeron.server.util.Logger
import frb.axeron.shared.ShizukuApiConstant.USER_SERVICE_ARG_PGID
import frb.axeron.shared.ShizukuApiConstant.USER_SERVICE_ARG_TOKEN
import moe.shizuku.api.BinderContainer
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException

class AxManagerProvider : AxeronProvider() {

    companion object {
        private const val EXTRA_BINDER = "moe.shizuku.privileged.api.intent.extra.BINDER"
        private const val METHOD_SEND_USER_SERVICE = "sendUserService"
        const val METHOD_GET_TCP_CONFIG = "getTcpConfig"
        const val KEY_TCP_MODE = "tcp_mode"
        const val KEY_TCP_PORT = "tcp_port"
        private val LOGGER = Logger("AxManagerProvider")
    }

    override fun call(method: String, arg: String?, extras: Bundle?): Bundle? {
        if (method == METHOD_GET_TCP_CONFIG) return tcpConfig()
        if (extras == null) return null
        return if (method == METHOD_SEND_USER_SERVICE) {
            LOGGER.d("sendUserService")
            try {
                extras.classLoader = BinderContainer::class.java.classLoader
                val token = extras.getString(USER_SERVICE_ARG_TOKEN) ?: return null
                val pgid = extras.getInt(USER_SERVICE_ARG_PGID)
                val binder = BundleCompat.getParcelable(extras, EXTRA_BINDER, BinderContainer::class.java)
                    ?.binder ?: return null
                val countDownLatch = CountDownLatch(1)
                var reply: Bundle? = Bundle()
                val listener = object : Axeron.OnBinderReceivedListener {
                    override fun onBinderReceived() {
                        try {
                            Axeron.attachUserService(binder, Bundle().apply {
                                putString(USER_SERVICE_ARG_TOKEN, token)
                                putInt(USER_SERVICE_ARG_PGID, pgid)
                            })
                            reply!!.putParcelable(EXTRA_BINDER,
                                BinderContainer(checkNotNull(Axeron.getShizukuService()) { "No Shizuku service" }.asBinder())
                            )
                        } catch (e: Throwable) {
                            LOGGER.e(e, "attachUserService $token")
                            reply = null
                        }
                        Axeron.removeBinderReceivedListener(this)
                        countDownLatch.countDown()
                    }
                }
                Axeron.addBinderReceivedListenerSticky(listener, workerHandler)
                try {
                    countDownLatch.await(5, TimeUnit.SECONDS)
                    reply
                } catch (e: TimeoutException) {
                    LOGGER.e(e, "Binder not received in 5s")
                    null
                }
            } catch (e: Throwable) {
                LOGGER.e(e, "sendUserService")
                null
            }
        } else {
            super.call(method, arg, extras)
        }
    }

    private fun tcpConfig(): Bundle? {
        val uid = Binder.getCallingUid()
        if (uid != Process.SHELL_UID && uid != Process.ROOT_UID) {
            OtgTargetMonitor.note("TCP mode was asked by uid $uid — refused (only adb shell may ask)")
            return null
        }
        OtgTargetMonitor.note(
            "The other phone read this phone's TCP mode: " +
                    "${if (AxeronSettings.getTcpMode()) "on" else "off"}, port ${AxeronSettings.getTcpPort()}"
        )
        return Bundle().apply {
            putBoolean(KEY_TCP_MODE, AxeronSettings.getTcpMode())
            putInt(KEY_TCP_PORT, AxeronSettings.getTcpPort())
        }
    }
}
