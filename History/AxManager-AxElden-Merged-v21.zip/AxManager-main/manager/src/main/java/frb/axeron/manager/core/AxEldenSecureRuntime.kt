package frb.axeron.manager.core

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.PowerManager
import androidx.annotation.RequiresApi
import java.io.Closeable
import java.util.concurrent.Executor
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Safe, read-only runtime monitor for AxManager itself.
 * It observes validated network state and Android thermal status. It does not
 * change connectivity, modify another app, or bypass any game's security.
 * Requires ACCESS_NETWORK_STATE in the app manifest.
 */
@RequiresApi(Build.VERSION_CODES.N)
class AxEldenSecureRuntime(
    context: Context,
    private val onState: (State) -> Unit
) : Closeable {

    data class State(
        val networkAvailable: Boolean = false,
        val internetValidated: Boolean = false,
        val thermalStatus: Int = PowerManager.THERMAL_STATUS_NONE,
        val apiRequestsAllowed: Boolean = false,
        val sampledAtMs: Long = System.currentTimeMillis()
    )

    private val appContext = context.applicationContext
    private val connectivity = appContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    private val power = appContext.getSystemService(Context.POWER_SERVICE) as PowerManager
    private val worker = HandlerThread("AxElden-SecureRuntime").apply { start() }
    private val handler = Handler(worker.looper)
    private val started = AtomicBoolean(false)
    @Volatile private var current = State()

    private val networkCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) = refreshNetwork()
        override fun onLost(network: Network) = refreshNetwork()
        override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) = refreshNetwork()
    }

    private val thermalCallback = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        PowerManager.OnThermalStatusChangedListener { status ->
            handler.post { publish(current.copy(thermalStatus = status)) }
        }
    } else null

    fun start() {
        if (!started.compareAndSet(false, true)) return
        try {
            connectivity.registerDefaultNetworkCallback(networkCallback)
        } catch (_: SecurityException) {
            started.set(false)
            publish(current.copy(networkAvailable = false, internetValidated = false))
            return
        } catch (_: RuntimeException) {
            started.set(false)
            publish(current.copy(networkAvailable = false, internetValidated = false))
            return
        }
        refreshNetwork()
        refreshThermal()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && thermalCallback != null) {
            power.addThermalStatusListener(Executor { command -> handler.post(command) }, thermalCallback)
        }
    }

    /** True only when Android reports an Internet-capable, validated network. */
    fun maySendApiRequest(): Boolean = started.get() && current.internetValidated

    fun state(): State = current

    private fun refreshNetwork() {
        try {
            val network = connectivity.activeNetwork
            val caps = network?.let(connectivity::getNetworkCapabilities)
            val hasInternet = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
            val validated = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) == true
            handler.post {
                publish(current.copy(
                    networkAvailable = network != null && hasInternet,
                    internetValidated = network != null && hasInternet && validated
                ))
            }
        } catch (_: SecurityException) {
            handler.post { publish(current.copy(networkAvailable = false, internetValidated = false)) }
        } catch (_: RuntimeException) {
            handler.post { publish(current.copy(networkAvailable = false, internetValidated = false)) }
        }
    }

    private fun refreshThermal() {
        val status = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            power.currentThermalStatus
        } else PowerManager.THERMAL_STATUS_NONE
        publish(current.copy(thermalStatus = status))
    }

    private fun publish(next: State) {
        val safe = next.copy(
            apiRequestsAllowed = started.get() && next.internetValidated,
            sampledAtMs = System.currentTimeMillis()
        )
        current = safe
        try { onState(safe) } catch (_: Exception) {
            // Consumer errors must not terminate the runtime monitor thread.
        }
    }

    override fun close() {
        if (!started.compareAndSet(true, false)) return
        try { connectivity.unregisterNetworkCallback(networkCallback) } catch (_: RuntimeException) { }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && thermalCallback != null) {
            try { power.removeThermalStatusListener(thermalCallback) } catch (_: RuntimeException) { }
        }
        worker.quitSafely()
    }
}
