package frb.axeron.manager.core

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.display.DisplayManager
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import android.view.Display
import android.view.Window
import android.view.WindowManager
import org.json.JSONObject
import java.io.Closeable
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/** Read-only telemetry and adaptive scheduling for AxManager itself. */
class AxEldenMonitor(context: Context) : Closeable {
    companion object { init { System.loadLibrary("axelden_monitor") } }

    private external fun nativeSample(): String
    private val appContext = context.applicationContext
    private val executor = Executors.newSingleThreadScheduledExecutor { r ->
        Thread(r, "AxElden-Monitor").apply { isDaemon = true }
    }
    @Volatile private var task: ScheduledFuture<*>? = null
    @Volatile private var frameMetrics: AxEldenFrameMetrics? = null
    @Volatile private var latestFrame: AxEldenFrameMetrics.Sample? = null
    private val closed = AtomicBoolean(false)
    @Volatile private var currentProfile = "BALANCED"
    private var severeSamples = 0
    private var coolSamples = 0

    data class Result(
        val timestampMs: Long,
        val uptimeSec: Long,
        val loadAverage1m: String,
        val memoryTotalMb: Long,
        val memoryAvailableMb: Long,
        val cpuBusyPercent: Double,
        val thermalC: Double?,
        val batteryPercent: Int?,
        val refreshRateHz: Float?,
        val appFps: Int?,
        val averageFrameMs: Double?,
        val jankPercent: Double?,
        val profile: String,
        val recommendedIntervalMs: Long,
        val actions: List<String>,
        val rawNative: String
    ) {
        fun toJson(): String = JSONObject().apply {
            put("timestamp_ms", timestampMs)
            put("uptime_seconds", uptimeSec)
            put("load_average_1m", loadAverage1m)
            put("memory_total_mb", memoryTotalMb)
            put("memory_available_mb", memoryAvailableMb)
            put("cpu_busy_percent", cpuBusyPercent)
            put("thermal_c", thermalC ?: JSONObject.NULL)
            put("battery_percent", batteryPercent ?: JSONObject.NULL)
            put("refresh_rate_hz", refreshRateHz ?: JSONObject.NULL)
            put("axmanager_app_fps", appFps ?: JSONObject.NULL)
            put("average_frame_ms", averageFrameMs ?: JSONObject.NULL)
            put("jank_percent", jankPercent ?: JSONObject.NULL)
            put("profile", profile)
            put("recommended_interval_ms", recommendedIntervalMs)
            put("actions", org.json.JSONArray(actions))
            put("raw_native", JSONObject(rawNative))
        }.toString()
    }

    /** Frame timing is attached only to AxManager's own Window. */
    @Synchronized fun attachOwnWindow(window: Window) {
        if (closed.get() || Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return
        frameMetrics?.close()
        latestFrame = null
        frameMetrics = try {
            AxEldenFrameMetrics(window, onSample = { latestFrame = it }).also { it.start() }
        } catch (_: RuntimeException) { null }
    }

    @Synchronized fun detachOwnWindow() {
        try { frameMetrics?.close() } catch (_: RuntimeException) { }
        frameMetrics = null
        latestFrame = null
    }

    fun sample(): Result {
        check(!closed.get()) { "AxEldenMonitor is closed" }
        val raw = nativeSample()
        val n = JSONObject(raw)
        // Combine the original LiveNative v20 JNI readings with the AI monitor sample.
        val legacy = try { AxEldenLiveNative.snapshot() } catch (_: Throwable) { null }
        val batteryIntent = appContext.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val battery = if (level >= 0 && scale > 0) (100 * level / scale).coerceIn(0, 100) else null
        val thermalStatus = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                (appContext.getSystemService(Context.POWER_SERVICE) as PowerManager).currentThermalStatus
            } else PowerManager.THERMAL_STATUS_NONE
        } catch (_: RuntimeException) { PowerManager.THERMAL_STATUS_NONE }
        val refresh = currentRefreshRate()
        val memTotal = n.optLong("mem_total_kb", -1L).takeIf { it > 0 }?.div(1024) ?: -1L
        val memAvail = n.optLong("mem_available_kb", -1L).takeIf { it >= 0 }?.div(1024) ?: -1L
        val cpu = n.optDouble("cpu_busy_percent", -1.0).takeIf { it in 0.0..100.0 } ?: -1.0
        val thermalC = n.optLong("thermal_milli_c", -1L)
            .takeIf { it in 1000..200000 }?.div(1000.0)
            ?: legacy?.thermalMaxMilliC?.takeIf { it in 1000..200000 }?.div(1000.0)
        val frame = latestFrame
        val actions = mutableListOf<String>()
        val hot = thermalStatus >= PowerManager.THERMAL_STATUS_SEVERE || (thermalC != null && thermalC >= 48.0)
        val memoryTight = memAvail > 0 && memTotal > 0 && memAvail * 100 / memTotal < 12
        val lowBattery = battery != null && battery <= 15
        if (hot || memoryTight || lowBattery || thermalStatus >= PowerManager.THERMAL_STATUS_CRITICAL) {
            severeSamples++
            coolSamples = 0
        } else {
            coolSamples++
            severeSamples = 0
        }
        if (severeSamples >= 2 && currentProfile != "PROTECT") {
            currentProfile = "PROTECT"
            actions += "Reduced optional AxManager monitoring work"
        } else if (coolSamples >= 5 && currentProfile != "BALANCED") {
            currentProfile = "BALANCED"
            actions += "Restored normal AxManager monitoring cadence"
        }
        if (cpu > 90.0) actions += "High system CPU load observed"
        if (thermalStatus >= PowerManager.THERMAL_STATUS_CRITICAL) actions += "Critical thermal state: optional work should pause"
        val interval = if (currentProfile == "PROTECT") 5000L else 1500L
        return Result(
            System.currentTimeMillis(), legacy?.uptimeSec ?: n.optLong("uptime_seconds", -1L),
            legacy?.load1 ?: "unknown", memTotal, memAvail, cpu, thermalC,
            battery ?: legacy?.batteryPercent?.takeIf { it in 0..100 }, refresh,
            frame?.fps, frame?.averageFrameMs, frame?.jankPercent,
            currentProfile, interval, actions, raw
        )
    }

    @Synchronized fun start(onResult: (Result) -> Unit) {
        if (closed.get() || task?.isDone == false) return
        scheduleNext(onResult, 0L)
    }

    @Synchronized private fun scheduleNext(onResult: (Result) -> Unit, delayMs: Long) {
        if (closed.get() || executor.isShutdown) return
        task = executor.schedule({
            val nextDelay = try {
                val result = sample()
                try { onResult(result) } catch (_: Exception) { }
                result.recommendedIntervalMs
            } catch (_: Exception) { 5000L }
            synchronized(this) {
                if (!closed.get() && task?.isCancelled == false) scheduleNext(onResult, nextDelay)
            }
        }, delayMs, TimeUnit.MILLISECONDS)
    }

    @Synchronized fun stop() {
        task?.cancel(true)
        task = null
    }

    override fun close() {
        if (!closed.compareAndSet(false, true)) return
        stop()
        detachOwnWindow()
        executor.shutdownNow()
    }

    private fun currentRefreshRate(): Float? = try {
        val dm = appContext.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        dm.getDisplay(Display.DEFAULT_DISPLAY)?.refreshRate?.takeIf { it > 0f }
    } catch (_: Exception) {
        try {
            val wm = appContext.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            @Suppress("DEPRECATION")
            wm.defaultDisplay.refreshRate.takeIf { it > 0f }
        } catch (_: Exception) { null }
    }
}
