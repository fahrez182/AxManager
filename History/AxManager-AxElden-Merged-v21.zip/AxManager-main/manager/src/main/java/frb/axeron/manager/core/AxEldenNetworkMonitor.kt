package frb.axeron.manager.core

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Build
import java.util.concurrent.CopyOnWriteArraySet

/**
 * Read-only connectivity monitor for AxManager's own networking decisions.
 * ONLINE means Android reports a validated Internet-capable default network;
 * it does not prove that a particular game server is reachable.
 *
 * Hardened additions: registration failure handling, API 21-23 fallback,
 * callback isolation, explicit unvalidated state, and safe refresh.
 */
class AxEldenNetworkMonitor(context: Context) {
    enum class State { ONLINE, LOCAL_ONLY, OFFLINE, UNKNOWN, UNVALIDATED }

    data class Snapshot(
        val state: State,
        val validatedInternet: Boolean,
        val wifi: Boolean,
        val cellular: Boolean,
        val metered: Boolean,
        val changedAtMs: Long
    ) {
        fun toJson(): String = org.json.JSONObject().apply {
            put("state", state.name)
            put("validated_internet", validatedInternet)
            put("wifi", wifi)
            put("cellular", cellular)
            put("metered", metered)
            put("changed_at_ms", changedAtMs)
        }.toString()
    }

    fun interface Listener { fun onChanged(snapshot: Snapshot) }

    private val appContext = context.applicationContext
    private val manager = appContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    private val listeners = CopyOnWriteArraySet<Listener>()
    @Volatile private var registered = false
    @Volatile private var snapshot = Snapshot(State.UNKNOWN, false, false, false, true, System.currentTimeMillis())

    private val callback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            // Wait for onCapabilitiesChanged; Android documents that callback ordering.
        }

        override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
            publish(snapshotFromCapabilities(caps))
        }

        override fun onLost(network: Network) {
            // A different default network may still be available; refresh from activeNetwork.
            publish(readCurrent())
        }

        override fun onUnavailable() {
            publish(Snapshot(State.OFFLINE, false, false, false, true, System.currentTimeMillis()))
        }
    }

    fun current(): Snapshot = snapshot

    /** API calls are permitted only when Android validates the active Internet route. */
    fun maySendApiRequest(): Boolean = snapshot.validatedInternet && snapshot.state == State.ONLINE

    /** Refreshes the snapshot without requiring a callback or restarting the monitor. */
    fun refresh(): Snapshot {
        val next = readCurrent()
        publish(next)
        return next
    }

    fun addListener(listener: Listener) {
        listeners += listener
        safelyNotify(listener, snapshot)
    }

    fun removeListener(listener: Listener) { listeners -= listener }

    @Synchronized fun start() {
        if (registered) return
        publish(readCurrent())
        try {
            if (Build.VERSION.SDK_INT >= 24) {
                manager.registerDefaultNetworkCallback(callback)
            } else {
                val request = NetworkRequest.Builder()
                    .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    .build()
                manager.registerNetworkCallback(request, callback)
            }
            registered = true
        } catch (_: SecurityException) {
            registered = false
            publish(snapshot.copy(state = State.UNKNOWN, changedAtMs = System.currentTimeMillis()))
        } catch (_: RuntimeException) {
            registered = false
            publish(snapshot.copy(state = State.UNKNOWN, changedAtMs = System.currentTimeMillis()))
        }
    }

    @Synchronized fun stop() {
        if (!registered) return
        try { manager.unregisterNetworkCallback(callback) } catch (_: IllegalArgumentException) {
            // Already unregistered by the platform; keep stop idempotent.
        } catch (_: SecurityException) {
            // Permission/state may have changed; local monitor state is still stopped.
        } finally {
            registered = false
        }
    }

    fun close() { stop(); listeners.clear() }

    private fun readCurrent(): Snapshot {
        return try {
            val network = manager.activeNetwork ?: return Snapshot(
                State.OFFLINE, false, false, false, true, System.currentTimeMillis()
            )
            val caps = manager.getNetworkCapabilities(network) ?: return Snapshot(
                State.UNKNOWN, false, false, false, true, System.currentTimeMillis()
            )
            snapshotFromCapabilities(caps)
        } catch (_: SecurityException) {
            Snapshot(State.UNKNOWN, false, false, false, true, System.currentTimeMillis())
        } catch (_: RuntimeException) {
            Snapshot(State.UNKNOWN, false, false, false, true, System.currentTimeMillis())
        }
    }

    private fun snapshotFromCapabilities(caps: NetworkCapabilities): Snapshot {
        val hasInternet = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        val validated = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
        val hasWifi = caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
        val hasCellular = caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)
        val state = when {
            validated -> State.ONLINE
            hasInternet -> State.UNVALIDATED
            hasWifi || hasCellular -> State.LOCAL_ONLY
            else -> State.LOCAL_ONLY
        }
        return Snapshot(
            state = state,
            validatedInternet = validated,
            wifi = hasWifi,
            cellular = hasCellular,
            metered = !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED),
            changedAtMs = System.currentTimeMillis()
        )
    }

    private fun publish(next: Snapshot) {
        snapshot = next
        listeners.forEach { listener -> safelyNotify(listener, next) }
    }

    private fun safelyNotify(listener: Listener, value: Snapshot) {
        try { listener.onChanged(value) } catch (_: Exception) {
            // One consumer must never break delivery to the remaining listeners.
        }
    }
}
