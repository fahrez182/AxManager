package frb.axeron.manager.core

/** Read-only device telemetry. This API does not inspect or modify other processes. */
object AxEldenLiveNative {
    init { System.loadLibrary("axelden") }
    @JvmStatic private external fun nativeSnapshot(): String
    @JvmStatic private external fun nativeMonotonicMillis(): Long

    data class Snapshot(
        val uptimeSec: Long, val ramTotalKb: Long, val ramAvailableKb: Long,
        val batteryPercent: Int, val thermalMaxMilliC: Long, val load1: String,
        val sampledAtMonotonicMs: Long
    )

    /** Returns a fresh sample from Android procfs/sysfs on every call. */
    @JvmStatic fun snapshot(): Snapshot {
        val raw = nativeSnapshot()
        fun long(key: String): Long = Regex("\\\"" + key + "\\\":(-?\\d+)").find(raw)?.groupValues?.get(1)?.toLongOrNull() ?: -1L
        val load = Regex("\\\"load1\\\":\\\"([^\\\"]*)\\\"").find(raw)?.groupValues?.get(1) ?: "unknown"
        return Snapshot(long("uptime_sec"), long("ram_total_kb"), long("ram_available_kb"),
            long("battery_percent").toInt(), long("thermal_max_mC"), load, nativeMonotonicMillis())
    }
}
