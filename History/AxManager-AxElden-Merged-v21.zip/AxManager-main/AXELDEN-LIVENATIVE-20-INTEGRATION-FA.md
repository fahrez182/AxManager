# AxElden LiveNative 20 — ادغام در AxManager

این بسته روی سورس AxManager ادغام شده است و کتابخانه `libaxelden.so` را با CMake می‌سازد.

## فایل‌های افزوده/تغییریافته
- `manager/src/main/cpp/axelden_live.cpp` — خواندن زنده و فقط‌خواندنی uptime، RAM، باتری، بیشینه دمای قابل‌خواندن و load average از procfs/sysfs.
- `manager/src/main/cpp/CMakeLists.txt` — افزودن هدف `axelden` و لینک کتابخانه‌های Android.
- `manager/src/main/java/frb/axeron/manager/core/AxEldenLiveNative.kt` — رابط JNI و مدل Snapshot.

## استفاده در کد Kotlin
```kotlin
val state = AxEldenLiveNative.snapshot()
// state.batteryPercent, state.ramAvailableKb, state.thermalMaxMilliC, state.load1
```
هر بار فراخوانی snapshot داده تازه می‌خواند. برای به‌روزرسانی UI، آن را از coroutine یا executor با فاصله منطقی (مثلاً 2 تا 5 ثانیه) فراخوانی کنید؛ روی Main thread اجرا نکنید.

## ساخت
از ریشه پروژه: `./gradlew :manager:assembleDebug`
نیازمند Android SDK/NDK و CMake نسخه سازگار با پروژه است. این محیط فاقد Android SDK/NDK و دستگاه فیزیکی برای build و runtime verification بود؛ بنابراین APK نهایی یا تست گوشی ادعا نمی‌شود.

## محدودیت‌ها
- فقط داده‌های عمومی سیستم‌عامل خوانده می‌شوند؛ دسترسی به فرایند بازی، حافظه بازی، hook/injection و دورزدن anti-cheat وجود ندارد.
- بعضی دستگاه‌ها مسیر یا مقیاس سنسور حرارتی را محدود/متفاوت می‌کنند؛ مقدار `-1` یعنی در دسترس نبودن.
- JNI به‌صورت lazy از Kotlin object بارگذاری می‌شود؛ از این API داخل اپ Manager استفاده کنید.
- این تغییر، سرویس foreground دائمی یا UI مستقل اضافه نمی‌کند؛ اجرای پس‌زمینه دائمی نیازمند طراحی جداگانه مطابق محدودیت‌های Android و مجوزهای پروژه است.
