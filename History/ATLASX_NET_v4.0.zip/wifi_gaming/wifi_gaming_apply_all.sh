#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='WIFIG-ALL'
arc_log_info "$TAG" '=== WiFi Gaming: ALL ==='
for s in wifi_gaming_scan_off wifi_gaming_sleep_off wifi_gaming_qos wifi_gaming_wakelock wifi_gaming_power_save_off wifi_gaming_tx_queue; do sh "$MODPATH/wifi_gaming/${s}.sh" 2>/dev/null; sleep 1; done
arc_log_info "$TAG" '=== WiFi Gaming: DONE ==='