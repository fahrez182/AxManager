#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='WIFIG-WL'
arc_exec "settings put global wifi_suspend_optimizations_enabled 0" 2>/dev/null
arc_log_info "$TAG" 'WiFi Gaming: wakelock ativo (sem suspend).'