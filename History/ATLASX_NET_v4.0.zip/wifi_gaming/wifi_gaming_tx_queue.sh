#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='WIFIG-TXQ'
arc_exec "sysctl -w net.core.netdev_max_backlog=5000" 2>/dev/null
arc_exec "sysctl -w net.core.dev_weight=64" 2>/dev/null
arc_log_info "$TAG" 'WiFi Gaming: TX queue otimizada.'