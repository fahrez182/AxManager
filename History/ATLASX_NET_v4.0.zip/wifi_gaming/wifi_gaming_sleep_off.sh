#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='WIFIG-SLP'
arc_exec "settings put system wifi_sleep_policy 2" 2>/dev/null
arc_exec "settings put global wifi_on 1" 2>/dev/null
arc_log_info "$TAG" 'WiFi Gaming: sleep desativado.'