#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='WIFIG-SCAN'
arc_exec "settings put global wifi_scan_always_available 0" 2>/dev/null
arc_exec "setprop wifi.supplicant_scan_interval 0" 2>/dev/null
arc_log_info "$TAG" 'WiFi Gaming: scan pausado.'