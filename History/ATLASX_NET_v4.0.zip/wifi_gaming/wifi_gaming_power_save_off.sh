#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='WIFIG-PS'
IFACE=$(cat "$MODPATH/data/active_iface.txt" 2>/dev/null||echo '')
[ -n "$IFACE" ] && iw dev "$IFACE" set power_save off 2>/dev/null
arc_log_info "$TAG" 'WiFi Gaming: power save OFF.'