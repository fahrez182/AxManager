#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='V6-ALL'
arc_log_info "$TAG" '=== IPv6 Suite: ALL ==='
for s in ipv6_core_optimizer ipv6_dns_optimizer ipv6_privacy_ext ipv6_fast_dad ipv6_mtu_optimizer ipv6_firewall; do sh "$MODPATH/ipv6/${s}.sh" 2>/dev/null; sleep 1; done
arc_log_info "$TAG" '=== IPv6 Suite: DONE ==='