#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='V6-PREF'
arc_exec "sysctl -w net.ipv6.conf.all.disable_ipv6=0" 2>/dev/null
arc_exec "setprop persist.sys.ipv6_prefer 0" 2>/dev/null
arc_log_info "$TAG" 'IPv6 prefer: IPv4-first (dual stack).'