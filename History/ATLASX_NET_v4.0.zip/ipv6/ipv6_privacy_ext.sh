#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='V6-PRIV'
arc_exec "sysctl -w net.ipv6.conf.all.use_tempaddr=2" 2>/dev/null
arc_exec "sysctl -w net.ipv6.conf.default.use_tempaddr=2" 2>/dev/null
arc_log_info "$TAG" 'IPv6 Privacy Extensions: enabled.'