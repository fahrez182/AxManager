#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='V6-DAD'
arc_exec "sysctl -w net.ipv6.conf.all.dad_transmits=1" 2>/dev/null
arc_log_info "$TAG" 'IPv6 DAD: 1 transmit.'