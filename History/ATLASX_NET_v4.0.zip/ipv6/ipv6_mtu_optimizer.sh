#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='V6-MTU'
arc_exec "sysctl -w net.ipv6.conf.all.accept_ra_defrtr=1" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_mtu_probing=1" 2>/dev/null
arc_log_info "$TAG" 'IPv6 MTU: probing enabled.'