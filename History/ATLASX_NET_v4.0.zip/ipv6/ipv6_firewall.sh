#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='V6-FW'
arc_exec "sysctl -w net.ipv6.conf.all.accept_redirects=0" 2>/dev/null
arc_exec "sysctl -w net.ipv6.conf.all.accept_source_route=0" 2>/dev/null
arc_log_info "$TAG" 'IPv6 Firewall: redirects blocked.'