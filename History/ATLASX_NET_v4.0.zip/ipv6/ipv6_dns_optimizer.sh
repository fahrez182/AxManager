#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='V6-DNS'
arc_exec "setprop net.dns6.1 2606:4700:4700::1111" 2>/dev/null
arc_exec "setprop net.dns6.2 2001:4860:4860::8888" 2>/dev/null
arc_log_info "$TAG" 'IPv6 DNS: CF+Google.'