#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='WIFI-WPA3'
arc_exec "settings put global wifi_wpa3_h2e 1" 2>/dev/null
arc_log_info "$TAG" 'WiFi WPA3 H2E: habilitado.'