#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='WIFIADV-ALL'
arc_log_info "$TAG" '=== WiFi Advanced: ALL ==='
for s in wifi_wpa_optimizer wifi_5ghz_force wifi_beacon_optimizer wifi_driver_optimizer wifi_antenna_diversity wifi_wpa3_support; do sh "$MODPATH/wifi_advanced/${s}.sh" 2>/dev/null; sleep 1; done
arc_log_info "$TAG" '=== WiFi Advanced: DONE ==='