#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='WIFI-TX'
IFACE=$(cat "$MODPATH/data/active_iface.txt" 2>/dev/null||echo '')
[ -n "$IFACE" ] && iwconfig "$IFACE" txpower auto 2>/dev/null
arc_log_info "$TAG" "WiFi TX power: $IFACE auto."