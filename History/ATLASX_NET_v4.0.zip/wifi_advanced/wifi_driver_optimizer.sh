#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='WIFI-DRV'
for MOD in /sys/module/wlan/parameters /sys/module/bcmdhd/parameters; do
    [ -d "$MOD" ] && echo 1 > "$MOD/tx_queue_len" 2>/dev/null
done
arc_log_info "$TAG" 'WiFi driver: otimizado.'