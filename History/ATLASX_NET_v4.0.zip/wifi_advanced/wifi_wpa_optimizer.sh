#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='WIFI-WPA'
arc_exec "setprop wifi.supplicant.scan.interval 300" 2>/dev/null
arc_exec "settings put global wifi_enhanced_auto_join 1" 2>/dev/null
arc_log_info "$TAG" 'WPA Supplicant: otimizado.'