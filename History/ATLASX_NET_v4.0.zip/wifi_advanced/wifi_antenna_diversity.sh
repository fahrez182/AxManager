#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='WIFI-ANT'
arc_exec "setprop wifi.antenna.diversity 1" 2>/dev/null
arc_log_info "$TAG" 'WiFi antenna diversity: ativo.'