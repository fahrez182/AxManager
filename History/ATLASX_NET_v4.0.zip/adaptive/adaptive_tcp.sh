#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='ADPT-TCP'
STATE=$(cat "$MODPATH/data/current_state.txt" 2>/dev/null||echo BROWSING)
[ "$STATE" = "GAMING" ] && { sh "$MODPATH/tcp_gaming/tcp_gaming_apply_all.sh" 2>/dev/null; exit 0; }
[ "$STATE" = "STREAMING" ] && { sh "$MODPATH/tcp_streaming/tcp_streaming_apply_all.sh" 2>/dev/null; exit 0; }
sh "$MODPATH/tcp/tcp_apply_all.sh" 2>/dev/null
arc_log_info "$TAG" "Adaptive TCP: state=$STATE"