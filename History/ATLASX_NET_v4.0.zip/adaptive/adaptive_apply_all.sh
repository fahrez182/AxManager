#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='ADPT-ALL'
arc_log_info "$TAG" '=== Adaptive Engine: ALL ==='
sh "$MODPATH/adaptive/adaptive_engine.sh" 2>/dev/null; sleep 1
sh "$MODPATH/adaptive/adaptive_dns.sh" 2>/dev/null; sleep 1
sh "$MODPATH/adaptive/adaptive_battery.sh" 2>/dev/null; sleep 1
sh "$MODPATH/adaptive/adaptive_thermal.sh" 2>/dev/null
arc_log_info "$TAG" '=== Adaptive Engine: DONE ==='