#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='ADPT-ENG'
STATE=$(cat "$MODPATH/data/current_state.txt" 2>/dev/null||echo BROWSING)
NET_TYPE=$(cat "$MODPATH/data/net_type.txt" 2>/dev/null||echo UNKNOWN)
case "${STATE}_${NET_TYPE}" in
    GAMING_WIFI)    sh "$MODPATH/wifi_gaming/wifi_gaming_apply_all.sh" 2>/dev/null ;;
    GAMING_4G)      sh "$MODPATH/mobile_4g/4g_apply_all.sh" 2>/dev/null ;;
    GAMING_5G)      sh "$MODPATH/mobile_5g/5g_apply_all.sh" 2>/dev/null ;;
    STREAMING_WIFI) sh "$MODPATH/tcp_streaming/tcp_streaming_apply_all.sh" 2>/dev/null ;;
    VOIP_*)         sh "$MODPATH/voip/voip_apply_all.sh" 2>/dev/null ;;
    *)              sh "$MODPATH/profiles/browsing_profile.sh" 2>/dev/null ;;
esac
arc_log_info "$TAG" "Adaptive: state=$STATE type=$NET_TYPE"