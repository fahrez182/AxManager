#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='ADPT-THERM'
TEMP=$(cat /sys/class/thermal/thermal_zone0/temp 2>/dev/null||echo 40000)
TEMP_C=$(( TEMP / 1000 ))
[ "$TEMP_C" -gt 50 ] 2>/dev/null && {
    arc_log_warn "$TAG" "Thermal throttle: ${TEMP_C}C"
    arc_exec "sysctl -w net.core.netdev_max_backlog=1000" 2>/dev/null
} || {
    arc_exec "sysctl -w net.core.netdev_max_backlog=5000" 2>/dev/null
    arc_log_info "$TAG" "Thermal OK: ${TEMP_C}C"
}