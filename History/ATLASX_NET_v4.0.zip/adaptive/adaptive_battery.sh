#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='ADPT-BATT'
BAT=$(cat /sys/class/power_supply/battery/capacity 2>/dev/null||echo 100)
[ "$BAT" -lt 20 ] 2>/dev/null && {
    arc_log_info "$TAG" "Low battery ($BAT%) saving net"
    arc_exec "settings put global wifi_sleep_policy 0" 2>/dev/null
} || arc_log_info "$TAG" "Battery OK: ${BAT}%"