#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='ADPT-WIFI'
STATE=$(cat "$MODPATH/data/current_state.txt" 2>/dev/null||echo BROWSING)
[ "$STATE" = "GAMING" ] && sh "$MODPATH/wifi_gaming/wifi_gaming_apply_all.sh" 2>/dev/null || sh "$MODPATH/wifi/wifi_adaptive.sh" 2>/dev/null
arc_log_info "$TAG" "Adaptive WiFi: state=$STATE"