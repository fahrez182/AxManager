#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='ADPT-DNS'
SCORE=$(cat "$MODPATH/data/net_quality.txt" 2>/dev/null||echo GOOD)
case "$SCORE" in
    BAD)  sh "$MODPATH/dns_advanced/dns_failover.sh" 2>/dev/null ;;
    FAIR) sh "$MODPATH/dns_advanced/dns_auto_benchmark.sh" 2>/dev/null ;;
    GOOD) sh "$MODPATH/dns/dns_adaptive.sh" 2>/dev/null ;;
esac
arc_log_info "$TAG" "Adaptive DNS: score=$SCORE"