#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='ADPT-MOB'
sh "$MODPATH/mobile/mobile_adaptive.sh" 2>/dev/null
arc_log_info "$TAG" 'Adaptive Mobile: done.'