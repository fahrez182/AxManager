#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='ADPT-QOS'
sh "$MODPATH/qos/qos_adaptive.sh" 2>/dev/null
arc_log_info "$TAG" 'Adaptive QoS: done.'