#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='ADPT-TIME'
HOUR=$(date '+%H' 2>/dev/null||echo 12)
if [ "$HOUR" -ge 1 ] && [ "$HOUR" -lt 6 ] 2>/dev/null; then
    sh "$MODPATH/profiles/idle_profile.sh" 2>/dev/null
    arc_log_info "$TAG" "Night mode ${HOUR}h"
elif [ "$HOUR" -ge 20 ] 2>/dev/null; then
    sh "$MODPATH/streaming/streaming_apply_all.sh" 2>/dev/null
    arc_log_info "$TAG" "Evening mode ${HOUR}h"
else
    arc_log_info "$TAG" "Day mode ${HOUR}h"
fi