#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='PROF-CHARGE'
sh "$MODPATH/dns_advanced/dns_auto_benchmark.sh" 2>/dev/null
sh "$MODPATH/background/bg_prefetch_scheduler.sh" 2>/dev/null
arc_log_info "$TAG" 'Charging Profile: prefetch + benchmark.'