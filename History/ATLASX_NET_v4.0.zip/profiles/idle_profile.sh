#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='PROF-IDLE'
arc_log_info "$TAG" '=== Idle Profile: aplicando ==='
sh "$MODPATH/background/bg_doze_optimizer.sh"   2>/dev/null
sh "$MODPATH/qos/qos_idle_profile.sh"           2>/dev/null
sh "$MODPATH/background/bg_hog_killer.sh"       2>/dev/null
arc_log_info "$TAG" '=== Idle Profile: done ==='