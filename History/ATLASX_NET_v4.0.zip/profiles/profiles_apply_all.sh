#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='PROF-ALL'
arc_log_info "$TAG" '=== Profiles: boot defaults ==='
sh "$MODPATH/profiles/browsing_profile.sh" 2>/dev/null
arc_log_info "$TAG" '=== Profiles: done ==='