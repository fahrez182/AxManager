#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='PROF-GAME'
arc_log_info "$TAG" '=== Gaming Profile: aplicando ==='
sh "$MODPATH/tcp_gaming/tcp_gaming_apply_all.sh"    2>/dev/null
sh "$MODPATH/udp/udp_gaming_optimizer.sh"           2>/dev/null
sh "$MODPATH/dns/dns_gaming_servers.sh"             2>/dev/null
sh "$MODPATH/wifi_gaming/wifi_gaming_apply_all.sh"  2>/dev/null
sh "$MODPATH/qos/qos_gaming_profile.sh"             2>/dev/null
sh "$MODPATH/background/bg_hog_killer.sh"           2>/dev/null
arc_log_info "$TAG" '=== Gaming Profile: done ==='