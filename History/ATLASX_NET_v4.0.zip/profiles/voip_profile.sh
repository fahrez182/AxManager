#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='PROF-VOIP'
arc_log_info "$TAG" '=== VoIP Profile: aplicando ==='
sh "$MODPATH/voip/voip_apply_all.sh"   2>/dev/null
sh "$MODPATH/qos/qos_voip_profile.sh"  2>/dev/null
sh "$MODPATH/dns/dns_core_optimizer.sh" 2>/dev/null
arc_log_info "$TAG" '=== VoIP Profile: done ==='