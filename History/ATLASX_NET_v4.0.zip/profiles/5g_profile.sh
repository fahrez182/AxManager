#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='PROF-5G'
sh "$MODPATH/mobile_5g/5g_apply_all.sh" 2>/dev/null
sh "$MODPATH/tcp_streaming/tcp_streaming_apply_all.sh" 2>/dev/null
arc_log_info "$TAG" '5G Profile: done.'