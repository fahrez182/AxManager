#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='PROF-BROWSE'
arc_log_info "$TAG" '=== Browsing Profile: aplicando ==='
sh "$MODPATH/tcp/tcp_apply_all.sh"           2>/dev/null
sh "$MODPATH/dns/dns_apply_all.sh"           2>/dev/null
sh "$MODPATH/dns_advanced/dns_auto_benchmark.sh" 2>/dev/null
sh "$MODPATH/http/http_apply_all.sh"         2>/dev/null
sh "$MODPATH/qos/qos_balanced_profile.sh"   2>/dev/null
arc_log_info "$TAG" '=== Browsing Profile: done ==='