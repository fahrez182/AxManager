#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='PROF-4G'
sh "$MODPATH/mobile_4g/4g_apply_all.sh" 2>/dev/null
sh "$MODPATH/tcp/tcp_apply_all.sh" 2>/dev/null
arc_log_info "$TAG" '4G Profile: done.'