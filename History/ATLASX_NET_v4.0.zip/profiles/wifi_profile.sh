#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='PROF-WIFI'
sh "$MODPATH/wifi/wifi_apply_all.sh"          2>/dev/null
sh "$MODPATH/wifi_advanced/wifi_advanced_apply_all.sh" 2>/dev/null
arc_log_info "$TAG" 'WiFi Profile: done.'