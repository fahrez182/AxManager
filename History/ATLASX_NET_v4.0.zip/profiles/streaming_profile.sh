#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='PROF-STR'
arc_log_info "$TAG" '=== Streaming Profile: aplicando ==='
sh "$MODPATH/tcp_streaming/tcp_streaming_apply_all.sh" 2>/dev/null
sh "$MODPATH/streaming/streaming_apply_all.sh"          2>/dev/null
sh "$MODPATH/qos/qos_streaming_profile.sh"              2>/dev/null
sh "$MODPATH/dns/dns_streaming_servers.sh"              2>/dev/null
arc_log_info "$TAG" '=== Streaming Profile: done ==='