#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='PKT-LOSS'
arc_exec "sysctl -w net.ipv4.tcp_reordering=3" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_frto=2" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_sack=1" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_dsack=1" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_fack=1" 2>/dev/null
arc_log_info "$TAG" 'Packet loss reducer: SACK+DSACK+FRTO.'