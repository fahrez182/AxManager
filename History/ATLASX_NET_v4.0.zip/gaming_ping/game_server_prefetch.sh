#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='GAME-PREFETCH'
arc_log_info "$TAG" 'Prefetching game server IPs...'
for server in garena.com activision.com riot.games battlegroundsmobileindia.alpha epicgames.com; do
    nslookup "$server" 1.1.1.1 >/dev/null 2>&1 &
done
wait; arc_log_info "$TAG" 'Game server prefetch: done.'