#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='ANTI-LAG'
arc_exec "sysctl -w net.ipv4.tcp_low_latency=1" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_nodelay=1" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_autocorking=0" 2>/dev/null
IFACE=$(cat "$MODPATH/data/active_iface.txt" 2>/dev/null||echo "")
[ -n "$IFACE" ] && [ "$IFACE" != "unknown" ] && {
    tc qdisc del dev "$IFACE" root 2>/dev/null
    tc qdisc add dev "$IFACE" root pfifo_fast 2>/dev/null
}
arc_log_info "$TAG" 'Anti-Lag Network: aplicado.'