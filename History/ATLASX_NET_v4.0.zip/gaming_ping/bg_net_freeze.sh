#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='BG-FREEZE'
STATE=$(cat "$MODPATH/data/current_state.txt" 2>/dev/null||echo BROWSING)
[ "$STATE" != "GAMING" ] && exit 0
BG_APPS="com.facebook.katana com.instagram.android com.zhiliaoapp.musically"
for pkg in $BG_APPS; do
    arc_exec "am set-inactive $pkg true" 2>/dev/null
done
arc_log_info "$TAG" 'BG Net Freeze: apps suspensos durante gaming.'