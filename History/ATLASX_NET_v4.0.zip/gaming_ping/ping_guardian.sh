#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='PING-GUARD'
IFACE=$(cat "$MODPATH/data/active_iface.txt" 2>/dev/null||echo "")
GW=$(ip route show default 2>/dev/null | awk '{print $3}' | head -1)
[ -z "$GW" ] && arc_log_warn "$TAG" 'sem gateway' && exit 0
MS=$(ping -c 3 -W 2 "$GW" 2>/dev/null | awk -F'/' '/rtt/{print int($5)}')
[ -z "$MS" ] && MS=999
echo "$MS" > "$MODPATH/data/current_ping_ms.txt"
arc_log_info "$TAG" "Gateway ping: ${MS}ms"
[ "$MS" -gt 150 ] 2>/dev/null && sh "$MODPATH/gaming_ping/ping_optimizer_fast.sh" 2>/dev/null
