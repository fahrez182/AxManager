#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='GPING-ALL'
arc_log_info "$TAG" '=== Gaming Ping Suite: ALL ==='
for s in anti_lag_network gaming_dns_fast udp_game_priority packet_loss_reducer jitter_reducer game_conn_keeper game_server_prefetch bg_net_freeze; do
    sh "$MODPATH/gaming_ping/${s}.sh" 2>/dev/null; sleep 1
done
arc_log_info "$TAG" '=== Gaming Ping Suite: DONE ==='