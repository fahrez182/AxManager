#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='JITTER'
arc_exec "sysctl -w net.ipv4.tcp_thin_linear_timeouts=1" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_thin_dupack=1" 2>/dev/null
arc_exec "sysctl -w net.core.busy_read=100" 2>/dev/null
arc_log_info "$TAG" 'Jitter reducer: thin TCP + busy poll.'