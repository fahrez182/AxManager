#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='PING-FAST'
arc_exec "sysctl -w net.ipv4.tcp_low_latency=1" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_autocorking=0" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_thin_linear_timeouts=1" 2>/dev/null
arc_exec "sysctl -w net.core.busy_read=50" 2>/dev/null
arc_exec "sysctl -w net.core.busy_poll=50" 2>/dev/null
arc_log_info "$TAG" 'Ping Fast optimizer: aplicado.'