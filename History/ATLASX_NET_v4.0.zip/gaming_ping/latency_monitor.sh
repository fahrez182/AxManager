#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='LAT-MON'
INTERVAL=15; LATENCY_LOG="$MODPATH/logs/latency.log"; mkdir -p "$MODPATH/logs"
while true; do
    sleep "$INTERVAL"
    GW=$(ip route show default 2>/dev/null | awk '{print $3}' | head -1)
    [ -z "$GW" ] && continue
    MS=$(ping -c 3 -W 2 "$GW" 2>/dev/null | awk -F'/' '/rtt/{print int($5)}')
    [ -z "$MS" ] && continue
    echo "$(date '+%H:%M') ${MS}ms" >> "$LATENCY_LOG"
    tail -100 "$LATENCY_LOG" > "${LATENCY_LOG}.tmp" 2>/dev/null && mv "${LATENCY_LOG}.tmp" "$LATENCY_LOG" 2>/dev/null
done