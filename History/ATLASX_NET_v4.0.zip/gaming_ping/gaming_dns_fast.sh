#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='GAME-DNS'
arc_exec "setprop net.dns1 1.1.1.1" 2>/dev/null
arc_exec "setprop net.dns2 8.8.8.8" 2>/dev/null
arc_exec "settings put global private_dns_mode hostname" 2>/dev/null
arc_exec "settings put global private_dns_specifier 1dot1dot1dot1.cloudflare-dns.com" 2>/dev/null
arc_log_info "$TAG" 'Gaming DNS: Cloudflare (menor latência).'