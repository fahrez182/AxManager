#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='GAME-KEEP'
arc_exec "sysctl -w net.ipv4.tcp_keepalive_time=30" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_keepalive_intvl=5" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_keepalive_probes=9" 2>/dev/null
arc_log_info "$TAG" 'Game Connection Keeper: 30s/5s/9.'