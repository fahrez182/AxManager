#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='GAME-UDP-PRI'
IFACE=$(cat "$MODPATH/data/active_iface.txt" 2>/dev/null||echo "")
[ -z "$IFACE" ] || [ "$IFACE" = "unknown" ] && exit 0
tc qdisc del dev "$IFACE" root 2>/dev/null
tc qdisc add dev "$IFACE" root handle 1: prio priomap 1 1 1 1 0 0 0 0 1 1 1 1 1 1 1 1 2>/dev/null
tc filter add dev "$IFACE" parent 1: protocol ip u32 match ip protocol 17 0xff flowid 1:1 2>/dev/null
arc_log_info "$TAG" "UDP game priority: $IFACE"
