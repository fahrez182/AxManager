#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='4G-LTE'
arc_exec "settings put global preferred_network_mode 9" 2>/dev/null
arc_exec "settings put global lte_service_forced 1" 2>/dev/null
arc_log_info "$TAG" '4G LTE: forçado.'