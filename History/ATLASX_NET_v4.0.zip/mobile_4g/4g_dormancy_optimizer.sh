#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='4G-DORM'
arc_exec "setprop ril.fast.dormancy.rule 1" 2>/dev/null
arc_exec "setprop ril.fast.dormancy.timeout 1" 2>/dev/null
arc_log_info "$TAG" '4G Dormancy: fast dormancy ativo.'