#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='4G-SIG'
arc_exec "setprop ril.fast.dormancy.rule 1" 2>/dev/null
arc_exec "settings put global cell_scan_period 30" 2>/dev/null
arc_log_info "$TAG" '4G Signal: otimizado.'