#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='4G-BUF'
arc_exec "sysctl -w net.ipv4.tcp_rmem='4096 87380 8388608'" 2>/dev/null
arc_log_info "$TAG" '4G TCP buffers: otimizados.'