#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='4G-CA'
arc_exec "settings put global force_lte_ca 1" 2>/dev/null
arc_exec "setprop persist.vendor.radio.ca_dc_config 3" 2>/dev/null
arc_log_info "$TAG" '4G CA: ativo.'