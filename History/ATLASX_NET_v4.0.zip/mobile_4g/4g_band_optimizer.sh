#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='4G-BAND'
arc_exec "setprop persist.radio.lte_band_enable 1" 2>/dev/null
arc_log_info "$TAG" '4G Band optimizer: done.'