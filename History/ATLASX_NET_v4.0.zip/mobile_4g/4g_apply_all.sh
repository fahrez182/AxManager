#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='4G-ALL'
arc_log_info "$TAG" '=== 4G LTE Suite: ALL ==='
for s in 4g_lte_optimizer 4g_lte_ca 4g_volte_optimizer 4g_signal_optimizer 4g_buffer_optimizer 4g_dormancy_optimizer; do sh "$MODPATH/mobile_4g/${s}.sh" 2>/dev/null; sleep 1; done
arc_log_info "$TAG" '=== 4G LTE Suite: DONE ==='