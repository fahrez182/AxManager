#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='SMART-TCP'
AVAIL=$(cat /proc/sys/net/ipv4/tcp_available_congestion_control 2>/dev/null||echo cubic)
echo "$AVAIL" | grep -q bbr && ARC_CC=bbr || ARC_CC=cubic
arc_exec "sysctl -w net.ipv4.tcp_congestion_control=$ARC_CC" 2>/dev/null
arc_log_info "$TAG" "Smart TCP: cc=$ARC_CC"