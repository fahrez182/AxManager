#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='SMART-DNS'
sh "$MODPATH/dns_advanced/dns_auto_benchmark.sh" 2>/dev/null
BEST=$(cat "$MODPATH/data/best_dns.txt" 2>/dev/null||echo "1.1.1.1")
arc_exec "setprop net.dns1 $BEST" 2>/dev/null
arc_log_info "$TAG" "Smart DNS: melhor servidor=$BEST"