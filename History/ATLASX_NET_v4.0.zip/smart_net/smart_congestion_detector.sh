#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='SMART-CONG'
PING=$(cat "$MODPATH/data/current_ping_ms.txt" 2>/dev/null||echo 0)
[ "$PING" -gt 200 ] 2>/dev/null && {
    arc_log_warn "$TAG" "Congestion detectado: ${PING}ms"
    sh "$MODPATH/stability/net_drift_corrector.sh" 2>/dev/null
} || arc_log_info "$TAG" "Sem congestion: ${PING}ms"