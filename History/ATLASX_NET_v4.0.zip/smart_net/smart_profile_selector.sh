#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='SMART-PROF'
STATE=$(cat "$MODPATH/data/current_state.txt" 2>/dev/null||echo BROWSING)
NET=$(cat "$MODPATH/data/net_type.txt" 2>/dev/null||echo UNKNOWN)
arc_log_info "$TAG" "Smart Profile: state=$STATE net=$NET"
case "$STATE" in
    GAMING)    sh "$MODPATH/profiles/gaming_profile.sh" 2>/dev/null ;;
    STREAMING) sh "$MODPATH/profiles/streaming_profile.sh" 2>/dev/null ;;
    VOIP)      sh "$MODPATH/profiles/voip_profile.sh" 2>/dev/null ;;
    SCREEN_OFF) sh "$MODPATH/profiles/idle_profile.sh" 2>/dev/null ;;
    CHARGING)  sh "$MODPATH/profiles/charging_profile.sh" 2>/dev/null ;;
    *)         sh "$MODPATH/profiles/browsing_profile.sh" 2>/dev/null ;;
esac