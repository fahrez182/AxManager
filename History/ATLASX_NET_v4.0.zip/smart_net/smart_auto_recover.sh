#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='SMART-AUTORC'
ping -c 1 -W 3 1.1.1.1 >/dev/null 2>&1 || {
    arc_log_warn "$TAG" "No connectivity — auto recover"
    sh "$MODPATH/stability/connection_recovery_engine.sh" 2>/dev/null
}