#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='SMART-ALL'
arc_log_info "$TAG" '=== Smart Net: ALL ==='
sh "$MODPATH/smart_net/smart_profile_selector.sh" 2>/dev/null; sleep 1
sh "$MODPATH/smart_net/smart_dns_switcher.sh" 2>/dev/null; sleep 1
sh "$MODPATH/smart_net/smart_tcp_picker.sh" 2>/dev/null; sleep 1
sh "$MODPATH/smart_net/smart_auto_recover.sh" 2>/dev/null
arc_log_info "$TAG" '=== Smart Net: DONE ==='