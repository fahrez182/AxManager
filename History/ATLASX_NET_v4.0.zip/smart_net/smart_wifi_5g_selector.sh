#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='SMART-5G'
NET=$(cat "$MODPATH/data/net_type.txt" 2>/dev/null||echo UNKNOWN)
IFACE=$(cat "$MODPATH/data/active_iface.txt" 2>/dev/null||echo "")
[ "$NET" = "WIFI" ] && [ -n "$IFACE" ] && {
    iw dev "$IFACE" set power_save off 2>/dev/null
    arc_exec "settings put global wifi_frequency_band 2" 2>/dev/null
}
arc_log_info "$TAG" "Smart WiFi: power save off + 5GHz"