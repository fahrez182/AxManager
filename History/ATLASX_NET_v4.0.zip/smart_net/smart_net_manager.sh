#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='SMART-MGR'
sh "$MODPATH/adaptive/adaptive_engine.sh" 2>/dev/null
sh "$MODPATH/adaptive/adaptive_dns.sh" 2>/dev/null
sh "$MODPATH/adaptive/adaptive_qos.sh" 2>/dev/null
arc_log_info "$TAG" 'Smart Net Manager: ciclo completo done.'