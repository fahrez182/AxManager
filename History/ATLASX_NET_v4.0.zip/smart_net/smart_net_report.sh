#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='SMART-REP'
sh "$MODPATH/monitoring/net_report.sh" 2>/dev/null
sh "$MODPATH/analytics/net_analytics.sh" 2>/dev/null
arc_log_info "$TAG" 'Smart Net Report: done.'