#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='RADIO-PWR'
STATE=$(cat "$MODPATH/data/current_state.txt" 2>/dev/null||echo BROWSING)
case "$STATE" in
    GAMING|VOIP|STREAMING)
        arc_exec "setprop ril.radio.power.management 0" 2>/dev/null
        arc_log_info "$TAG" 'Radio Power: PERFORMANCE' ;;
    SCREEN_OFF)
        arc_exec "setprop ril.radio.power.management 1" 2>/dev/null
        arc_log_info "$TAG" 'Radio Power: SAVE' ;;
    *)
        arc_exec "setprop ril.radio.power.management 2" 2>/dev/null
        arc_log_info "$TAG" 'Radio Power: BALANCED' ;;
esac