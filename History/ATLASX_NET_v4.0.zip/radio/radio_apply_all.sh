#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='RADIO-ALL'
arc_log_info "$TAG" '=== Radio Suite: ALL ==='
for s in radio_signal_optimizer radio_band_lock radio_handoff_optimizer radio_network_mode_auto radio_volte_optimizer radio_antenna_optimizer radio_power_optimizer; do
    sh "$MODPATH/radio/${s}.sh" 2>/dev/null; sleep 1
done
arc_log_info "$TAG" '=== Radio Suite: DONE ==='