#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='RADIO-ANT'
arc_exec "setprop persist.radio.antenna.enable 1" 2>/dev/null
arc_exec "settings put global antenna_diversity 1" 2>/dev/null
arc_log_info "$TAG" 'Radio antenna diversity: ativo.'