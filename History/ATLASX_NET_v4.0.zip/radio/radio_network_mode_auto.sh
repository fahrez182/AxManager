#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='RADIO-AUTO'
arc_exec "settings put global preferred_network_mode 27" 2>/dev/null
arc_exec "setprop ril.preferred.rat 27" 2>/dev/null
arc_log_info "$TAG" 'Radio Mode: automático 5G/4G/3G.'