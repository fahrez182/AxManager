#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='RADIO-KEEP'
INTERVAL=30
arc_log_info "$TAG" 'Radio Keeper started'
while true; do
    sleep "$INTERVAL"
    STATE=$(cat "$MODPATH/data/current_state.txt" 2>/dev/null||echo BROWSING)
    [ "$STATE" = "SCREEN_OFF" ] && continue
    APN=$(arc_exec "settings get global data_roaming" 2>/dev/null || echo "")
    arc_exec "settings put global cell_on 1" 2>/dev/null
    arc_exec "setprop ril.current.rat 13" 2>/dev/null
    arc_log_info "$TAG" "Radio tick: state=$STATE"
done