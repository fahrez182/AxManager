#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='RADIO-BAND'
arc_exec "setprop persist.radio.lte_band_enable 1" 2>/dev/null
arc_exec "setprop persist.vendor.radio.rat_on NR:LTE:WCDMA:EDGE:GPRS" 2>/dev/null
arc_log_info "$TAG" 'Radio Band: 5G>4G>3G priorizados.'