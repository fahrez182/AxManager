#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='RADIO-ERR'
ping -c 1 -W 3 8.8.8.8 >/dev/null 2>&1 || {
    arc_log_warn "$TAG" 'Radio: sem conectividade — toggle'
    arc_exec "settings put global airplane_mode_on 1" 2>/dev/null; sleep 3
    arc_exec "settings put global airplane_mode_on 0" 2>/dev/null; sleep 5
    arc_exec "am broadcast -a android.intent.action.AIRPLANE_MODE --ez state false" 2>/dev/null
    arc_log_info "$TAG" 'Radio: toggle airplane concluído.'
}