#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='RADIO-HO'
arc_exec "settings put global wifi_to_mobile_handover 1" 2>/dev/null
arc_exec "settings put global mobile_data_always_on 1" 2>/dev/null
arc_exec "settings put global tcp_default_init_rwnd 60" 2>/dev/null
arc_log_info "$TAG" 'Radio Handoff: sem queda na troca WiFi/4G.'