#!/system/bin/sh
MODPATH="$(dirname "$0")/.."
echo "Reiniciando ATLASX NET..."
pkill -f "net_scheduler" 2>/dev/null
pkill -f "net_state_manager" 2>/dev/null
pkill -f "radio_keeper" 2>/dev/null
pkill -f "net_watchdog" 2>/dev/null
pkill -f "connection_keeper" 2>/dev/null
sleep 3
exec sh "$MODPATH/service.sh" &
echo "ATLASX NET reiniciado."
