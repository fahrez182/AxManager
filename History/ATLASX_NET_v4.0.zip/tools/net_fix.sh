#!/system/bin/sh
MODPATH="$(dirname "$0")/.."
echo "=== ATLASX NET — CORREÇÃO RÁPIDA ==="
. "$MODPATH/core/compat.sh"
sh "$MODPATH/stability/connection_recovery_engine.sh"
sh "$MODPATH/dns/dns_adaptive.sh"
sh "$MODPATH/stability/net_persistence_guard.sh"
sh "$MODPATH/monitoring/net_report.sh"
echo "=== Correção concluída ==="
