#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='MON-CONN'
INTERVAL=30
while true; do
    sleep "$INTERVAL"
    CONNS=$(cat /proc/net/tcp 2>/dev/null | wc -l || echo 0)
    echo "$CONNS" > "$MODPATH/data/active_connections.txt"
    arc_log_info "$TAG" "Active TCP connections: $CONNS"
done