#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='MON-LAT'
INTERVAL=20; LOG="$MODPATH/logs/latency_tracker.log"; mkdir -p "$MODPATH/logs"
while true; do sleep "$INTERVAL"
    MS=$(ping -c 2 -W 2 1.1.1.1 2>/dev/null | awk -F'/' '/rtt/{print int($5)}')
    [ -n "$MS" ] && echo "$(date '+%H:%M') ${MS}ms" >> "$LOG"
    tail -200 "$LOG" > "${LOG}.tmp" 2>/dev/null && mv "${LOG}.tmp" "$LOG" 2>/dev/null
done