#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='MON-HEALTH'
CF=$(ping -c 2 -W 2 1.1.1.1 2>/dev/null | awk -F'/' '/rtt/{print int($5)}' || echo 999)
GG=$(ping -c 2 -W 2 8.8.8.8 2>/dev/null | awk -F'/' '/rtt/{print int($5)}' || echo 999)
SCORE=$( [ "$CF" -lt 50 ] 2>/dev/null && echo "GOOD" || { [ "$CF" -lt 150 ] 2>/dev/null && echo "FAIR" || echo "BAD"; } )
echo "$SCORE" > "$MODPATH/data/net_quality.txt"
arc_log_info "$TAG" "Net health: CF=${CF}ms GG=${GG}ms QUALITY=$SCORE"
