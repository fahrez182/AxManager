#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='MON-ALL'
arc_log_info "$TAG" '=== Monitoring: ALL ==='
sh "$MODPATH/monitoring/net_health_check.sh" 2>/dev/null
sh "$MODPATH/monitoring/net_report.sh" 2>/dev/null
arc_log_info "$TAG" '=== Monitoring: DONE ==='