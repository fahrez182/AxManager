#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='MON-REP'
SCORE=$(cat "$MODPATH/data/net_quality.txt" 2>/dev/null||echo "?")
STATE=$(cat "$MODPATH/data/current_state.txt" 2>/dev/null||echo "?")
NET_TYPE=$(cat "$MODPATH/data/net_type.txt" 2>/dev/null||echo "?")
IFACE=$(cat "$MODPATH/data/active_iface.txt" 2>/dev/null||echo "?")
PING=$(cat "$MODPATH/data/current_ping_ms.txt" 2>/dev/null||echo "?")
arc_log_info "$TAG" "=== ATLASX NET REPORT ==="
arc_log_info "$TAG" "State: $STATE | Type: $NET_TYPE | Iface: $IFACE"
arc_log_info "$TAG" "Ping: ${PING}ms | Quality: $SCORE"
