#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='MON-DNS'
INTERVAL=120
while true; do
    sleep "$INTERVAL"
    DNS=$(getprop net.dns1 2>/dev/null || echo "?")
    DNS_TYPE=$(arc_exec "settings get global private_dns_mode" 2>/dev/null || echo "?")
    arc_log_info "$TAG" "DNS: $DNS | Mode: $DNS_TYPE"
done