#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='MON-IFACE'
PREV=""; INTERVAL=10
while true; do
    sleep "$INTERVAL"
    CURR=$(ip route show default 2>/dev/null | awk '{print $5}' | head -1)
    [ "$CURR" != "$PREV" ] && {
        arc_log_info "$TAG" "Interface change: $PREV→$CURR"
        echo "${CURR:-unknown}" > "$MODPATH/data/active_iface.txt"
        PREV="$CURR"
    }
done