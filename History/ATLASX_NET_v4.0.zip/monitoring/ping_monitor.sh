#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='MON-PING'
INTERVAL=30; LOG="$MODPATH/logs/ping_monitor.log"; mkdir -p "$MODPATH/logs"
arc_log_info "$TAG" 'Ping Monitor started'
while true; do
    sleep "$INTERVAL"
    GW=$(ip route show default 2>/dev/null | awk '{print $3}' | head -1)
    [ -z "$GW" ] && continue
    MS=$(ping -c 3 -W 2 "$GW" 2>/dev/null | awk -F'/' '/rtt/{print int($5)}')
    [ -n "$MS" ] && echo "$(date '+%H:%M') GW=${MS}ms" >> "$LOG"
    tail -200 "$LOG" > "${LOG}.tmp" 2>/dev/null && mv "${LOG}.tmp" "$LOG" 2>/dev/null
done