#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='MON-BW'
INTERVAL=60; LOG="$MODPATH/logs/bandwidth.log"; mkdir -p "$MODPATH/logs"
arc_log_info "$TAG" 'Bandwidth Monitor started'
while true; do
    sleep "$INTERVAL"
    IFACE=$(cat "$MODPATH/data/active_iface.txt" 2>/dev/null||echo "")
    [ -z "$IFACE" ] || [ "$IFACE" = "unknown" ] && continue
    RX=$(cat "/sys/class/net/$IFACE/statistics/rx_bytes" 2>/dev/null || echo 0)
    TX=$(cat "/sys/class/net/$IFACE/statistics/tx_bytes" 2>/dev/null || echo 0)
    echo "$(date '+%H:%M') rx=${RX} tx=${TX}" >> "$LOG"
    tail -200 "$LOG" > "${LOG}.tmp" 2>/dev/null && mv "${LOG}.tmp" "$LOG" 2>/dev/null
done