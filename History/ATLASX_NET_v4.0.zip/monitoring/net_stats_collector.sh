#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='MON-STATS'
mkdir -p "$MODPATH/logs"
IFACE=$(cat "$MODPATH/data/active_iface.txt" 2>/dev/null||echo "unknown")
RX=$(cat "/sys/class/net/$IFACE/statistics/rx_bytes" 2>/dev/null || echo 0)
TX=$(cat "/sys/class/net/$IFACE/statistics/tx_bytes" 2>/dev/null || echo 0)
PING=$(cat "$MODPATH/data/current_ping_ms.txt" 2>/dev/null || echo "?")
STATE=$(cat "$MODPATH/data/current_state.txt" 2>/dev/null || echo "?")
SCORE=$(cat "$MODPATH/data/net_quality.txt" 2>/dev/null || echo "?")
arc_log_info "$TAG" "IFACE=$IFACE RX=${RX}B TX=${TX}B PING=${PING}ms STATE=$STATE SCORE=$SCORE"
