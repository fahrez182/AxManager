#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='TCP-STR-MPATH'
arc_exec "sysctl -w net.mptcp.enabled=1" 2>/dev/null || arc_log_info "$TAG" 'MPTCP: não suportado (ok)'
arc_log_info "$TAG" 'Streaming multipath: checked.'