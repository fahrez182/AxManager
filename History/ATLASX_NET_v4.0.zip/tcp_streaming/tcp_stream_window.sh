#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='TCP-STR-WIN'
arc_exec "sysctl -w net.ipv4.tcp_window_scaling=1" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_adv_win_scale=2" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_app_win=31" 2>/dev/null
arc_log_info "$TAG" 'TCP window scaling: streaming.'