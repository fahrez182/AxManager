#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='TCP-STR-PRE'
arc_exec "sysctl -w net.ipv4.tcp_fastopen=3" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_slow_start_after_idle=0" 2>/dev/null
arc_log_info "$TAG" 'Streaming preconnect: done.'