#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='TCP-STR-NAG'
arc_exec "sysctl -w net.ipv4.tcp_autocorking=1" 2>/dev/null
arc_log_info "$TAG" 'Nagle/autocorking: streaming ON.'