#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='TCPS-ALL'
arc_log_info "$TAG" '=== TCP Streaming: ALL ==='
for s in tcp_stream_buffers tcp_stream_window tcp_stream_congestion tcp_stream_nagle tcp_stream_memory tcp_stream_preconnect; do sh "$MODPATH/tcp_streaming/${s}.sh" 2>/dev/null; sleep 1; done
arc_log_info "$TAG" '=== TCP Streaming: DONE ==='