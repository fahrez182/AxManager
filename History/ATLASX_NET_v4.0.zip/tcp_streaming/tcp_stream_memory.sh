#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='TCP-STR-MEM'
TOTAL=$(awk '/MemTotal/{print int($2)}' /proc/meminfo 2>/dev/null||echo 4194304)
arc_exec "sysctl -w net.ipv4.tcp_mem='$(($TOTAL/48)) $(($TOTAL/32)) $(($TOTAL/16))'" 2>/dev/null
arc_log_info "$TAG" 'TCP memory streaming: done.'