#!/system/bin/sh
  # @priority: CRITICAL
  # @category: SYSTEM
  # @interval: ONCE
  # @impact: LOW
  # ==============================================================================
  # ATLASX ARC - COMPAT LAYER (core/compat.sh)
  # Detecta runtime (ROOT / SHIZUKU / ADB) e fornece wrappers seguros.
  # SEMPRE faça source deste arquivo antes de qualquer operação privilegiada.
  # ==============================================================================

  ARC_RUNTIME="NONE"
  ARC_RISH_BIN=""
  ARC_SDK=$(getprop ro.build.version.sdk 2>/dev/null || echo "0")
  ARC_DEVICE_BRAND=$(getprop ro.product.brand 2>/dev/null | tr '[:upper:]' '[:lower:]')
  ARC_DEVICE_MODEL=$(getprop ro.product.model 2>/dev/null)
  ARC_SOC=$(getprop ro.soc.model 2>/dev/null || getprop ro.hardware.chipname 2>/dev/null || getprop ro.hardware 2>/dev/null || echo "unknown")

  _RISH_PATHS="
  /data/user/0/moe.shizuku.privileged.api/files/rish
  /data/user/0/moe.shizuku.privileged.api/rish
  /data/user_de/0/moe.shizuku.privileged.api/files/rish
  /data/local/tmp/rish
  /system/bin/rish
  "

  _detect_rish() {
      for p in $_RISH_PATHS; do
          if [ -x "$p" ]; then
              if "$p" -c "id" 2>/dev/null | grep -q "uid"; then
                  ARC_RISH_BIN="$p"; return 0
              fi
          fi
      done
      if command -v rish >/dev/null 2>&1; then
          local bin; bin=$(command -v rish)
          if "$bin" -c "id" 2>/dev/null | grep -q "uid"; then
              ARC_RISH_BIN="$bin"; return 0
          fi
      fi
      return 1
  }

  _detect_runtime() {
      if [ "$(id -u 2>/dev/null)" = "0" ]; then
          ARC_RUNTIME="ROOT"; return
      fi
      if su -c "id -u" 2>/dev/null | grep -q "^0$"; then
          ARC_RUNTIME="ROOT"; return
      fi
      if pm list packages 2>/dev/null | grep -q "moe.shizuku.privileged.api"; then
          if _detect_rish; then
              ARC_RUNTIME="SHIZUKU"; return
          fi
      fi
      ARC_RUNTIME="ADB"
  }

  _detect_runtime

  arc_exec() {
      local cmd="$*"
      case "$ARC_RUNTIME" in
          ROOT)    sh -c "$cmd" 2>/dev/null ;;
          SHIZUKU) "$ARC_RISH_BIN" -c "$cmd" 2>/dev/null ;;
          ADB)     sh -c "$cmd" 2>/dev/null ;;
      esac
  }

  arc_has_root() {
      [ "$ARC_RUNTIME" = "ROOT" ]
  }

  arc_has_shizuku() {
      [ "$ARC_RUNTIME" = "SHIZUKU" ] || [ "$ARC_RUNTIME" = "ROOT" ]
  }

  arc_write_sysfs() {
      local p="$1" v="$2"
      [ -z "$p" ] || [ -z "$v" ] && return 1
      if arc_has_root; then
          echo "$v" > "$p" 2>/dev/null && return 0
      fi
      return 1
  }

  arc_setprop() {
      local k="$1" v="$2"
      arc_exec "setprop $k '$v'"
  }

  arc_settings_put() {
      local ns="$1" k="$2" v="$3"
      arc_exec "settings put $ns $k $v"
  }

  arc_settings_get() {
      local ns="$1" k="$2"
      arc_exec "settings get $ns $k"
  }

  arc_device_config() {
      local ns="$1" k="$2" v="$3"
      arc_exec "device_config put $ns $k $v"
  }

  arc_device_config_get() {
      local ns="$1" k="$2"
      arc_exec "device_config get $ns $k"
  }

  arc_am() {
      arc_exec "am $*"
  }

  arc_pm() {
      arc_exec "pm $*"
  }

  arc_cmd() {
      arc_exec "cmd $*"
  }

  arc_is_xiaomi() {
      echo "$ARC_DEVICE_BRAND" | grep -qiE "xiaomi|redmi|poco"
  }

  arc_is_samsung() {
      echo "$ARC_DEVICE_BRAND" | grep -qi "samsung"
  }

  arc_is_snapdragon() {
      echo "$ARC_SOC" | grep -qiE "snapdragon|sm[0-9]|qcom"
  }

  arc_is_mediatek() {
      echo "$ARC_SOC" | grep -qiE "mediatek|mt[0-9]|dimensity|helio"
  }

  arc_is_exynos() {
      echo "$ARC_SOC" | grep -qi "exynos"
  }

  export ARC_RUNTIME ARC_RISH_BIN ARC_SDK ARC_DEVICE_BRAND ARC_DEVICE_MODEL ARC_SOC
  