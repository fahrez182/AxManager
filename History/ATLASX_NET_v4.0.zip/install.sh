#!/system/bin/sh
MODPATH="$(dirname "$0")"
echo "========================================"
echo "   ATLASX NET v4.0 — INSTALAÇÃO"
echo "   ADB | Shizuku | Root compatible"
echo "========================================"
. "$MODPATH/core/compat.sh"
echo "[ Runtime: $ARC_RUNTIME | SDK: $ARC_SDK ]"
for d in core runtime data logs locks pids analytics monitoring brands profiles adaptive smart_net; do
  mkdir -p "$MODPATH/$d"
done
find "$MODPATH" -name "*.sh" -exec chmod 755 {} \; 2>/dev/null
echo "BROWSE" > "$MODPATH/data/current_state.txt"
echo "UNKNOWN" > "$MODPATH/data/active_iface.txt"
echo "0" > "$MODPATH/data/net_score.txt"
echo ""
echo "[ ATLASX NET instalado com sucesso! ]"
echo "========================================"
