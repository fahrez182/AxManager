#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='KNET-ALL'
arc_log_info "$TAG" '=== Kernel Net Suite: ALL ==='
for s in kernel_net_core kernel_net_arp kernel_net_conntrack kernel_net_rp_filter kernel_net_tcp_mem kernel_net_napi kernel_net_ipv6; do sh "$MODPATH/kernel_net/${s}.sh" 2>/dev/null; sleep 1; done
arc_log_info "$TAG" '=== Kernel Net Suite: DONE ==='