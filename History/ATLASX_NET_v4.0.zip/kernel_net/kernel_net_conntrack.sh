#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='KNET-CT'
arc_exec "sysctl -w net.netfilter.nf_conntrack_max=65536" 2>/dev/null
arc_exec "sysctl -w net.netfilter.nf_conntrack_tcp_timeout_established=7440" 2>/dev/null
arc_exec "sysctl -w net.netfilter.nf_conntrack_udp_timeout=30" 2>/dev/null
arc_log_info "$TAG" 'Kernel conntrack: 65536/7440s.'