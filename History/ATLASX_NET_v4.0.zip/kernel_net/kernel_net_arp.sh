#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='KNET-ARP'
arc_exec "sysctl -w net.ipv4.neigh.default.gc_thresh1=128" 2>/dev/null
arc_exec "sysctl -w net.ipv4.neigh.default.gc_thresh2=512" 2>/dev/null
arc_exec "sysctl -w net.ipv4.neigh.default.gc_thresh3=1024" 2>/dev/null
arc_exec "sysctl -w net.ipv4.neigh.default.gc_stale_time=120" 2>/dev/null
arc_log_info "$TAG" 'Kernel ARP cache: otimizado.'