#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='KNET-MEM'
TOT=$(awk '/MemTotal/{print int($2)}' /proc/meminfo 2>/dev/null||echo 4194304)
arc_exec "sysctl -w net.ipv4.tcp_mem='$(($TOT/48)) $(($TOT/32)) $(($TOT/16))'" 2>/dev/null
arc_log_info "$TAG" 'Kernel TCP mem: calibrado.'