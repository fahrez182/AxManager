#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='KNET-NAPI'
arc_exec "sysctl -w net.core.netdev_budget=600" 2>/dev/null
arc_exec "sysctl -w net.core.netdev_budget_usecs=8000" 2>/dev/null
arc_log_info "$TAG" 'Kernel NAPI: budget=600 usecs=8000.'