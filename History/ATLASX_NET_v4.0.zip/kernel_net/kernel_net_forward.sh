#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='KNET-FWD'
arc_exec "sysctl -w net.ipv4.ip_forward=1" 2>/dev/null
arc_exec "sysctl -w net.ipv6.conf.all.forwarding=0" 2>/dev/null
arc_log_info "$TAG" 'Kernel IP forward: IPv4 on, IPv6 off.'