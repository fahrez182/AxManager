#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='KNET-IRQ'
for iface_irq in /proc/irq/*/affinity_hint; do
    [ -f "$iface_irq" ] && cat "$iface_irq" > "${iface_irq%affinity_hint}smp_affinity" 2>/dev/null
done
arc_log_info "$TAG" 'Kernel IRQ affinity: network balanceado.'