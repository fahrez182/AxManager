#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='KNET-RP'
arc_exec "sysctl -w net.ipv4.conf.all.rp_filter=1" 2>/dev/null
arc_exec "sysctl -w net.ipv4.conf.default.rp_filter=1" 2>/dev/null
arc_log_info "$TAG" 'Kernel RP filter: ativo (anti-spoofing).'