#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='KNET-CORE'
arc_exec "sysctl -w net.ipv4.route.gc_timeout=60" 2>/dev/null
arc_exec "sysctl -w net.ipv4.route.gc_interval=30" 2>/dev/null
arc_exec "sysctl -w net.ipv4.route.max_size=32768" 2>/dev/null
arc_exec "sysctl -w net.core.netdev_max_backlog=5000" 2>/dev/null
arc_log_info "$TAG" 'Kernel Net Core: route cache + backlog.'