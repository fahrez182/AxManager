#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='KNET-V6'
arc_exec "sysctl -w net.ipv6.conf.all.accept_ra=2" 2>/dev/null
arc_exec "sysctl -w net.ipv6.conf.default.accept_ra=2" 2>/dev/null
arc_exec "sysctl -w net.ipv6.conf.all.autoconf=1" 2>/dev/null
arc_log_info "$TAG" 'Kernel IPv6: SLAAC + RA enabled.'