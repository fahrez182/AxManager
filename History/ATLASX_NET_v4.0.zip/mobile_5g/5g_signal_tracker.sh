#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='5G-TRACK'
arc_exec "settings put global nr_signal_strength_improve 1" 2>/dev/null
arc_log_info "$TAG" '5G Signal tracker: ativo.'