#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='5G-ALL'
arc_log_info "$TAG" '=== 5G Suite: ALL ==='
for s in 5g_nsa_optimizer 5g_sa_optimizer 5g_throughput_booster 5g_latency_optimizer 5g_carrier_agg 5g_signal_tracker; do sh "$MODPATH/mobile_5g/${s}.sh" 2>/dev/null; sleep 1; done
arc_log_info "$TAG" '=== 5G Suite: DONE ==='