#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='5G-THRU'
arc_exec "sysctl -w net.ipv4.tcp_rmem='4096 131072 67108864'" 2>/dev/null
arc_exec "sysctl -w net.core.rmem_max=67108864" 2>/dev/null
arc_log_info "$TAG" '5G TCP buffers: máximos.'