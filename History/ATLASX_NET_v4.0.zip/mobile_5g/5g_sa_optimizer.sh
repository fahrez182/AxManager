#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='5G-SA'
arc_exec "setprop persist.radio.5g.sa.enable 1" 2>/dev/null
arc_exec "settings put global preferred_network_mode 33" 2>/dev/null
arc_log_info "$TAG" '5G SA: ativado.'