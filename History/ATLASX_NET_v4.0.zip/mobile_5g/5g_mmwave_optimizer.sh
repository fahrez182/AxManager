#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='5G-MM'
arc_exec "setprop persist.radio.5g.mmwave 1" 2>/dev/null
arc_log_info "$TAG" '5G mmWave: habilitado.'