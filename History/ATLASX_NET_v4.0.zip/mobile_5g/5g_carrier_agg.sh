#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='5G-CA'
arc_exec "settings put global force_5g_ca 1" 2>/dev/null
arc_exec "setprop persist.vendor.radio.ca_dc_config 5" 2>/dev/null
arc_log_info "$TAG" '5G CA: carrier aggregation máximo.'