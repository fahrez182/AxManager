#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='5G-NSA'
arc_exec "setprop persist.vendor.radio.enable_temp_dds 1" 2>/dev/null
arc_exec "settings put global preferred_network_mode 27" 2>/dev/null
arc_log_info "$TAG" '5G NSA: ativado.'