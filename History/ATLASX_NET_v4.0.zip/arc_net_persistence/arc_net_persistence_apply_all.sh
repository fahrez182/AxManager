#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='ARCPER-ALL'
arc_log_info "$TAG" '=== ARC Net Persistence: ALL ==='
for s in net_drift_daily net_config_backup net_sysctl_persist net_dns_persist net_wifi_persist net_mobile_persist; do
    sh "$MODPATH/arc_net_persistence/${s}.sh" 2>/dev/null; sleep 1
done
arc_log_info "$TAG" '=== ARC Net Persistence: DONE ==='