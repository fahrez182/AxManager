#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='ARC-MOB-P'
arc_exec "settings put global mobile_data_always_on 1" 2>/dev/null
arc_exec "settings put global cell_on 1" 2>/dev/null
arc_log_info "$TAG" 'Mobile persist: done.'