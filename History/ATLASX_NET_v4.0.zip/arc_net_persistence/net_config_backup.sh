#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='ARC-BCK'
CFG_FILE="$MODPATH/data/net_config_backup.txt"
mkdir -p "$MODPATH/data"
echo "dns1=$(getprop net.dns1 2>/dev/null)" > "$CFG_FILE"
echo "congestion=$(sysctl -n net.ipv4.tcp_congestion_control 2>/dev/null)" >> "$CFG_FILE"
echo "keepalive=$(sysctl -n net.ipv4.tcp_keepalive_time 2>/dev/null)" >> "$CFG_FILE"
arc_log_info "$TAG" 'Net config backed up.'