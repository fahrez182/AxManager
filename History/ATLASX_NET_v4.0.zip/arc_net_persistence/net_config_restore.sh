#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='ARC-RST'
CFG_FILE="$MODPATH/data/net_config_backup.txt"
[ -f "$CFG_FILE" ] || exit 0
while IFS='=' read -r KEY VAL; do
    case "$KEY" in
        dns1) arc_exec "setprop net.dns1 $VAL" 2>/dev/null ;;
        congestion) arc_exec "sysctl -w net.ipv4.tcp_congestion_control=$VAL" 2>/dev/null ;;
        keepalive) arc_exec "sysctl -w net.ipv4.tcp_keepalive_time=$VAL" 2>/dev/null ;;
    esac
done < "$CFG_FILE"
arc_log_info "$TAG" 'Net config restored.'