#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='ARC-DRIFT'
arc_log_info "$TAG" 'ARC Net Drift: diário'
sh "$MODPATH/stability/net_drift_corrector.sh" 2>/dev/null
sh "$MODPATH/stability/dns_stability_guard.sh" 2>/dev/null
sh "$MODPATH/stability/net_persistence_guard.sh" 2>/dev/null