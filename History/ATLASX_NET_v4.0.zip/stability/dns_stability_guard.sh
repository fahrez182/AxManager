#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='STAB-DNS'
DNS1=$(getprop net.dns1 2>/dev/null||echo "")
[ -z "$DNS1" ] || [ "$DNS1" = "127.0.0.1" ] && {
    arc_exec "setprop net.dns1 1.1.1.1" 2>/dev/null
    arc_exec "setprop net.dns2 8.8.8.8" 2>/dev/null
    arc_log_warn "$TAG" "DNS estabilizado: era $DNS1"
} || arc_log_info "$TAG" "DNS estavel: $DNS1"