#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='STAB-ALL'
arc_log_info "$TAG" '=== Stability Suite: ALL ==='
for s in net_drift_corrector net_persistence_guard dns_stability_guard wifi_stability_guard mobile_stability_guard net_session_recovery net_longevity; do
    sh "$MODPATH/stability/${s}.sh" 2>/dev/null; sleep 1
done
arc_log_info "$TAG" '=== Stability Suite: DONE ==='