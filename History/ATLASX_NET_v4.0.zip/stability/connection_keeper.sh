#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='STAB-KEEP'
INTERVAL=45
arc_log_info "$TAG" 'Connection Keeper started'
FAIL=0
while true; do sleep "$INTERVAL"
    ping -c 1 -W 3 1.1.1.1 >/dev/null 2>&1 && FAIL=0 || {
        FAIL=$((FAIL+1))
        arc_log_warn "$TAG" "Connectivity fail #$FAIL"
        [ "$FAIL" -ge 2 ] 2>/dev/null && { sh "$MODPATH/stability/connection_recovery_engine.sh" 2>/dev/null; FAIL=0; }
    }
done