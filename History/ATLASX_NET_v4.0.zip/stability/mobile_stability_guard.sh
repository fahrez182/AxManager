#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='STAB-MOB'
NET_TYPE=$(cat "$MODPATH/data/net_type.txt" 2>/dev/null||echo UNKNOWN)
{ [ "$NET_TYPE" = "4G" ] || [ "$NET_TYPE" = "5G" ]; } || exit 0
arc_exec "settings put global mobile_data_always_on 1" 2>/dev/null
arc_exec "settings put global cell_on 1" 2>/dev/null
arc_log_info "$TAG" "Mobile Stability: always-on $NET_TYPE"