#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='STAB-LONG'
arc_exec "sysctl -w net.ipv4.tcp_slow_start_after_idle=0" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_no_metrics_save=1" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_window_scaling=1" 2>/dev/null
arc_log_info "$TAG" 'Net Longevity: sem regressao apos idle.'