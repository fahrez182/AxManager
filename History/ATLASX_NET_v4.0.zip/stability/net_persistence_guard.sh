#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='STAB-PERSIST'
arc_exec "sysctl -w net.ipv4.tcp_fastopen=3" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_low_latency=1" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_keepalive_time=60" 2>/dev/null
arc_log_info "$TAG" 'Net persistence: configuracoes criticas restauradas.'