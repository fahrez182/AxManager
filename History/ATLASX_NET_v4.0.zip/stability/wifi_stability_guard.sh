#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='STAB-WIFI'
NET_TYPE=$(cat "$MODPATH/data/net_type.txt" 2>/dev/null||echo UNKNOWN)
[ "$NET_TYPE" = "WIFI" ] || exit 0
IFACE=$(cat "$MODPATH/data/active_iface.txt" 2>/dev/null||echo "")
[ -n "$IFACE" ] && [ "$IFACE" != "unknown" ] && iw dev "$IFACE" set power_save off 2>/dev/null
arc_exec "settings put system wifi_sleep_policy 2" 2>/dev/null
arc_log_info "$TAG" 'WiFi Stability: power save off.'