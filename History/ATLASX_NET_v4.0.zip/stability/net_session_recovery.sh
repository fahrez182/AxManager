#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='STAB-SESSION'
arc_exec "sysctl -w net.ipv4.tcp_retries2=8" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_syn_retries=3" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_keepalive_time=60" 2>/dev/null
arc_log_info "$TAG" 'Session Recovery: done.'