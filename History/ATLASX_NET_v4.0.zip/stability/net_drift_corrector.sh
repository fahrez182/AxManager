#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='STAB-DRIFT'
CONG=$(sysctl -n net.ipv4.tcp_congestion_control 2>/dev/null||echo cubic)
[ "$CONG" != "bbr" ] && [ "$CONG" != "cubic" ] && {
    arc_exec "sysctl -w net.ipv4.tcp_congestion_control=cubic" 2>/dev/null
    arc_log_warn "$TAG" "Drift: congestion corrigido"
}
KA=$(sysctl -n net.ipv4.tcp_keepalive_time 2>/dev/null||echo 7200)
[ "$KA" -gt 120 ] 2>/dev/null && {
    arc_exec "sysctl -w net.ipv4.tcp_keepalive_time=60" 2>/dev/null
    arc_log_warn "$TAG" "Drift: keepalive corrigido"
}
arc_log_info "$TAG" 'Net Drift Corrector: done.'