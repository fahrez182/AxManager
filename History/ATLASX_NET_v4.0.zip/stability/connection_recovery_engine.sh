#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='STAB-REC'
arc_log_warn "$TAG" 'Connection Recovery: iniciando...'
sh "$MODPATH/dns/dns_adaptive.sh" 2>/dev/null; sleep 2
sh "$MODPATH/wifi/wifi_adaptive.sh" 2>/dev/null; sleep 2
sh "$MODPATH/mobile/mobile_adaptive.sh" 2>/dev/null; sleep 2
sh "$MODPATH/radio/radio_emergency_recovery.sh" 2>/dev/null; sleep 5
ping -c 1 -W 3 1.1.1.1 >/dev/null 2>&1 && arc_log_info "$TAG" 'Recovery: ok!' || arc_log_error "$TAG" 'Recovery: sem conectividade.'