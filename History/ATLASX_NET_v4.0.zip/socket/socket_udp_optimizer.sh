#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='SOCK-UDP'
arc_exec "sysctl -w net.core.rmem_max=16777216" 2>/dev/null
arc_exec "sysctl -w net.ipv4.udp_rmem_min=16384" 2>/dev/null
arc_exec "sysctl -w net.ipv4.udp_wmem_min=16384" 2>/dev/null
arc_log_info "$TAG" 'Socket UDP: buffers gaming.'