#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='SOCK-CORE'
arc_exec "sysctl -w net.core.somaxconn=2048" 2>/dev/null
arc_exec "sysctl -w net.ipv4.ip_local_port_range='1024 65535'" 2>/dev/null
arc_exec "sysctl -w net.core.optmem_max=65536" 2>/dev/null
arc_log_info "$TAG" 'Socket Core: somaxconn=2048.'