#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='SOCK-BACK'
arc_exec "sysctl -w net.core.netdev_max_backlog=5000" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_max_syn_backlog=4096" 2>/dev/null
arc_log_info "$TAG" 'Socket Backlog: 5000/4096.'