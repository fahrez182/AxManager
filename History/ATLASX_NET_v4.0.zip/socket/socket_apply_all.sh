#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='SOCK-ALL'
arc_log_info "$TAG" '=== Socket Suite: ALL ==='
for s in socket_core_optimizer socket_buffer_optimizer socket_backlog_optimizer socket_timeout_optimizer socket_reuse_optimizer socket_gaming_optimizer socket_udp_optimizer; do sh "$MODPATH/socket/${s}.sh" 2>/dev/null; sleep 1; done
arc_log_info "$TAG" '=== Socket Suite: DONE ==='