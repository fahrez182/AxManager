#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='SOCK-REUSE'
arc_exec "sysctl -w net.ipv4.tcp_tw_reuse=1" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_tw_recycle=0" 2>/dev/null
arc_log_info "$TAG" 'Socket Reuse: TW reuse ON, recycle OFF.'