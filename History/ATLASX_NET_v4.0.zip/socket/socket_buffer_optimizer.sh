#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='SOCK-BUF'
arc_exec "sysctl -w net.core.rmem_default=262144" 2>/dev/null
arc_exec "sysctl -w net.core.wmem_default=262144" 2>/dev/null
arc_exec "sysctl -w net.core.rmem_max=16777216" 2>/dev/null
arc_log_info "$TAG" 'Socket Buffers: 256KB default / 16MB max.'