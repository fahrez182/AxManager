#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='SOCK-TO'
arc_exec "sysctl -w net.ipv4.tcp_fin_timeout=15" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_keepalive_time=60" 2>/dev/null
arc_log_info "$TAG" 'Socket Timeout: fin=15s keepalive=60s.'