#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='GSESS'
arc_exec "sysctl -w net.ipv4.tcp_retries2=8" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_retries1=3" 2>/dev/null
arc_log_info "$TAG" 'Game Session Guard: retries otimizados.'