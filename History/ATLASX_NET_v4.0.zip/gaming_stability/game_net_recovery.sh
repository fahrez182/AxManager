#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='GREC'
GW=$(ip route show default 2>/dev/null | awk '{print $3}' | head -1)
[ -z "$GW" ] && exit 0
ping -c 1 -W 2 "$GW" >/dev/null 2>&1 || {
    arc_log_warn "$TAG" 'Gateway inalcançável — recovery'
    sh "$MODPATH/stability/connection_recovery_engine.sh" 2>/dev/null
}