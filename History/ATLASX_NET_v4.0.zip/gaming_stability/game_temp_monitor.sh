#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='GTEMP'
TEMP=$(cat /sys/class/thermal/thermal_zone0/temp 2>/dev/null||echo 40000)
TEMP_C=$(( TEMP / 1000 ))
[ "$TEMP_C" -gt 50 ] 2>/dev/null && arc_log_warn "$TAG" "Temperatura elevada: ${TEMP_C}°C — reduzindo carga"
arc_log_info "$TAG" "Gaming temp: ${TEMP_C}°C"