#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='GALM'
MS=$(cat "$MODPATH/data/current_ping_ms.txt" 2>/dev/null||echo 0)
[ "$MS" -gt 200 ] 2>/dev/null && arc_log_warn "$TAG" "Ping alto: ${MS}ms"
arc_log_info "$TAG" "Ping alarm check: ${MS}ms"