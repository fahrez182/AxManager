#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='GROUTE'
arc_exec "sysctl -w net.ipv4.ip_dynaddr=0" 2>/dev/null
arc_exec "sysctl -w net.ipv4.conf.all.accept_source_route=0" 2>/dev/null
arc_log_info "$TAG" 'Game routing: estabilizado.'