#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='GSTAB-ALL'
arc_log_info "$TAG" '=== Gaming Stability: ALL ==='
for s in game_session_guard game_ping_alarm game_consistent_route game_udp_buffer_persist game_mobile_data_lock; do sh "$MODPATH/gaming_stability/${s}.sh" 2>/dev/null; sleep 1; done
arc_log_info "$TAG" '=== Gaming Stability: DONE ==='