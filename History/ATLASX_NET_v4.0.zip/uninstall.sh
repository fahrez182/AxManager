#!/system/bin/sh
MODPATH="$(dirname "$0")"
. "$MODPATH/core/compat.sh" 2>/dev/null || true
echo "Desinstalando ATLASX NET..."
# Restaura DNS padrão
arc_exec "settings put global private_dns_mode off" 2>/dev/null
arc_exec "settings put global private_dns_specifier ''" 2>/dev/null
# Mata daemons
pkill -f "atlasx_net" 2>/dev/null
pkill -f "net_scheduler" 2>/dev/null
pkill -f "gaming_ping" 2>/dev/null
pkill -f "dns_cache" 2>/dev/null
# Restaura sysctl de rede
sysctl -w net.core.rmem_default=212992 2>/dev/null
sysctl -w net.core.wmem_default=212992 2>/dev/null
echo "ATLASX NET desinstalado."
