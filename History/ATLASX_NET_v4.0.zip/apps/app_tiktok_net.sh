#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='APP-TT'
STATE=$(cat "$MODPATH/data/current_state.txt" 2>/dev/null||echo BROWSING)
[ "$STATE" = "GAMING" ] && arc_exec "am set-inactive com.zhiliaoapp.musically true" 2>/dev/null
arc_log_info "$TAG" "TikTok net: estado=$STATE"