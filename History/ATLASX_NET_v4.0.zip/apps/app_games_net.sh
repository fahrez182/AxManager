#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='APP-GAMES'
GAMES='com.dts.freefireth com.dts.freefiremax com.tencent.ig com.activision.callofduty com.garena.game.codm'
for pkg in $GAMES; do
    arc_exec "am set-inactive $pkg false" 2>/dev/null
    arc_exec "cmd netpolicy set restrict-background $pkg 0" 2>/dev/null
done
arc_log_info "$TAG" 'Games: rede sem restrição.'