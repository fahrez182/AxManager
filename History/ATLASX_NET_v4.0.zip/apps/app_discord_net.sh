#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='APP-DISC'
arc_exec "am set-inactive com.discord false" 2>/dev/null
arc_exec "cmd netpolicy set restrict-background com.discord 0" 2>/dev/null
arc_exec "sysctl -w net.ipv4.udp_rmem_min=32768" 2>/dev/null
arc_log_info "$TAG" 'Discord: UDP + BG liberado.'