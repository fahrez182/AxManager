#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='APP-IG'
STATE=$(cat "$MODPATH/data/current_state.txt" 2>/dev/null||echo BROWSING)
[ "$STATE" = "GAMING" ] && arc_exec "am set-inactive com.instagram.android true" 2>/dev/null || arc_exec "am set-inactive com.instagram.android false" 2>/dev/null
arc_log_info "$TAG" "Instagram net: estado=$STATE"