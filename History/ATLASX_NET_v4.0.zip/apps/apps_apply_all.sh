#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='APPS-ALL'
arc_log_info "$TAG" '=== Apps Net: ALL ==='
for s in app_whatsapp_net app_telegram_net app_youtube_net app_discord_net app_spotify_net app_games_net app_critical_bg; do sh "$MODPATH/apps/${s}.sh" 2>/dev/null; sleep 1; done
arc_log_info "$TAG" '=== Apps Net: DONE ==='