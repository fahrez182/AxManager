#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='APP-TG'
arc_exec "am set-inactive org.telegram.messenger false" 2>/dev/null
arc_exec "cmd netpolicy set restrict-background org.telegram.messenger 0" 2>/dev/null
arc_log_info "$TAG" 'Telegram: sem restrição de rede.'