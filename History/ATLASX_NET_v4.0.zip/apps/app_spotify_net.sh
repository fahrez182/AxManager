#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='APP-SPOT'
arc_exec "am set-inactive com.spotify.music false" 2>/dev/null
arc_exec "cmd netpolicy set restrict-background com.spotify.music 0" 2>/dev/null
arc_log_info "$TAG" 'Spotify: BG rede liberado.'