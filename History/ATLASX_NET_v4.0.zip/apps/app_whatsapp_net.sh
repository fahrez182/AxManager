#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='APP-WA'
arc_exec "am set-inactive com.whatsapp false" 2>/dev/null
arc_exec "cmd netpolicy set restrict-background com.whatsapp 0" 2>/dev/null
arc_log_info "$TAG" 'WhatsApp: sem restrição de rede.'