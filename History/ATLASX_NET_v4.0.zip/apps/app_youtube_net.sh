#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='APP-YT'
arc_exec "am set-inactive com.google.android.youtube false" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_rmem='4096 131072 16777216'" 2>/dev/null
arc_log_info "$TAG" 'YouTube: buffers 16MB.'