#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
# ATLASX NET — TCP QOS MARKS
# Marca pacotes TCP para priorização no QoS.
TAG="TCP-QOS"
IFACE=$(cat "$MODPATH/data/active_iface.txt" 2>/dev/null || echo "")
[ -z "$IFACE" ] || [ "$IFACE" = "unknown" ] && exit 0
# DSCP marking: prioriza gaming (AF41) e VoIP (EF)
command -v iptables >/dev/null 2>&1 && {
    iptables -t mangle -F OUTPUT 2>/dev/null
    iptables -t mangle -A OUTPUT -p udp --dport 7000:9000 -j DSCP --set-dscp-class AF41 2>/dev/null
    iptables -t mangle -A OUTPUT -p udp --dport 3478:3480 -j DSCP --set-dscp-class EF 2>/dev/null
}
arc_log_info "$TAG" "TCP QoS marks: iface=$IFACE"
