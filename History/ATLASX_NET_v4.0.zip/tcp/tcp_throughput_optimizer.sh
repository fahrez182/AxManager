#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
# ATLASX NET — TCP THROUGHPUT OPTIMIZER
# Maximiza throughput. Modo streaming/download.
TAG="TCP-THRU"
arc_exec "sysctl -w net.ipv4.tcp_low_latency=0" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_autocorking=1" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_window_scaling=1" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_adv_win_scale=2" 2>/dev/null
arc_exec "sysctl -w net.core.netdev_max_backlog=5000" 2>/dev/null
arc_exec "sysctl -w net.core.somaxconn=1024" 2>/dev/null
arc_log_info "$TAG" "TCP Throughput: modo alto-volume ativo."
