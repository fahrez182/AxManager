#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
# ATLASX NET — TCP CORE OPTIMIZER (base para todos os perfis)
TAG="TCP-CORE"
arc_log_info "$TAG" "TCP Core Optimizer..."
arc_exec "sysctl -w net.ipv4.tcp_fastopen=3" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_slow_start_after_idle=0" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_no_metrics_save=1" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_timestamps=1" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_sack=1" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_dsack=1" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_window_scaling=1" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_mtu_probing=1" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_syncookies=1" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_fin_timeout=15" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_tw_reuse=1" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_max_orphans=32768" 2>/dev/null
arc_log_info "$TAG" "TCP Core: done."
