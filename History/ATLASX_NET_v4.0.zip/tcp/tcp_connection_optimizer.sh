#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
# ATLASX NET — TCP CONNECTION OPTIMIZER
# Otimiza half-open connections, SYN, retransmissões.
TAG="TCP-CONN"
arc_exec "sysctl -w net.ipv4.tcp_syn_retries=3" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_synack_retries=3" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_retries1=3" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_retries2=8" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_max_syn_backlog=4096" 2>/dev/null
arc_exec "sysctl -w net.ipv4.ip_local_port_range='1024 65535'" 2>/dev/null
arc_log_info "$TAG" "TCP Connections: done."
