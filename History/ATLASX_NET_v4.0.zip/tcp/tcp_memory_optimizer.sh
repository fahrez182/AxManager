#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
# ATLASX NET — TCP MEMORY OPTIMIZER
# Ajusta alocação de memória TCP para o dispositivo.
TAG="TCP-MEM"
TOTAL=$(awk '/MemTotal/{print int($2)}' /proc/meminfo 2>/dev/null || echo 4194304)
LOW=$(( TOTAL / 64 ))
MED=$(( TOTAL / 32 ))
HIGH=$(( TOTAL / 16 ))
arc_exec "sysctl -w net.ipv4.tcp_mem='$LOW $MED $HIGH'" 2>/dev/null
arc_log_info "$TAG" "TCP Memory: $LOW/$MED/$HIGH (páginas)"
