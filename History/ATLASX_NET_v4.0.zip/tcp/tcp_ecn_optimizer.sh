#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
# ATLASX NET — TCP ECN OPTIMIZER
# Explicit Congestion Notification: reduz drops de pacote.
TAG="TCP-ECN"
arc_exec "sysctl -w net.ipv4.tcp_ecn=1" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_ecn_fallback=1" 2>/dev/null
arc_log_info "$TAG" "TCP ECN: ativado."
