#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
# ATLASX NET — TCP APPLY ALL
TAG="TCP-ALL"
arc_log_info "$TAG" "=== TCP Suite: ALL ==="
for s in tcp_core_optimizer tcp_buffer_optimizer tcp_congestion_control tcp_keepalive_optimizer tcp_connection_optimizer tcp_error_recovery tcp_ecn_optimizer tcp_memory_optimizer; do
    sh "$MODPATH/tcp/${s}.sh" 2>/dev/null; sleep 1
done
arc_log_info "$TAG" "=== TCP Suite: DONE ==="
