#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
# ATLASX NET — TCP BUFFER OPTIMIZER
TAG="TCP-BUF"
arc_log_info "$TAG" "TCP Buffer Optimizer..."
TIER=$(cat "$MODPATH/data/net_tier.txt" 2>/dev/null || echo "MED")
case "$TIER" in
    HIGH) RMEM="4096 87380 16777216"; WMEM="4096 65536 16777216" ;;
    MED)  RMEM="4096 65536 8388608";  WMEM="4096 49152 8388608"  ;;
    *)    RMEM="4096 43690 4194304";  WMEM="4096 32768 4194304"  ;;
esac
arc_exec "sysctl -w net.ipv4.tcp_rmem='$RMEM'" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_wmem='$WMEM'" 2>/dev/null
arc_exec "sysctl -w net.core.rmem_max=16777216" 2>/dev/null
arc_exec "sysctl -w net.core.wmem_max=16777216" 2>/dev/null
arc_exec "sysctl -w net.core.rmem_default=262144" 2>/dev/null
arc_exec "sysctl -w net.core.wmem_default=262144" 2>/dev/null
arc_exec "sysctl -w net.core.optmem_max=65536" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_mem='786432 1048576 26777216'" 2>/dev/null
arc_log_info "$TAG" "TCP Buffers: TIER=$TIER done."
