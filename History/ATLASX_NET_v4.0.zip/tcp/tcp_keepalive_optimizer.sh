#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
# ATLASX NET — TCP KEEPALIVE
# Mantém conexões vivas. Crucial para jogos e VoIP.
TAG="TCP-KEEP"
arc_exec "sysctl -w net.ipv4.tcp_keepalive_time=60" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_keepalive_intvl=10" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_keepalive_probes=6" 2>/dev/null
arc_log_info "$TAG" "TCP Keepalive: time=60s interval=10s probes=6"
