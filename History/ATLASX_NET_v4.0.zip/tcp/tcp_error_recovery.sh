#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
# ATLASX NET — TCP ERROR RECOVERY
# Acelera recuperação de erros e timeouts.
TAG="TCP-ERR"
arc_exec "sysctl -w net.ipv4.tcp_reordering=3" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_frto=2" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_rfc1337=1" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_abort_on_overflow=0" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_max_tw_buckets=32768" 2>/dev/null
arc_log_info "$TAG" "TCP Error Recovery: done."
