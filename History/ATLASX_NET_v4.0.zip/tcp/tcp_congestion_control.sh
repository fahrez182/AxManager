#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
# ATLASX NET — TCP CONGESTION CONTROL
# Seleciona algoritmo ideal: BBR > CUBIC > RENO
TAG="TCP-CONG"
arc_log_info "$TAG" "Selecionando congestion control..."
AVAILABLE=$(cat /proc/sys/net/ipv4/tcp_available_congestion_control 2>/dev/null || echo "cubic")
STATE=$(cat "$MODPATH/data/current_state.txt" 2>/dev/null || echo "BROWSING")
if echo "$AVAILABLE" | grep -q "bbr"; then
    arc_exec "sysctl -w net.ipv4.tcp_congestion_control=bbr" 2>/dev/null
    arc_log_info "$TAG" "BBR ativado"
elif echo "$AVAILABLE" | grep -q "cubic"; then
    arc_exec "sysctl -w net.ipv4.tcp_congestion_control=cubic" 2>/dev/null
    arc_log_info "$TAG" "CUBIC ativado"
else
    arc_exec "sysctl -w net.ipv4.tcp_congestion_control=reno" 2>/dev/null
fi
arc_exec "sysctl -w net.core.default_qdisc=fq" 2>/dev/null
