#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
# ATLASX NET — TCP LATENCY OPTIMIZER
# Reduz latência ao custo de throughput (modo gaming/voip).
TAG="TCP-LAT"
arc_exec "sysctl -w net.ipv4.tcp_low_latency=1" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_nodelay=1" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_thin_linear_timeouts=1" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_thin_dupack=1" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_autocorking=0" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_nagle=0" 2>/dev/null
arc_log_info "$TAG" "TCP Latency: modo baixa-latência ativo."
