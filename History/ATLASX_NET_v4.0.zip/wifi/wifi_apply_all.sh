#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='WIFI-ALL'
arc_log_info "$TAG" '=== WiFi Suite: ALL ==='
for s in wifi_core_optimizer wifi_scan_optimizer wifi_power_mode wifi_frequency_optimizer wifi_latency_reducer wifi_roaming_optimizer wifi_aggressive_handover wifi_qos_optimizer; do
    sh "$MODPATH/wifi/${s}.sh" 2>/dev/null; sleep 1
done
arc_log_info "$TAG" '=== WiFi Suite: DONE ==='