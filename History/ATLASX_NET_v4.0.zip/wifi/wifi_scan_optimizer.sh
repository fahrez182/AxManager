#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='WIFI-SCAN'
arc_exec "settings put global wifi_scan_always_available 0" 2>/dev/null
arc_exec "settings put global soft_ap_timeout_enabled 0" 2>/dev/null
arc_exec "setprop wifi.supplicant_scan_interval 600" 2>/dev/null
arc_exec "settings put global wifi_networks_available_notification_on 0" 2>/dev/null
arc_log_info "$TAG" 'WiFi Scan: intervalo máximo, notificações off.'