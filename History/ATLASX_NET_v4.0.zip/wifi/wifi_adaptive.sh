#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='WIFI-ADAPT'
STATE=$(cat "$MODPATH/data/current_state.txt" 2>/dev/null||echo BROWSING)
sh "$MODPATH/wifi/wifi_core_optimizer.sh" 2>/dev/null
sh "$MODPATH/wifi/wifi_power_mode.sh" 2>/dev/null
case "$STATE" in
    GAMING) sh "$MODPATH/wifi/wifi_latency_reducer.sh" 2>/dev/null ;;
    STREAMING) sh "$MODPATH/wifi/wifi_qos_optimizer.sh" 2>/dev/null ;;
esac
arc_log_info "$TAG" "WiFi adaptive: estado=$STATE"
