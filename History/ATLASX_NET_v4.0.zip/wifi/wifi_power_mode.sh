#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='WIFI-PWR'
STATE=$(cat "$MODPATH/data/current_state.txt" 2>/dev/null||echo BROWSING)
case "$STATE" in
    GAMING|STREAMING|VOIP)
        arc_exec "settings put system wifi_sleep_policy 2" 2>/dev/null
        arc_exec "sysctl -w net.ipv4.tcp_keepalive_time=30" 2>/dev/null
        arc_log_info "$TAG" 'WiFi Power: HIGH (performance)' ;;
    SCREEN_OFF)
        arc_exec "settings put system wifi_sleep_policy 0" 2>/dev/null
        arc_log_info "$TAG" 'WiFi Power: LOW (sleep)' ;;
    *)
        arc_exec "settings put system wifi_sleep_policy 2" 2>/dev/null
        arc_log_info "$TAG" 'WiFi Power: BALANCED' ;;
esac