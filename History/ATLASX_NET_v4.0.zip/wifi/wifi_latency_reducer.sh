#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='WIFI-LAT'
arc_exec "sysctl -w net.ipv4.tcp_keepalive_time=45" 2>/dev/null
arc_exec "settings put global wifi_scan_always_available 0" 2>/dev/null
arc_exec "settings put system wifi_sleep_policy 2" 2>/dev/null
arc_log_info "$TAG" 'WiFi Latency: minimizada.'