#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='WIFI-SIG'
IFACE=$(cat "$MODPATH/data/active_iface.txt" 2>/dev/null||echo "")
[ -z "$IFACE" ] && exit 0
iwconfig "$IFACE" txpower auto 2>/dev/null
arc_exec "setprop wifi.supplicant.screen.on.scan.interval.ms 0" 2>/dev/null
arc_log_info "$TAG" "WiFi Signal booster: $IFACE txpower auto."
