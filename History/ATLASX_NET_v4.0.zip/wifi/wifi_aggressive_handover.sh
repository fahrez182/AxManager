#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='WIFI-HAND'
arc_exec "settings put global wifi_to_mobile_handover 1" 2>/dev/null
arc_exec "settings put global mobile_data_always_on 1" 2>/dev/null
arc_log_info "$TAG" 'WiFi Handover: sem queda de conexão.'