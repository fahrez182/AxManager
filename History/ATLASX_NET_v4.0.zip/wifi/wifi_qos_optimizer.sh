#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='WIFI-QOS'
IFACE=$(cat "$MODPATH/data/active_iface.txt" 2>/dev/null||echo "")
[ -z "$IFACE" ] || [ "$IFACE" = "unknown" ] && exit 0
tc qdisc del dev "$IFACE" root 2>/dev/null
tc qdisc add dev "$IFACE" root fq_codel 2>/dev/null || tc qdisc add dev "$IFACE" root pfifo_fast 2>/dev/null
arc_log_info "$TAG" "WiFi QoS fq_codel: $IFACE"
