#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='WIFI-FREQ'
arc_exec "settings put global wifi_frequency_band 2" 2>/dev/null
arc_exec "setprop wifi.interface wlan0" 2>/dev/null
arc_log_info "$TAG" 'WiFi Frequency: 5GHz preferred.'