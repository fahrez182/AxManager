#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='WIFI-CORE'
arc_exec "settings put global wifi_sleep_policy 2" 2>/dev/null
arc_exec "settings put global wifi_scan_always_available 0" 2>/dev/null
arc_exec "settings put global wifi_roam_scan_period 30" 2>/dev/null
arc_exec "settings put global wifi_watchdog_poor_network_test_enabled 0" 2>/dev/null
arc_exec "setprop wifi.supplicant_scan_interval 300" 2>/dev/null
arc_log_info "$TAG" 'WiFi Core: varreduras desnecessárias desativadas.'