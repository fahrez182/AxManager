#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='WIFI-ROAM'
arc_exec "settings put global wifi_roam_scan_period 60" 2>/dev/null
arc_exec "settings put global network_preference_signal_strength 4" 2>/dev/null
arc_log_info "$TAG" 'WiFi Roaming: agressivo (pega melhor AP).'