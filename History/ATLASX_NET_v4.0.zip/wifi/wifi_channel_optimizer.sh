#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='WIFI-CHAN'
arc_exec "settings put global wifi_saved_state 1" 2>/dev/null
arc_exec "setprop wifi.supplicant_scan_interval 180" 2>/dev/null
arc_log_info "$TAG" 'WiFi Channel: scan otimizado.'