#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='QOS-DSCP'
IFACE=$(cat "$MODPATH/data/active_iface.txt" 2>/dev/null||echo "")
[ -z "$IFACE" ] && exit 0
command -v iptables >/dev/null 2>&1 && {
    iptables -t mangle -F OUTPUT 2>/dev/null
    iptables -t mangle -A OUTPUT -p udp --dport 1024:65535 -j DSCP --set-dscp-class AF41 2>/dev/null
    iptables -t mangle -A OUTPUT -p udp -m udp --dport 5060 -j DSCP --set-dscp-class EF 2>/dev/null
}
arc_log_info "$TAG" "QoS DSCP: AF41 UDP gaming, EF VoIP."
