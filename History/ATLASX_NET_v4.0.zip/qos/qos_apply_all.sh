#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='QOS-ALL'
arc_log_info "$TAG" '=== QoS Suite: ALL ==='
sh "$MODPATH/qos/qos_engine.sh"          ; sleep 1
sh "$MODPATH/qos/qos_adaptive.sh"        ; sleep 1
sh "$MODPATH/qos/qos_dscp_marks.sh"      ; sleep 1
arc_log_info "$TAG" '=== QoS Suite: DONE ==='