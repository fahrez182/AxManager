#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='QOS-BW'
IFACE=$(cat "$MODPATH/data/active_iface.txt" 2>/dev/null||echo "")
NET_TYPE=$(cat "$MODPATH/data/net_type.txt" 2>/dev/null||echo UNKNOWN)
[ -z "$IFACE" ] || [ "$IFACE" = "unknown" ] && exit 0
case "$NET_TYPE" in
    5G)   RATE="500mbit" ;;
    4G)   RATE="100mbit" ;;
    WIFI) RATE="300mbit" ;;
    *)    RATE="50mbit"  ;;
esac
tc qdisc del dev "$IFACE" root 2>/dev/null
tc qdisc add dev "$IFACE" root tbf rate "$RATE" burst 32kb latency 50ms 2>/dev/null
arc_log_info "$TAG" "QoS Bandwidth: $IFACE rate=$RATE"
