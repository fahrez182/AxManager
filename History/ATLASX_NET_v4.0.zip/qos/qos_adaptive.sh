#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='QOS-ADAPT'
STATE=$(cat "$MODPATH/data/current_state.txt" 2>/dev/null||echo BROWSING)
case "$STATE" in
    GAMING)    sh "$MODPATH/qos/qos_gaming_profile.sh" 2>/dev/null ;;
    STREAMING) sh "$MODPATH/qos/qos_streaming_profile.sh" 2>/dev/null ;;
    VOIP)      sh "$MODPATH/qos/qos_voip_profile.sh" 2>/dev/null ;;
    SCREEN_OFF)sh "$MODPATH/qos/qos_idle_profile.sh" 2>/dev/null ;;
    *)         sh "$MODPATH/qos/qos_balanced_profile.sh" 2>/dev/null ;;
esac
arc_log_info "$TAG" "QoS adaptive: estado=$STATE"
