#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='QOS-ENG'
IFACE=$(cat "$MODPATH/data/active_iface.txt" 2>/dev/null||echo "")
[ -z "$IFACE" ] || [ "$IFACE" = "unknown" ] && exit 0
tc qdisc del dev "$IFACE" root 2>/dev/null
tc qdisc add dev "$IFACE" root handle 1: prio priomap 2 2 2 2 1 1 1 1 0 0 0 0 3 3 3 3 2>/dev/null
# Gaming UDP: prio 0 (highest)
tc filter add dev "$IFACE" parent 1: protocol ip u32 match ip protocol 17 0xff match ip dport 7000 0xff00 flowid 1:1 2>/dev/null
# VoIP: prio 1
tc filter add dev "$IFACE" parent 1: protocol ip u32 match ip protocol 17 0xff match ip dport 3478 0xffff flowid 1:2 2>/dev/null
# Normal: prio 2
tc filter add dev "$IFACE" parent 1: protocol ip u32 match ip protocol 6 0xff flowid 1:3 2>/dev/null
arc_log_info "$TAG" "QoS Engine: $IFACE — 3 níveis"
