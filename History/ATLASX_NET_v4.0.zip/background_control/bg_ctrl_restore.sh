#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='BGCTRL-RST'
for pkg in com.facebook.katana com.instagram.android com.zhiliaoapp.musically; do
    arc_exec "am set-inactive $pkg false" 2>/dev/null
done
arc_exec "settings put global background_data 1" 2>/dev/null
arc_log_info "$TAG" 'BG data: restaurado.'