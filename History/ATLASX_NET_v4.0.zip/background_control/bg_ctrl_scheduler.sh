#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='BGCTRL-SCHED'
STATE=$(cat "$MODPATH/data/current_state.txt" 2>/dev/null||echo BROWSING)
[ "$STATE" = "GAMING" ] && sh "$MODPATH/background/bg_hog_killer.sh" 2>/dev/null
arc_log_info "$TAG" "BG Control Scheduler: estado=$STATE"