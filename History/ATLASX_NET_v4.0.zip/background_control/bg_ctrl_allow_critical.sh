#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='BGCTRL-CRIT'
CRIT='com.whatsapp org.telegram.messenger com.google.android.gm'
for pkg in $CRIT; do arc_exec "cmd netpolicy set restrict-background $pkg 0" 2>/dev/null; done
arc_log_info "$TAG" 'Critical apps: BG data desbloqueado.'