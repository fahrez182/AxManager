#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='BGCTRL-MON'
INTERVAL=120
while true; do sleep "$INTERVAL"
    STATE=$(cat "$MODPATH/data/current_state.txt" 2>/dev/null||echo BROWSING)
    sh "$MODPATH/background_control/bg_ctrl_scheduler.sh" 2>/dev/null
    arc_log_info "$TAG" "BG monitor tick: $STATE"
done