#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='BGCTRL-ALL'
arc_log_info "$TAG" '=== BG Control: ALL ==='
for s in bg_ctrl_throttle_heavy bg_ctrl_allow_critical bg_ctrl_data_usage; do sh "$MODPATH/background_control/${s}.sh" 2>/dev/null; sleep 1; done
arc_log_info "$TAG" '=== BG Control: DONE ==='