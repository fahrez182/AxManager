#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='BGCTRL-WIFI'
arc_exec "settings put global preferred_network_mode_background 0" 2>/dev/null
arc_log_info "$TAG" 'BG WiFi-only: habilitado para updates.'