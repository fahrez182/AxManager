#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='BGCTRL-THR'
HEAVY='com.facebook.katana com.instagram.android'
for pkg in $HEAVY; do arc_exec "cmd netpolicy set restrict-background $pkg 1" 2>/dev/null; done
arc_log_info "$TAG" 'BG heavy throttled.'