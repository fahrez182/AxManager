#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='ANA-QUAL'
INTERVAL=120
while true; do
    sleep "$INTERVAL"
    sh "$MODPATH/monitoring/net_health_check.sh" 2>/dev/null
    sh "$MODPATH/analytics/net_analytics.sh" 2>/dev/null
done