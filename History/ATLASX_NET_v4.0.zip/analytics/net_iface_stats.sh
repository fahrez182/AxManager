#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='ANA-IFACE'
IFACE=$(cat "$MODPATH/data/active_iface.txt" 2>/dev/null||echo '')
[ -z "$IFACE" ] && exit 0
RX=$(cat "/sys/class/net/$IFACE/statistics/rx_bytes" 2>/dev/null||echo 0)
TX=$(cat "/sys/class/net/$IFACE/statistics/tx_bytes" 2>/dev/null||echo 0)
arc_log_info "$TAG" "Stats: $IFACE rx=$(($RX/1024/1024))MB tx=$(($TX/1024/1024))MB"