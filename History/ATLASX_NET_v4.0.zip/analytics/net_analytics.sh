#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='ANA-NET'
STATE=$(cat "$MODPATH/data/current_state.txt" 2>/dev/null||echo BROWSING)
SCORE=$(cat "$MODPATH/data/net_quality.txt" 2>/dev/null||echo "?")
NET_TYPE=$(cat "$MODPATH/data/net_type.txt" 2>/dev/null||echo "?")
LOG="$MODPATH/logs/analytics.log"; mkdir -p "$MODPATH/logs"
echo "$(date '+%Y-%m-%d %H:%M') state=$STATE quality=$SCORE net=$NET_TYPE" >> "$LOG"
tail -500 "$LOG" > "${LOG}.tmp" 2>/dev/null && mv "${LOG}.tmp" "$LOG" 2>/dev/null
arc_log_info "$TAG" "Analytics: state=$STATE quality=$SCORE net=$NET_TYPE"
