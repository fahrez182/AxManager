#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='ANA-SESSION'
START=$(date '+%s' 2>/dev/null||echo 0)
echo "$START" > "$MODPATH/data/session_start.txt"
arc_log_info "$TAG" 'Session started.'