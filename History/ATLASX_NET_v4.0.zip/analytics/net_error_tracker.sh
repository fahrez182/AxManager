#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='ANA-ERR'
ERR_LOG="$MODPATH/logs/errors.log"
grep -c 'ERROR\|WARN' "$MODPATH/logs/system.log" 2>/dev/null > "$MODPATH/data/error_count.txt"
arc_log_info "$TAG" 'Error tracker: updated.'