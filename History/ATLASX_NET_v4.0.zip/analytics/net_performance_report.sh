#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='ANA-PERF'
PING=$(cat "$MODPATH/data/current_ping_ms.txt" 2>/dev/null||echo "?")
IFACE=$(cat "$MODPATH/data/active_iface.txt" 2>/dev/null||echo "?")
CONNS=$(cat "$MODPATH/data/active_connections.txt" 2>/dev/null||echo "?")
arc_log_info "$TAG" "Performance: ping=${PING}ms iface=$IFACE conns=$CONNS"
