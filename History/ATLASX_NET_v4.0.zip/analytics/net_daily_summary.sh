#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='ANA-DAILY'
DATE=$(date '+%Y-%m-%d' 2>/dev/null||echo "?")
PING=$(cat "$MODPATH/data/current_ping_ms.txt" 2>/dev/null||echo "?")
SCORE=$(cat "$MODPATH/data/net_quality.txt" 2>/dev/null||echo "?")
arc_log_info "$TAG" "Daily Summary [$DATE]: ping=${PING}ms quality=$SCORE"
