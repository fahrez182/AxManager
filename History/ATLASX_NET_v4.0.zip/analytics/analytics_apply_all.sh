#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='ANA-ALL'
arc_log_info "$TAG" '=== Analytics: ALL ==='
sh "$MODPATH/analytics/net_analytics.sh" 2>/dev/null
sh "$MODPATH/analytics/net_performance_report.sh" 2>/dev/null
sh "$MODPATH/analytics/net_iface_stats.sh" 2>/dev/null
arc_log_info "$TAG" '=== Analytics: DONE ==='