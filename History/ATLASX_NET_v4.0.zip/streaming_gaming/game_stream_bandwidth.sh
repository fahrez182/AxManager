#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='GSTR-BW'
arc_exec "sysctl -w net.core.rmem_max=16777216" 2>/dev/null
arc_exec "sysctl -w net.core.wmem_max=16777216" 2>/dev/null
arc_log_info "$TAG" 'Game streaming bandwidth: 16MB.'