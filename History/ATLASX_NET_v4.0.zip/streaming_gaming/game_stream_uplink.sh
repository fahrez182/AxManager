#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='GSTR-UP'
arc_exec "sysctl -w net.ipv4.tcp_wmem='4096 65536 16777216'" 2>/dev/null
arc_log_info "$TAG" 'Game streaming uplink: otimizado.'