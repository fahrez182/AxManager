#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='GSTR-ALL'
arc_log_info "$TAG" '=== Game Streaming: ALL ==='
for s in game_stream_buffer game_stream_latency game_stream_bandwidth game_stream_uplink game_stream_qos game_stream_dns; do sh "$MODPATH/streaming_gaming/${s}.sh" 2>/dev/null; sleep 1; done
arc_log_info "$TAG" '=== Game Streaming: DONE ==='