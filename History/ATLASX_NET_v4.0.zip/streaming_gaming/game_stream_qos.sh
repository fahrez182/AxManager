#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='GSTR-QOS'
IFACE=$(cat "$MODPATH/data/active_iface.txt" 2>/dev/null||echo '')
[ -n "$IFACE" ] && tc qdisc add dev "$IFACE" root fq_codel target 5ms 2>/dev/null
arc_log_info "$TAG" 'Game stream QoS: fq_codel 5ms.'