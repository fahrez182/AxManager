#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='GSTR-AUD'
arc_exec "sysctl -w net.core.netdev_budget=600" 2>/dev/null
arc_log_info "$TAG" 'Game stream audio: netdev budget 600.'