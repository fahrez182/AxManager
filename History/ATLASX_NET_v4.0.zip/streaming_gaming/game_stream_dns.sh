#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='GSTR-DNS'
arc_exec "setprop net.dns1 1.1.1.1" 2>/dev/null
arc_exec "setprop net.dns2 8.8.8.8" 2>/dev/null
arc_log_info "$TAG" 'Game stream DNS: Cloudflare.'