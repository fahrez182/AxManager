#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='VPN-RECON'
INTERVAL=30
while true; do sleep "$INTERVAL"
    STATE=$(cat "$MODPATH/data/current_state.txt" 2>/dev/null||echo BROWSING)
    [ "$STATE" = "SCREEN_OFF" ] && continue
    arc_log_info "$TAG" 'VPN reconnect guard: tick'
done