#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='VPN-GAME'
arc_exec "sysctl -w net.ipv4.tcp_low_latency=1" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_autocorking=0" 2>/dev/null
arc_log_info "$TAG" 'VPN Gaming: low latency mode.'