#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='VPN-ALL'
arc_log_info "$TAG" '=== VPN Suite: ALL ==='
for s in vpn_core_optimizer vpn_dns_leak_prevention vpn_protocol_optimizer vpn_connection_keeper; do sh "$MODPATH/vpn/${s}.sh" 2>/dev/null; sleep 1; done
arc_log_info "$TAG" '=== VPN Suite: DONE ==='