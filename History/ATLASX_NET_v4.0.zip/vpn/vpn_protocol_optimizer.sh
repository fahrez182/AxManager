#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='VPN-PROTO'
arc_exec "sysctl -w net.ipv4.tcp_fastopen=3" 2>/dev/null
arc_exec "setprop net.quic.enabled 1" 2>/dev/null
arc_log_info "$TAG" 'VPN Protocol: FastOpen + QUIC.'