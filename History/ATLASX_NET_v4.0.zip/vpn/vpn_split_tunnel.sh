#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='VPN-SPLIT'
arc_exec "settings put global vpn_split_tunnel 1" 2>/dev/null
arc_log_info "$TAG" 'VPN Split Tunnel: habilitado.'