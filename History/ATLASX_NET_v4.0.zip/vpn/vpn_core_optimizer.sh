#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='VPN-CORE'
arc_exec "sysctl -w net.ipv4.tcp_keepalive_time=30" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_keepalive_intvl=10" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_rmem='4096 87380 8388608'" 2>/dev/null
arc_log_info "$TAG" 'VPN: keepalive + buffers.'