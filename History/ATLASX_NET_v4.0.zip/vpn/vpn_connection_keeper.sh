#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='VPN-KEEP'
arc_exec "sysctl -w net.ipv4.tcp_keepalive_time=20" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_keepalive_probes=10" 2>/dev/null
arc_log_info "$TAG" 'VPN Connection Keeper: 20s/10 probes.'