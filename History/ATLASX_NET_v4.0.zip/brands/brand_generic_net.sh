#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='BRAND-GEN'
arc_exec "setprop net.dns1 1.1.1.1" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_fastopen=3" 2>/dev/null
arc_log_info "$TAG" 'Generic brand NET: baseline.'