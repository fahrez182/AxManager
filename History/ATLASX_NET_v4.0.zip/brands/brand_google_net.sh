#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='BRAND-GOOG'
arc_exec "settings put global private_dns_mode hostname" 2>/dev/null
arc_exec "settings put global private_dns_specifier dns.google" 2>/dev/null
arc_exec "setprop net.dns1 8.8.8.8" 2>/dev/null
arc_log_info "$TAG" 'Google Pixel NET: Google DNS + DoT.'