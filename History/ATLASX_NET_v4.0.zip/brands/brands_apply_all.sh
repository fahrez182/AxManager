#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='BRANDS-ALL'
arc_log_info "$TAG" '=== Brands NET: ALL ==='
sh "$MODPATH/brands/brand_router.sh" 2>/dev/null
sh "$MODPATH/brands/brand_gaming_phone_net.sh" 2>/dev/null
arc_log_info "$TAG" '=== Brands NET: DONE ==='