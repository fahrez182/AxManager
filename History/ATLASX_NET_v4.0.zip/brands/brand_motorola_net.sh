#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='BRAND-MOTO'
arc_exec "sysctl -w net.ipv4.tcp_low_latency=1" 2>/dev/null
arc_exec "settings put global motorola_network_optimized 1" 2>/dev/null
arc_log_info "$TAG" 'Motorola NET: low latency.'