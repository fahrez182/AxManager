#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='BRAND-SAMS'
arc_exec "settings put global samsung_wifi_enhanced 1" 2>/dev/null
arc_exec "settings put global wifi_roam_scan_period 30" 2>/dev/null
arc_exec "setprop persist.net.pdp_max_active 10" 2>/dev/null
arc_log_info "$TAG" 'Samsung NET: enhanced WiFi + max PDPs.'