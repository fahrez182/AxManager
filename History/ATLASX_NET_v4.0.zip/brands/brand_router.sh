#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='BRAND'
BRAND=$(getprop ro.product.brand 2>/dev/null | tr "[:upper:]" "[:lower:]")
arc_log_info "$TAG" "Brand detected: $BRAND"
case "$BRAND" in
    xiaomi|redmi|poco) sh "$MODPATH/brands/brand_xiaomi_net.sh" 2>/dev/null ;;
    samsung)          sh "$MODPATH/brands/brand_samsung_net.sh" 2>/dev/null ;;
    oneplus)          sh "$MODPATH/brands/brand_oneplus_net.sh" 2>/dev/null ;;
    google)           sh "$MODPATH/brands/brand_google_net.sh" 2>/dev/null ;;
    huawei|honor)     sh "$MODPATH/brands/brand_huawei_net.sh" 2>/dev/null ;;
    motorola|moto)    sh "$MODPATH/brands/brand_motorola_net.sh" 2>/dev/null ;;
    *) arc_log_info "$TAG" "Brand: generic profile" ;;
esac