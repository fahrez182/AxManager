#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='BRAND-HW'
arc_exec "setprop persist.radio.lte_band_enable 1" 2>/dev/null
arc_exec "settings put global huawei_net_boost 1" 2>/dev/null
arc_log_info "$TAG" 'Huawei/Honor NET: LTE band + boost.'