#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='BRAND-MI'
arc_exec "setprop persist.vendor.radio.5g_enable 1" 2>/dev/null
arc_exec "settings put global miui_fast_connect 1" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_low_latency=1" 2>/dev/null
arc_exec "setprop net.miui.network_optimize 1" 2>/dev/null
arc_log_info "$TAG" 'Xiaomi NET: 5G + MIUI fast connect.'