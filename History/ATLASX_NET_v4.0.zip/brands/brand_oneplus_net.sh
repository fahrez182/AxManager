#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='BRAND-OP'
arc_exec "setprop persist.radio.5g_enable 1" 2>/dev/null
arc_exec "settings put global oneplus_network_boost 1" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_low_latency=1" 2>/dev/null
arc_log_info "$TAG" 'OnePlus NET: 5G + low latency.'