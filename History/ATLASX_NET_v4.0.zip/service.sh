#!/system/bin/sh
# ATLASX NET v4.0 — SERVICE.SH
# Arquitetura: 1 loop central NET Scheduler + daemons essenciais
# ADB / Shizuku / Root | sem root obrigatório
# Inspirado na arquitetura ATLASX ARC Long-Term Stability
MODPATH="${0%/*}"; export MODPATH

# Aguarda boot completo (máx 180s)
WAIT=0
until [ "$WAIT" -ge 90 ]; do
    [ "$(getprop sys.boot_completed 2>/dev/null)" = "1" ] && break
    sleep 2; WAIT=$((WAIT+1))
done
sleep 20

. "$MODPATH/core/compat.sh"
. "$MODPATH/core/logger.sh"
TAG="SERVICE"
mkdir -p "$MODPATH/data" "$MODPATH/logs" "$MODPATH/locks" "$MODPATH/pids"
arc_log_info "$TAG" "=== ATLASX NET v4.0 — INICIANDO ==="
arc_log_info "$TAG" "Runtime: $ARC_RUNTIME | SDK: $ARC_SDK | Brand: $ARC_DEVICE_BRAND"

# ══════════════════════════════════════════════════════════════════════════════
# ONE-SHOT BOOT: aplicados 1x na inicialização
# ══════════════════════════════════════════════════════════════════════════════
arc_log_info "$TAG" "[BOOT] One-shots iniciando..."
for script in \
    core/hardware_detector.sh \
    core/network_detector.sh \
    brands/brand_router.sh \
    kernel_net/kernel_net_apply_all.sh \
    socket/socket_apply_all.sh \
    tcp/tcp_apply_all.sh \
    udp/udp_apply_all.sh \
    dns/dns_apply_all.sh \
    dns_advanced/dns_advanced_apply_all.sh \
    http/http_apply_all.sh \
    wifi/wifi_apply_all.sh \
    wifi_advanced/wifi_advanced_apply_all.sh \
    mobile/mobile_apply_all.sh \
    qos/qos_apply_all.sh \
    streaming/streaming_apply_all.sh \
    voip/voip_apply_all.sh \
    apps/apps_apply_all.sh \
    security/security_apply_all.sh \
    ipv6/ipv6_apply_all.sh \
    background/background_apply_all.sh \
    radio/radio_apply_all.sh \
    signal/signal_apply_all.sh \
    tether/tether_apply_all.sh \
    profiles/profiles_apply_all.sh \
    stability/stability_apply_all.sh \
    arc_net_persistence/arc_net_persistence_apply_all.sh \
    arc_net_consistency/arc_net_consistency_apply_all.sh \
    smart_net/smart_net_apply_all.sh \
    conflict_prevention/conflict_prevention_apply_all.sh \
    module_optimizer/module_optimizer_apply_all.sh \
    gaming_ping/gaming_ping_apply_all.sh; do
    [ -f "$MODPATH/$script" ] && {
        arc_log_info "$TAG" "[ONE-SHOT] $script"
        sh "$MODPATH/$script" 2>/dev/null
        sleep 1
    }
done
arc_log_info "$TAG" "[BOOT] One-shots concluídos."

# ══════════════════════════════════════════════════════════════════════════════
# DAEMONS ESSENCIAIS (loops independentes em background)
# Apenas os que PRECISAM de loop próprio — o resto vai pelo Scheduler
# ══════════════════════════════════════════════════════════════════════════════
arc_log_info "$TAG" "[DAEMONS] Iniciando daemons essenciais..."

# 1. Net State Manager (detecta GAMING/STREAMING/VOIP/BROWSING)
sh "$MODPATH/core/net_state_manager.sh" &
echo $! > "$MODPATH/pids/net_state_manager.pid"
arc_log_info "$TAG" "[DAEMON] Net State Manager PID=$!"

# 2. Interface Manager (detecta trocas WiFi↔4G)
sh "$MODPATH/core/iface_manager.sh" &
echo $! > "$MODPATH/pids/iface_manager.pid"
arc_log_info "$TAG" "[DAEMON] Iface Manager PID=$!"

# 3. Net Watchdog (keepalive + recovery)
sh "$MODPATH/runtime/net_watchdog.sh" &
echo $! > "$MODPATH/pids/net_watchdog.pid"
arc_log_info "$TAG" "[DAEMON] Net Watchdog PID=$!"

# 4. Radio Keeper (mantém sinal móvel)
sh "$MODPATH/radio/radio_keeper.sh" &
echo $! > "$MODPATH/pids/radio_keeper.pid"
arc_log_info "$TAG" "[DAEMON] Radio Keeper PID=$!"

# 5. Conflict Manager (mutex de recursos)
sh "$MODPATH/runtime/net_conflict_manager.sh" &
echo $! > "$MODPATH/pids/net_conflict_manager.pid"
arc_log_info "$TAG" "[DAEMON] Conflict Manager PID=$!"

# 6. Net Health Monitor (mede latência + score)
sh "$MODPATH/core/net_health_monitor.sh" &
echo $! > "$MODPATH/pids/net_health_monitor.pid"
arc_log_info "$TAG" "[DAEMON] Net Health Monitor PID=$!"

# 7. Connection Keeper (detecta queda + recovery)
sh "$MODPATH/stability/connection_keeper.sh" &
echo $! > "$MODPATH/pids/connection_keeper.pid"
arc_log_info "$TAG" "[DAEMON] Connection Keeper PID=$!"

# 8. Net Quality Tracker (analytics periódico)
sh "$MODPATH/analytics/net_quality_tracker.sh" &
echo $! > "$MODPATH/pids/net_quality_tracker.pid"
arc_log_info "$TAG" "[DAEMON] Quality Tracker PID=$!"

# 9. ARC Net Adaptation Score Monitor
sh "$MODPATH/arc_net_adaptation/net_adapt_score_monitor.sh" &
echo $! > "$MODPATH/pids/net_adapt_score.pid"
arc_log_info "$TAG" "[DAEMON] Adaptation Monitor PID=$!"

arc_log_info "$TAG" "[DAEMONS] 9 daemons essenciais ativos."

# ══════════════════════════════════════════════════════════════════════════════
# LOOP CENTRAL — NET SCHEDULER (único, tick = 10s)
# Agenda todas as otimizações adaptativas. Substitui 50+ loops individuais.
# ══════════════════════════════════════════════════════════════════════════════
arc_log_info "$TAG" "[SCHEDULER] NET Scheduler v3.0 iniciando (tick=10s)..."
exec sh "$MODPATH/runtime/net_scheduler.sh"
