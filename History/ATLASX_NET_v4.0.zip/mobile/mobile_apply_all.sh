#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='MOB-ALL'
arc_log_info "$TAG" '=== Mobile Suite: ALL ==='
for s in mobile_core_optimizer mobile_signal_optimizer mobile_data_always_on mobile_carrier_aggregation mobile_voip_optimizer; do
    sh "$MODPATH/mobile/${s}.sh" 2>/dev/null; sleep 1
done
arc_log_info "$TAG" '=== Mobile Suite: DONE ==='