#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='MOB-5G'
arc_exec "settings put global preferred_network_mode 27" 2>/dev/null
arc_exec "settings put global nr_dual_connectivity_mode 1" 2>/dev/null
arc_exec "setprop persist.radio.5g_enable 1" 2>/dev/null
arc_exec "setprop persist.vendor.radio.5g_enable 1" 2>/dev/null
arc_log_info "$TAG" 'Mobile 5G NSA/SA: ativado.'