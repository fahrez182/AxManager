#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='MOB-VOIP'
arc_exec "settings put global wifi_calling_mode 2" 2>/dev/null
arc_exec "settings put global volte_enabled 1" 2>/dev/null
arc_exec "setprop persist.dbg.volte_avail_ovr 1" 2>/dev/null
arc_log_info "$TAG" 'Mobile VoIP/VoLTE: ativado.'