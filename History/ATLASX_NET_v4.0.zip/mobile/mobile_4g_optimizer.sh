#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='MOB-4G'
arc_exec "settings put global preferred_network_mode 9" 2>/dev/null
arc_exec "setprop ril.net.type 9" 2>/dev/null
arc_exec "settings put global data_activity_timeout_mobile 60" 2>/dev/null
arc_log_info "$TAG" 'Mobile 4G LTE: otimizado.'