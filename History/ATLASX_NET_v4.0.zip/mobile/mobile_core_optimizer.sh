#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='MOB-CORE'
arc_exec "settings put global mobile_data 1" 2>/dev/null
arc_exec "settings put global preferred_network_mode 27" 2>/dev/null
arc_exec "settings put global lte_service_forced 1" 2>/dev/null
arc_exec "settings put global cell_on 1" 2>/dev/null
arc_exec "setprop ril.current.rat 13" 2>/dev/null
arc_log_info "$TAG" 'Mobile Core: LTE/5G prioridade máxima.'