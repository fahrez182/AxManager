#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='MOB-SIG'
arc_exec "setprop gsm.cell.id.change 1" 2>/dev/null
arc_exec "settings put global signal_strength_improve 1" 2>/dev/null
arc_exec "setprop ril.fast.dormancy.rule 1" 2>/dev/null
arc_log_info "$TAG" 'Mobile Signal: otimizado.'