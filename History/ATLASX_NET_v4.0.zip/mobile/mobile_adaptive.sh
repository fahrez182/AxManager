#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='MOB-ADAPT'
NET_TYPE=$(cat "$MODPATH/data/net_type.txt" 2>/dev/null || echo UNKNOWN)
case "$NET_TYPE" in
    5G) sh "$MODPATH/mobile/mobile_5g_optimizer.sh" 2>/dev/null ;;
    4G) sh "$MODPATH/mobile/mobile_4g_optimizer.sh" 2>/dev/null ;;
esac
sh "$MODPATH/mobile/mobile_data_always_on.sh" 2>/dev/null
arc_log_info "$TAG" "Mobile adaptive: tipo=$NET_TYPE"
