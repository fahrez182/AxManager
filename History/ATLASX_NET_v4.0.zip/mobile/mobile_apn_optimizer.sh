#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='MOB-APN'
arc_exec "settings put global apn_edit_enabled 1" 2>/dev/null
arc_exec "setprop net.gprs.data-stall-recovery-action 3" 2>/dev/null
arc_log_info "$TAG" 'Mobile APN: modo performance.'