#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='DNS-CF'
arc_exec "setprop net.dns1 1.1.1.1" 2>/dev/null
arc_exec "setprop net.dns2 1.0.0.1" 2>/dev/null
arc_exec "settings put global private_dns_specifier 1dot1dot1dot1.cloudflare-dns.com" 2>/dev/null
arc_log_info "$TAG" 'DNS: Cloudflare 1.1.1.1 + 1.0.0.1'