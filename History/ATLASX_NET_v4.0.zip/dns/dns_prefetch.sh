#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='DNS-PREFETCH'
arc_log_info "$TAG" 'DNS prefetch: iniciando...'
for domain in google.com youtube.com instagram.com tiktok.com netflix.com     cloudflare.com garena.com activision.com discord.com whatsapp.net     telegram.org spotify.com twitch.tv level.io; do
    nslookup "$domain" 1.1.1.1 >/dev/null 2>&1 &
done
wait
arc_log_info "$TAG" 'DNS prefetch: concluído.'