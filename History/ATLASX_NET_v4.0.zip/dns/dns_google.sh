#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='DNS-GOOG'
arc_exec "setprop net.dns1 8.8.8.8" 2>/dev/null
arc_exec "setprop net.dns2 8.8.4.4" 2>/dev/null
arc_log_info "$TAG" 'DNS: Google 8.8.8.8'