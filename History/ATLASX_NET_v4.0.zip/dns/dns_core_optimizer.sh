#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='DNS-CORE'
arc_exec "setprop net.dns1 1.1.1.1" 2>/dev/null
arc_exec "setprop net.dns2 1.0.0.1" 2>/dev/null
arc_exec "setprop net.dns3 8.8.8.8" 2>/dev/null
arc_exec "setprop net.dns4 8.8.4.4" 2>/dev/null
arc_exec "setprop net.rmnet0.dns1 1.1.1.1" 2>/dev/null
arc_exec "setprop net.rmnet0.dns2 1.0.0.1" 2>/dev/null
arc_log_info "$TAG" 'DNS Core: Cloudflare+Google definidos.'