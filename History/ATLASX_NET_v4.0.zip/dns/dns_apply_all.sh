#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='DNS-ALL'
arc_log_info "$TAG" '=== DNS Suite: ALL ==='
sh "$MODPATH/dns/dns_core_optimizer.sh"; sleep 1
sh "$MODPATH/dns/dns_private_doh.sh"  ; sleep 1
sh "$MODPATH/dns/dns_prefetch.sh"     ; sleep 1
sh "$MODPATH/dns/dns_ttl_optimizer.sh"; sleep 1
arc_log_info "$TAG" '=== DNS Suite: DONE ==='