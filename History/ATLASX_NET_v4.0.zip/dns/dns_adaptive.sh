#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='DNS-ADAPT'
STATE=$(cat "$MODPATH/data/current_state.txt" 2>/dev/null || echo BROWSING)
case "$STATE" in
    GAMING)    sh "$MODPATH/dns/dns_gaming_servers.sh" 2>/dev/null ;;
    STREAMING) sh "$MODPATH/dns/dns_streaming_servers.sh" 2>/dev/null ;;
    VOIP)      sh "$MODPATH/dns/dns_core_optimizer.sh" 2>/dev/null ;;
    *)         sh "$MODPATH/dns/dns_core_optimizer.sh" 2>/dev/null ;;
esac
arc_log_info "$TAG" "DNS adaptive: estado=$STATE"
