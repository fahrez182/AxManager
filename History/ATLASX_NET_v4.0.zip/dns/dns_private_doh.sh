#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='DNS-DOH'
SDK=$(getprop ro.build.version.sdk 2>/dev/null || echo 0)
if [ "$SDK" -ge 28 ] 2>/dev/null; then
    arc_exec "settings put global private_dns_mode hostname" 2>/dev/null
    arc_exec "settings put global private_dns_specifier 1dot1dot1dot1.cloudflare-dns.com" 2>/dev/null
    arc_log_info "$TAG" 'DNS-over-HTTPS: Cloudflare (1.1.1.1) ativo.'
else
    arc_log_info "$TAG" 'DNS-over-HTTPS: SDK < 28, fallback para DNS padrão.'
fi