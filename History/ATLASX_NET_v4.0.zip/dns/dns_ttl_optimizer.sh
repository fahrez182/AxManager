#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='DNS-TTL'
arc_exec "settings put global dns_tls_hostname 1dot1dot1dot1.cloudflare-dns.com" 2>/dev/null
arc_exec "sysctl -w net.ipv4.route.gc_timeout=60" 2>/dev/null
arc_log_info "$TAG" 'DNS TTL: otimizado.'