#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='DNS-CHK'
local MS; MS=$(nslookup google.com 1.1.1.1 2>/dev/null | awk '/time/{print $NF}')
[ -z "$MS" ] && arc_log_warn "$TAG" 'DNS 1.1.1.1: timeout — fallback' && arc_exec "setprop net.dns1 8.8.8.8" 2>/dev/null
arc_log_info "$TAG" "DNS check: ${MS:-ok}"
