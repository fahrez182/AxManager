#!/system/bin/sh
# ATLASX ARC — RESOURCE LOCK (mutex sem root)
# arc_lock_acquire RESOURCE OWNER  → 0=ok, 1=locked by other
# arc_lock_release RESOURCE OWNER
# arc_lock_owner   RESOURCE        → imprime dono atual
LOCK_DIR="${MODPATH:-/data/local/tmp/atlasx}/locks"
mkdir -p "$LOCK_DIR" 2>/dev/null

arc_lock_acquire() {
    local RES="$1" OWNER="$2" LOCK="$LOCK_DIR/${1}.lock"
    if [ -f "$LOCK" ]; then
        local CUR; CUR=$(cat "$LOCK" 2>/dev/null)
        [ "$CUR" = "$OWNER" ] && return 0  # já é nosso
        return 1  # outro dono
    fi
    echo "$OWNER" > "$LOCK" 2>/dev/null && return 0 || return 1
}

arc_lock_release() {
    local RES="$1" OWNER="$2" LOCK="$LOCK_DIR/${1}.lock"
    local CUR; CUR=$(cat "$LOCK" 2>/dev/null)
    [ "$CUR" = "$OWNER" ] && rm -f "$LOCK" 2>/dev/null
}

arc_lock_owner() {
    cat "$LOCK_DIR/${1}.lock" 2>/dev/null || echo ""
}

arc_lock_release_stale() {
    # Limpa locks com mais de 60s (processo morreu sem liberar)
    local LOCK_DIR="${MODPATH:-/data/local/tmp/atlasx}/locks"
    local NOW; NOW=$(date '+%s' 2>/dev/null || echo 0)
    for lk in "$LOCK_DIR"/*.lock; do
        [ -f "$lk" ] || continue
        local MTIME; MTIME=$(stat -c '%Y' "$lk" 2>/dev/null || echo 0)
        local AGE=$(( NOW - MTIME ))
        [ "$AGE" -gt 60 ] && rm -f "$lk" 2>/dev/null
    done
}
