#!/system/bin/sh
# ATLASX NET — NET CONFLICT MANAGER
# Garante que engines de rede não conflitem no mesmo recurso.
# @interval: 45s
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
. "$MODPATH/runtime/resource_lock.sh"
TAG="NET-CONFLICT"; CONFLICT_LOG="$MODPATH/logs/net_conflict.log"; mkdir -p "$MODPATH/logs"
arc_log_info "$TAG" "Net Conflict Manager started"
_check_dns_conflict() {
    local DNS; DNS=$(arc_exec "settings get global private_dns_specifier" 2>/dev/null || echo "?")
    local OWNER; OWNER=$(arc_lock_owner "dns_config")
    arc_log_info "$TAG" "DNS=$DNS owner=$OWNER"
}
_check_tcp_conflict() {
    local CONG; CONG=$(sysctl -n net.ipv4.tcp_congestion_control 2>/dev/null || echo "?")
    arc_log_info "$TAG" "TCP congestion=$CONG"
}
arc_lock_release_stale
while true; do
    _check_dns_conflict; _check_tcp_conflict; sleep 45
done
