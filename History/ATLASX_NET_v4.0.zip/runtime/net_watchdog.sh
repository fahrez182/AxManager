#!/system/bin/sh
# ATLASX NET — NET WATCHDOG
# Monitora conectividade. Aciona recuperação automática em caso de falha.
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG="NET-WATCH"; INTERVAL=30; FAIL_COUNT=0; FAIL_THRESHOLD=3
arc_log_info "$TAG" "Net Watchdog started"
while true; do
    sleep "$INTERVAL"
    if ping -c 1 -W 3 1.1.1.1 >/dev/null 2>&1; then
        FAIL_COUNT=0
    else
        FAIL_COUNT=$(( FAIL_COUNT + 1 ))
        arc_log_warn "$TAG" "Ping falhou ($FAIL_COUNT/$FAIL_THRESHOLD)"
        if [ "$FAIL_COUNT" -ge "$FAIL_THRESHOLD" ]; then
            arc_log_warn "$TAG" "Conectividade perdida — recovery"
            sh "$MODPATH/stability/connection_recovery_engine.sh" 2>/dev/null
            FAIL_COUNT=0
        fi
    fi
done
