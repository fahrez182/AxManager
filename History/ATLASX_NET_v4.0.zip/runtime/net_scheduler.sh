#!/system/bin/sh
# ATLASX NET — NET SCHEDULER (Loop Central Único)
# Agenda engines de rede por estado + timer. Sem conflitos.
# ADB/Shizuku compatible.
MODPATH="${MODPATH:-${0%/*}/..}"
. "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"; . "$MODPATH/runtime/resource_lock.sh"
TAG="NET-SCHED"; TICK=10; TICK_COUNT=0
FREQ_FAST=3   # ~30s
FREQ_MED=9    # ~90s
FREQ_SLOW=24  # ~240s
FREQ_IDLE=54  # ~540s
STATE=""; PREV_STATE=""
arc_log_info "$TAG" "=== NET SCHEDULER STARTED (tick=${TICK}s) ==="

_read_state() { STATE=$(cat "$MODPATH/data/current_state.txt" 2>/dev/null || echo "BROWSING"); }
_allowed_in() { for s in "$@"; do [ "$STATE" = "$s" ] && return 0; done; return 1; }
_blocked_in()  { for s in "$@"; do [ "$STATE" = "$s" ] && return 1; done; return 0; }

_task_ping_guard() {
    _blocked_in SCREEN_OFF || return
    sh "$MODPATH/gaming_ping/ping_guardian.sh" 2>/dev/null
}
_task_dns_fast() {
    _blocked_in SCREEN_OFF || return
    sh "$MODPATH/dns/dns_fast_check.sh" 2>/dev/null
}
_task_iface_check() { sh "$MODPATH/core/network_detector.sh" 2>/dev/null; }
_task_tcp_tune() {
    arc_lock_acquire "tcp_config" "net_scheduler" || return
    STATE_NOW=$(cat "$MODPATH/data/current_state.txt" 2>/dev/null || echo "BROWSING")
    case "$STATE_NOW" in
        GAMING)    sh "$MODPATH/tcp_gaming/tcp_gaming_apply_all.sh" 2>/dev/null ;;
        STREAMING) sh "$MODPATH/tcp_streaming/tcp_streaming_apply_all.sh" 2>/dev/null ;;
        VOIP)      sh "$MODPATH/voip/voip_tcp_optimizer.sh" 2>/dev/null ;;
        *)         sh "$MODPATH/tcp/tcp_apply_all.sh" 2>/dev/null ;;
    esac
    arc_lock_release "tcp_config" "net_scheduler"
}
_task_dns_tune() {
    arc_lock_acquire "dns_config" "net_scheduler" || return
    sh "$MODPATH/dns/dns_adaptive.sh" 2>/dev/null
    arc_lock_release "dns_config" "net_scheduler"
}
_task_qos_tune() { sh "$MODPATH/qos/qos_adaptive.sh" 2>/dev/null; }
_task_bg_control() {
    _blocked_in GAMING VOIP || return
    sh "$MODPATH/background/bg_data_manager.sh" 2>/dev/null
}
_task_wifi_tune() {
    local T; T=$(cat "$MODPATH/data/net_type.txt" 2>/dev/null || echo "")
    [ "$T" = "WIFI" ] && sh "$MODPATH/wifi/wifi_adaptive.sh" 2>/dev/null
}
_task_mobile_tune() {
    local T; T=$(cat "$MODPATH/data/net_type.txt" 2>/dev/null || echo "")
    { [ "$T" = "4G" ] || [ "$T" = "5G" ]; } && sh "$MODPATH/mobile/mobile_adaptive.sh" 2>/dev/null
}
_task_analytics() { _allowed_in SCREEN_OFF BROWSING || return; sh "$MODPATH/analytics/net_analytics.sh" 2>/dev/null; }
_task_health()    { sh "$MODPATH/monitoring/net_health_check.sh" 2>/dev/null; }
_task_stability() { sh "$MODPATH/stability/connection_keeper.sh" 2>/dev/null; }
_task_persist()   { sh "$MODPATH/arc_net_persistence/net_drift_corrector.sh" 2>/dev/null; }

_on_enter_gaming()    { sh "$MODPATH/profiles/gaming_profile.sh" 2>/dev/null &; sh "$MODPATH/gaming_ping/gaming_ping_apply_all.sh" 2>/dev/null &; }
_on_exit_gaming()     { sh "$MODPATH/profiles/browsing_profile.sh" 2>/dev/null; }
_on_enter_streaming() { sh "$MODPATH/profiles/streaming_profile.sh" 2>/dev/null &; }
_on_enter_voip()      { sh "$MODPATH/profiles/voip_profile.sh" 2>/dev/null &; }
_on_screen_off()      { sh "$MODPATH/profiles/idle_profile.sh" 2>/dev/null; }

while true; do
    TICK_COUNT=$(( TICK_COUNT + 1 ))
    _read_state
    if [ "$STATE" != "$PREV_STATE" ]; then
        case "$STATE" in GAMING) _on_enter_gaming ;; STREAMING) _on_enter_streaming ;; VOIP) _on_enter_voip ;; SCREEN_OFF) _on_screen_off ;; esac
        case "$PREV_STATE" in GAMING) _on_exit_gaming ;; esac
        PREV_STATE="$STATE"
    fi
    [ $(( TICK_COUNT % FREQ_FAST )) -eq 0 ] 2>/dev/null && { _task_ping_guard &; _task_dns_fast &; _task_iface_check; }
    [ $(( TICK_COUNT % FREQ_MED  )) -eq 0 ] 2>/dev/null && { _task_tcp_tune; _task_dns_tune; _task_qos_tune; _task_wifi_tune; _task_mobile_tune; _task_bg_control; }
    [ $(( TICK_COUNT % FREQ_SLOW )) -eq 0 ] 2>/dev/null && { _task_analytics &; _task_health; _task_stability; }
    [ $(( TICK_COUNT % FREQ_IDLE )) -eq 0 ] 2>/dev/null && { _task_persist; TICK_COUNT=0; }
    sleep "$TICK"
done
