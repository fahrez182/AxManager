#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='ARC-ADPT-T'
PREV_T=$(cat "$MODPATH/data/prev_net_type.txt" 2>/dev/null||echo '')
CURR_T=$(cat "$MODPATH/data/net_type.txt" 2>/dev/null||echo UNKNOWN)
[ "$CURR_T" != "$PREV_T" ] && {
    sh "$MODPATH/smart_net/smart_profile_selector.sh" 2>/dev/null
    echo "$CURR_T" > "$MODPATH/data/prev_net_type.txt"
    arc_log_info "$TAG" "Net type adapted: $PREV_T→$CURR_T"
}