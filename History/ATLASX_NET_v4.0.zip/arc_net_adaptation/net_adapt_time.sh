#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='ARC-ADPT-TI'
sh "$MODPATH/adaptive/adaptive_time.sh" 2>/dev/null
arc_log_info "$TAG" 'Time adaptation: done.'