#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='ARC-ADPT-S'
PREV=$(cat "$MODPATH/data/prev_state.txt" 2>/dev/null||echo '')
CURR=$(cat "$MODPATH/data/current_state.txt" 2>/dev/null||echo BROWSING)
[ "$CURR" != "$PREV" ] && {
    sh "$MODPATH/smart_net/smart_profile_selector.sh" 2>/dev/null
    echo "$CURR" > "$MODPATH/data/prev_state.txt"
    arc_log_info "$TAG" "State adapted: $PREV→$CURR"
}