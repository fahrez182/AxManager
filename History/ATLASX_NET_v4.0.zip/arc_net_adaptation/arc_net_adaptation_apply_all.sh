#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='ARCADPT-ALL'
arc_log_info "$TAG" '=== ARC Net Adaptation: ALL ==='
for s in net_adapt_state_change net_adapt_type_change net_adapt_quality net_adapt_thermal net_adapt_battery net_adapt_time; do
    sh "$MODPATH/arc_net_adaptation/${s}.sh" 2>/dev/null; sleep 1
done
arc_log_info "$TAG" '=== ARC Net Adaptation: DONE ==='