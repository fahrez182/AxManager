#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='ARC-ADPT-SM'
INTERVAL=90
while true; do sleep "$INTERVAL"
    sh "$MODPATH/arc_net_adaptation/net_adapt_quality.sh" 2>/dev/null
    sh "$MODPATH/arc_net_adaptation/net_adapt_thermal.sh" 2>/dev/null
done