#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='ARC-ADPT-Q'
SCORE=$(cat "$MODPATH/data/net_quality.txt" 2>/dev/null||echo GOOD)
case "$SCORE" in
    BAD)  sh "$MODPATH/stability/connection_recovery_engine.sh" 2>/dev/null ;;
    FAIR) sh "$MODPATH/dns_advanced/dns_auto_benchmark.sh" 2>/dev/null ;;
esac
arc_log_info "$TAG" "Quality adapt: $SCORE"