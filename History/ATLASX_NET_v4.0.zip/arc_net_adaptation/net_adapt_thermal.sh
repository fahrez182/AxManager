#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='ARC-ADPT-TH'
sh "$MODPATH/adaptive/adaptive_thermal.sh" 2>/dev/null
arc_log_info "$TAG" 'Thermal adaptation: done.'