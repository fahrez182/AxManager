#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='ARC-ADPT-B'
sh "$MODPATH/adaptive/adaptive_battery.sh" 2>/dev/null
arc_log_info "$TAG" 'Battery adaptation: done.'