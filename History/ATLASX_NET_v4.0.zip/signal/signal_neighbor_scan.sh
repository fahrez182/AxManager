#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='SIG-NEIGH'
arc_exec "settings put global cell_scan_period 60" 2>/dev/null
arc_exec "setprop persist.radio.scan_pci 1" 2>/dev/null
arc_log_info "$TAG" 'Signal neighbor scan: 60s.'