#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='SIG-CELL'
arc_exec "setprop ril.cell.network.select 1" 2>/dev/null
arc_exec "settings put global cell_id_enabled 1" 2>/dev/null
arc_log_info "$TAG" 'Signal cell select: automático.'