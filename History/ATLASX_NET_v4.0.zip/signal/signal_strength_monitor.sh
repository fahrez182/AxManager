#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='SIG-MON'
INTERVAL=60
arc_log_info "$TAG" 'Signal strength monitor started'
while true; do
    sleep "$INTERVAL"
    RSSI=$(dumpsys telephony.registry 2>/dev/null | grep -m1 'mSignalStrength' | grep -oE 'ss=[0-9-]+' | head -1 | tr -d 'ss=')
    [ -n "$RSSI" ] && echo "$RSSI" > "$MODPATH/data/signal_rssi.txt"
    arc_log_info "$TAG" "RSSI: ${RSSI:-?} dBm"
done