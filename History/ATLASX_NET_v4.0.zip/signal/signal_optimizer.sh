#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='SIG-OPT'
arc_exec "settings put global signal_strength_improve 1" 2>/dev/null
arc_exec "setprop gsm.current.prefer.operator.plmn ''" 2>/dev/null
arc_log_info "$TAG" 'Signal optimizer: done.'