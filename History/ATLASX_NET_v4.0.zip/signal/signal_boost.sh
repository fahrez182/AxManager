#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='SIG-BOOST'
arc_exec "setprop persist.radio.lte_vrte_limited 0" 2>/dev/null
arc_exec "settings put global signal_boost 1" 2>/dev/null
arc_log_info "$TAG" 'Signal boost: ativo.'