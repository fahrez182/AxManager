#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='SIG-TRACK'
arc_exec "settings put global nr_signal_strength_improve 1" 2>/dev/null
arc_exec "settings put global lte_signal_threshold 4" 2>/dev/null
arc_log_info "$TAG" 'Signal tracker: NR+LTE ativo.'