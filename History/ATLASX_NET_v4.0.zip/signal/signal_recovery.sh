#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='SIG-REC'
arc_exec "settings put global cell_on 1" 2>/dev/null
arc_exec "setprop ril.current.rat 13" 2>/dev/null
arc_log_info "$TAG" 'Signal recovery: cell_on=1.'