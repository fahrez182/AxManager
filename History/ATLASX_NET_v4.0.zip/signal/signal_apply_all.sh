#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='SIG-ALL'
arc_log_info "$TAG" '=== Signal Suite: ALL ==='
for s in signal_optimizer signal_boost signal_tracker signal_cell_select signal_recovery; do sh "$MODPATH/signal/${s}.sh" 2>/dev/null; sleep 1; done
arc_log_info "$TAG" '=== Signal Suite: DONE ==='