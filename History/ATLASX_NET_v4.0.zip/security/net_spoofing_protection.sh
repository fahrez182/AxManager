#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='SEC-SPOOF'
arc_exec "sysctl -w net.ipv4.conf.all.rp_filter=1" 2>/dev/null
arc_exec "sysctl -w net.ipv4.conf.all.log_martians=1" 2>/dev/null
arc_log_info "$TAG" 'Spoofing protection: rp_filter + martians log.'