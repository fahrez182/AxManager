#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='SEC-CORE'
arc_exec "sysctl -w net.ipv4.conf.all.rp_filter=1" 2>/dev/null
arc_exec "sysctl -w net.ipv4.conf.default.rp_filter=1" 2>/dev/null
arc_exec "sysctl -w net.ipv4.icmp_echo_ignore_broadcasts=1" 2>/dev/null
arc_exec "sysctl -w net.ipv4.icmp_ignore_bogus_error_responses=1" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_syncookies=1" 2>/dev/null
arc_log_info "$TAG" 'Net Security: rp_filter + syncookies.'