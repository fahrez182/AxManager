#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='SEC-DNS'
arc_exec "settings put global private_dns_mode hostname" 2>/dev/null
arc_exec "settings put global private_dns_specifier 1dot1dot1dot1.cloudflare-dns.com" 2>/dev/null
arc_log_info "$TAG" 'DNS Security: DoT Cloudflare.'