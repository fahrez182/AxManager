#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='SEC-SSL'
arc_exec "setprop persist.security.ssl.verify 1" 2>/dev/null
arc_exec "settings put global captive_portal_https_url https://connectivitycheck.gstatic.com/generate_204" 2>/dev/null
arc_log_info "$TAG" 'SSL Pinning: Google connectivity check.'