#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='SEC-TEL'
arc_exec "settings put global usage_stats_cloud 0" 2>/dev/null
arc_exec "settings put global send_action_app_error 0" 2>/dev/null
arc_exec "settings put secure send_security_reports 0" 2>/dev/null
arc_log_info "$TAG" 'Telemetry reducer: analytics off.'