#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='SEC-DDOS'
arc_exec "sysctl -w net.ipv4.tcp_max_syn_backlog=2048" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_synack_retries=2" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_syn_retries=2" 2>/dev/null
arc_log_info "$TAG" 'Net DDoS: SYN flood protection.'