#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='SEC-PRIV'
arc_exec "settings put global private_dns_mode hostname" 2>/dev/null
arc_exec "settings put global captive_portal_mode 0" 2>/dev/null
arc_exec "settings put secure connectivity_samples 0" 2>/dev/null
arc_log_info "$TAG" 'Net Privacy: DoT + captive portal off.'