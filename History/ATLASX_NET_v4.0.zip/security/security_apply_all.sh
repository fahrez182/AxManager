#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='SEC-ALL'
arc_log_info "$TAG" '=== Security Suite: ALL ==='
for s in net_security_core net_ddos_protection net_firewall_optimizer net_dns_security net_spoofing_protection net_privacy_optimizer net_telemetry_reducer net_ip_spoofing_block; do sh "$MODPATH/security/${s}.sh" 2>/dev/null; sleep 1; done
arc_log_info "$TAG" '=== Security Suite: DONE ==='