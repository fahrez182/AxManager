#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='SEC-FW'
arc_exec "settings put global captive_portal_mode 0" 2>/dev/null
arc_exec "sysctl -w net.ipv4.conf.all.send_redirects=0" 2>/dev/null
arc_exec "sysctl -w net.ipv4.conf.all.accept_redirects=0" 2>/dev/null
arc_log_info "$TAG" 'Net Firewall: redirects off, captive portal off.'