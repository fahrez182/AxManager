#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='DNSA-ALL'
arc_log_info "$TAG" '=== DNS Advanced: ALL ==='
sh "$MODPATH/dns_advanced/dns_auto_benchmark.sh" ; sleep 2
sh "$MODPATH/dns_advanced/dns_cache_warmer.sh"   ; sleep 1
sh "$MODPATH/dns_advanced/dns_failover.sh"        ; sleep 1
arc_log_info "$TAG" '=== DNS Advanced: DONE ==='