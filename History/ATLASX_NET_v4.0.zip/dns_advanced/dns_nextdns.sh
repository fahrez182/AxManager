#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='DNS-NEXT'
arc_exec "settings put global private_dns_mode hostname" 2>/dev/null
arc_exec "settings put global private_dns_specifier dns.nextdns.io" 2>/dev/null
arc_log_info "$TAG" 'DNS: NextDNS DoH'