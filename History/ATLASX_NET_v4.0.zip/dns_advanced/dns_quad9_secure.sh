#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='DNS-Q9'
arc_exec "setprop net.dns1 9.9.9.9" 2>/dev/null
arc_exec "setprop net.dns2 149.112.112.112" 2>/dev/null
arc_log_info "$TAG" 'DNS: Quad9 (filtro de malware)'