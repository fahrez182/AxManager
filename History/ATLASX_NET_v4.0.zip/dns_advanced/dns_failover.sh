#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='DNS-FAIL'
if ! ping -c 1 -W 2 1.1.1.1 >/dev/null 2>&1; then
    arc_log_warn "$TAG" '1.1.1.1 unreachable — failover para 8.8.8.8'
    arc_exec "setprop net.dns1 8.8.8.8" 2>/dev/null
    arc_exec "setprop net.dns2 9.9.9.9" 2>/dev/null
fi