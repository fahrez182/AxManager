#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='DNS-OPEN'
arc_exec "setprop net.dns1 208.67.222.222" 2>/dev/null
arc_exec "setprop net.dns2 208.67.220.220" 2>/dev/null
arc_log_info "$TAG" 'DNS: OpenDNS'