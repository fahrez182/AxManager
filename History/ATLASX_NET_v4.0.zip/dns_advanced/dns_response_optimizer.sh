#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='DNS-RESP'
arc_exec "sysctl -w net.ipv4.route.gc_interval=60" 2>/dev/null
arc_exec "sysctl -w net.ipv4.route.gc_timeout=60" 2>/dev/null
arc_log_info "$TAG" 'DNS response: route cache otimizado.'