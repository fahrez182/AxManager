#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='DNS-SPLIT'
NET_TYPE=$(cat "$MODPATH/data/net_type.txt" 2>/dev/null || echo UNKNOWN)
case "$NET_TYPE" in
    WIFI) arc_exec "setprop net.dns1 1.1.1.1" 2>/dev/null ;;
    4G|5G) arc_exec "setprop net.dns1 8.8.8.8" 2>/dev/null ;;
esac
arc_log_info "$TAG" "DNS split: type=$NET_TYPE"
