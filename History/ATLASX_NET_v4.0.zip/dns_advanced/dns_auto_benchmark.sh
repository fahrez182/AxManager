#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='DNS-BENCH'
arc_log_info "$TAG" 'DNS benchmark iniciado...'
BEST_MS=999; BEST_DNS=""
for dns in 1.1.1.1 8.8.8.8 9.9.9.9 208.67.222.222; do
    MS=$(ping -c 2 -W 1 "$dns" 2>/dev/null | awk -F'/' '/rtt/{print int($5)}' || echo 999)
    [ "$MS" -lt "$BEST_MS" ] 2>/dev/null && { BEST_MS="$MS"; BEST_DNS="$dns"; }
done
[ -n "$BEST_DNS" ] && {
    arc_exec "setprop net.dns1 $BEST_DNS" 2>/dev/null
    echo "$BEST_DNS" > "$MODPATH/data/best_dns.txt"
    arc_log_info "$TAG" "Best DNS: $BEST_DNS (${BEST_MS}ms)"
}