#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='DNS-WARM'
arc_log_info "$TAG" 'DNS cache warmer...'
BEST=$(cat "$MODPATH/data/best_dns.txt" 2>/dev/null || echo "1.1.1.1")
for d in google.com youtube.com instagram.com tiktok.com netflix.com discord.com twitch.tv; do
    nslookup "$d" "$BEST" >/dev/null 2>&1 &
done
wait; arc_log_info "$TAG" 'DNS cache: aquecido.'