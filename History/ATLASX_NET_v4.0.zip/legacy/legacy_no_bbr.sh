#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='LEG-BBR'
arc_exec "sysctl -w net.ipv4.tcp_congestion_control=cubic" 2>/dev/null
arc_exec "sysctl -w net.core.default_qdisc=pfifo_fast" 2>/dev/null
arc_log_info "$TAG" 'Legacy: CUBIC + pfifo_fast.'