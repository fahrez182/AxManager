#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='LEG-ALL'
SDK=$(getprop ro.build.version.sdk 2>/dev/null||echo 30)
arc_log_info "$TAG" "=== Legacy NET (SDK=$SDK): ALL ==="
[ "$SDK" -lt 28 ] 2>/dev/null && sh "$MODPATH/legacy/legacy_no_bbr.sh" 2>/dev/null
sh "$MODPATH/legacy/legacy_net_base.sh" 2>/dev/null
arc_log_info "$TAG" '=== Legacy NET: DONE ==='