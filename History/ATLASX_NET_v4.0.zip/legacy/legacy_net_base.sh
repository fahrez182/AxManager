#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='LEG-BASE'
SDK=$(getprop ro.build.version.sdk 2>/dev/null||echo 21)
arc_log_info "$TAG" "Legacy NET: SDK=$SDK"
arc_exec "sysctl -w net.ipv4.tcp_fastopen=1" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_window_scaling=1" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_sack=1" 2>/dev/null
arc_log_info "$TAG" 'Legacy NET base: done.'