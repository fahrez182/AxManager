#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='LEG-2G3G'
arc_exec "sysctl -w net.ipv4.tcp_rmem='4096 32768 1048576'" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_wmem='4096 32768 1048576'" 2>/dev/null
arc_exec "setprop net.dns1 8.8.8.8" 2>/dev/null
arc_log_info "$TAG" 'Legacy 2G/3G NET: buffers reduzidos.'