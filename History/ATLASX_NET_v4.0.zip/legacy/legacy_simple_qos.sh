#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='LEG-QOS'
IFACE=$(cat "$MODPATH/data/active_iface.txt" 2>/dev/null||echo "")
[ -n "$IFACE" ] && [ "$IFACE" != "unknown" ] && tc qdisc add dev "$IFACE" root pfifo_fast 2>/dev/null
arc_log_info "$TAG" 'Legacy QoS: pfifo_fast.'