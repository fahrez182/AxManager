#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='LEG-V6'
arc_exec "sysctl -w net.ipv6.conf.all.disable_ipv6=1" 2>/dev/null
arc_exec "sysctl -w net.ipv6.conf.default.disable_ipv6=1" 2>/dev/null
arc_log_info "$TAG" 'Legacy: IPv6 desativado.'