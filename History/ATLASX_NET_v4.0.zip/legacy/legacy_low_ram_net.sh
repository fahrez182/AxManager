#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='LEG-RAM'
TOTAL=$(awk '/MemTotal/{print int($2/1024)}' /proc/meminfo 2>/dev/null||echo 2048)
arc_log_info "$TAG" "Low RAM NET: ${TOTAL}MB"
arc_exec "sysctl -w net.ipv4.tcp_rmem='4096 43690 2097152'" 2>/dev/null
arc_exec "sysctl -w net.core.rmem_max=4194304" 2>/dev/null
arc_log_info "$TAG" 'Low RAM NET buffers: conservador.'