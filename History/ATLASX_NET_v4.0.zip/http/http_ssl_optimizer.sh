#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='HTTP-SSL'
arc_exec "setprop net.ssl.session_cache_size 50" 2>/dev/null
arc_exec "setprop net.tls.resumption 1" 2>/dev/null
arc_log_info "$TAG" 'HTTP SSL: session cache + TLS resumption.'