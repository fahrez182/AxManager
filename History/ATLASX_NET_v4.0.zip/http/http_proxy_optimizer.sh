#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='HTTP-PROXY'
arc_exec "settings put global http_proxy :0" 2>/dev/null
arc_log_info "$TAG" 'HTTP Proxy: limpo (sem proxy).'