#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='HTTP2'
arc_exec "setprop net.http2.enabled 1" 2>/dev/null
arc_exec "setprop net.quic.enabled 1" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_window_scaling=1" 2>/dev/null
arc_log_info "$TAG" 'HTTP/2 + QUIC: ativado.'