#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='HTTP-CACHE'
arc_exec "setprop net.http.cache.size 67108864" 2>/dev/null
arc_exec "sysctl -w net.core.rmem_default=262144" 2>/dev/null
arc_log_info "$TAG" 'HTTP Cache: 64MB.'