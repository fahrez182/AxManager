#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='HTTP-COMP'
arc_exec "setprop net.http.accept_encoding gzip,deflate,br" 2>/dev/null
arc_log_info "$TAG" 'HTTP compression: gzip+brotli.'