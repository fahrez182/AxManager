#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='HTTP-ALL'
arc_log_info "$TAG" '=== HTTP Suite: ALL ==='
for s in http_core_optimizer http2_optimizer http3_quic_optimizer http_compression http_cache_optimizer http_ssl_optimizer http_prefetch; do sh "$MODPATH/http/${s}.sh" 2>/dev/null; sleep 1; done
arc_log_info "$TAG" '=== HTTP Suite: DONE ==='