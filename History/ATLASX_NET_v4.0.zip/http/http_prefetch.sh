#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='HTTP-PRE'
arc_exec "setprop net.prefetch.enabled 1" 2>/dev/null
arc_exec "setprop net.dns_prefetch 1" 2>/dev/null
arc_log_info "$TAG" 'HTTP Prefetch: habilitado.'