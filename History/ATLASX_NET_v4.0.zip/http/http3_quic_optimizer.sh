#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='HTTP3'
arc_exec "setprop net.quic.enabled 1" 2>/dev/null
arc_exec "setprop chromium.quic 1" 2>/dev/null
arc_exec "sysctl -w net.core.rmem_max=16777216" 2>/dev/null
arc_log_info "$TAG" 'HTTP/3 QUIC: ativado.'