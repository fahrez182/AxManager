#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='HTTP-CORE'
arc_exec "setprop net.http.keep_alive 1" 2>/dev/null
arc_exec "setprop net.http.max_connections 16" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_fastopen=3" 2>/dev/null
arc_log_info "$TAG" 'HTTP Core: keep-alive + fastopen.'