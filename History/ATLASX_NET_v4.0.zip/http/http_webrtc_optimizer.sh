#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='HTTP-WEBRTC'
arc_exec "setprop webrtc.ice.timeout 5000" 2>/dev/null
arc_exec "setprop webrtc.audio.buffer_size 960" 2>/dev/null
arc_log_info "$TAG" 'HTTP WebRTC: ICE timeout + audio buffer.'