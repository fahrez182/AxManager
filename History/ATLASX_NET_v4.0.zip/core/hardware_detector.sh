#!/system/bin/sh
# ATLASX NET — HARDWARE DETECTOR
# Detecta CPU, RAM, SoC e define perfis de rede compatíveis.
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG="HW-DETECT"
TOTAL_RAM=$(awk '/MemTotal/{print int($2/1024)}' /proc/meminfo 2>/dev/null || echo 4096)
CPUS=$(nproc 2>/dev/null || echo 4)
SOC="$ARC_SOC"
SDK="$ARC_SDK"
[ "$TOTAL_RAM" -ge 8192 ] && NET_TIER="HIGH" || { [ "$TOTAL_RAM" -ge 4096 ] && NET_TIER="MED" || NET_TIER="LOW"; }
echo "$NET_TIER" > "$MODPATH/data/net_tier.txt"
echo "$CPUS"     > "$MODPATH/data/cpu_count.txt"
echo "$SOC"      > "$MODPATH/data/soc_model.txt"
arc_log_info "$TAG" "RAM=${TOTAL_RAM}MB CPUS=$CPUS SOC=$SOC TIER=$NET_TIER SDK=$SDK"
