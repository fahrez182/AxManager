#!/system/bin/sh
# ATLASX NET — NETWORK DETECTOR
# Detecta interface ativa, tipo de conexão (WiFi/4G/5G), qualidade.
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG="NET-DETECT"
_detect_iface() {
    local iface; iface=$(ip route show default 2>/dev/null | awk '/default/{print $5}' | head -1)
    [ -z "$iface" ] && iface=$(ip route 2>/dev/null | awk '/^default/{print $5}' | head -1)
    echo "${iface:-unknown}"
}
_detect_net_type() {
    local iface="$1"
    case "$iface" in
        wlan*|wifi*|ap*) echo "WIFI" ;;
        rmnet*|ccmni*|data*) 
            local gen; gen=$(getprop gsm.network.type 2>/dev/null || echo "")
            echo "$gen" | grep -qi "5G" && echo "5G" || echo "4G"
            ;;
        eth*) echo "ETH" ;;
        *) echo "UNKNOWN" ;;
    esac
}
IFACE=$(_detect_iface)
NET_TYPE=$(_detect_net_type "$IFACE")
echo "$IFACE"    > "$MODPATH/data/active_iface.txt"
echo "$NET_TYPE" > "$MODPATH/data/net_type.txt"
arc_log_info "$TAG" "Iface=$IFACE Type=$NET_TYPE"
