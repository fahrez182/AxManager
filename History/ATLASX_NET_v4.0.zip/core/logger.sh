#!/system/bin/sh
  # @priority: CRITICAL
  # @category: SYSTEM
  # @interval: ONCE
  # @impact: LOW
  # ==============================================================================
  # ATLASX ARC - LOGGER (core/logger.sh)
  # Sistema de log centralizado com rotação automática e níveis de severidade.
  # ==============================================================================

  _ARC_LOG_DIR="${MODPATH:-/data/local/tmp/atlasx-arc}/logs"
  _ARC_LOG_FILE="$_ARC_LOG_DIR/system.log"
  _ARC_LOG_MAX_BYTES=2097152  # 2MB

  mkdir -p "$_ARC_LOG_DIR" 2>/dev/null

  arc_log() {
      local tag="${1:-ARC}" msg="$2" level="${3:-INFO}"
      local line="[$(date '+%Y-%m-%d %H:%M:%S')] [$level] [$tag] $msg"
      echo "$line" >> "$_ARC_LOG_FILE"
      if [ -f "$_ARC_LOG_FILE" ]; then
          local size; size=$(wc -c < "$_ARC_LOG_FILE" 2>/dev/null || echo 0)
          if [ "$size" -gt "$_ARC_LOG_MAX_BYTES" ]; then
              tail -n 1000 "$_ARC_LOG_FILE" > "${_ARC_LOG_FILE}.tmp" 2>/dev/null
              mv "${_ARC_LOG_FILE}.tmp" "$_ARC_LOG_FILE" 2>/dev/null
          fi
      fi
  }

  arc_log_info()  { arc_log "$1" "$2" "INFO"; }
  arc_log_warn()  { arc_log "$1" "$2" "WARN"; }
  arc_log_error() { arc_log "$1" "$2" "ERROR"; }
  arc_log_debug() { arc_log "$1" "$2" "DEBUG"; }
  