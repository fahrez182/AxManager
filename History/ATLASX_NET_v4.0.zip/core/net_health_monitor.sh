#!/system/bin/sh
# ATLASX NET — NET HEALTH MONITOR
# Mede latência, packet loss e throughput. Salva score de rede.
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG="NET-HEALTH"; INTERVAL=60; HEALTH_LOG="$MODPATH/logs/net_health.log"
mkdir -p "$MODPATH/logs"
arc_log_info "$TAG" "Net Health Monitor started"
_ping_ms() {
    local host="$1"; local ms
    ms=$(ping -c 3 -W 2 "$host" 2>/dev/null | awk -F'/' '/rtt/{print int($5)}')
    echo "${ms:-999}"
}
_calc_score() {
    local ms="$1"; [ "$ms" -lt 20 ] && echo 100 && return
    [ "$ms" -lt 50 ] && echo 90  && return
    [ "$ms" -lt 100 ] && echo 75 && return
    [ "$ms" -lt 200 ] && echo 50 && return
    echo 25
}
while true; do
    sleep "$INTERVAL"
    local IFACE; IFACE=$(cat "$MODPATH/data/active_iface.txt" 2>/dev/null || echo "")
    local GW; GW=$(ip route show default 2>/dev/null | awk '/default/{print $3}' | head -1)
    local CF_MS; CF_MS=$(_ping_ms "1.1.1.1")
    local GW_MS; GW_MS=$(_ping_ms "${GW:-8.8.8.8}")
    local SCORE; SCORE=$(_calc_score "$CF_MS")
    echo "$SCORE" > "$MODPATH/data/net_score.txt"
    echo "$(date '+%H:%M' 2>/dev/null) cf=${CF_MS}ms gw=${GW_MS}ms score=${SCORE}" >> "$HEALTH_LOG"
    arc_log_info "$TAG" "Latência: cf=${CF_MS}ms gw=${GW_MS}ms score=${SCORE}"
    tail -200 "$HEALTH_LOG" > "${HEALTH_LOG}.tmp" 2>/dev/null && mv "${HEALTH_LOG}.tmp" "$HEALTH_LOG" 2>/dev/null
done
