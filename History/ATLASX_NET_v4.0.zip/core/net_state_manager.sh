#!/system/bin/sh
# ATLASX NET — NET STATE MANAGER
# Estados: GAMING | STREAMING | BROWSING | VOIP | IDLE | SCREEN_OFF | CHARGING
# Escreve em current_state.txt para todo o módulo.
# @interval: 6s (loop próprio)
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG="NET-STATE"
STATE_FILE="$MODPATH/data/current_state.txt"
FG_FILE="$MODPATH/data/cache_fg_pkg"
INTERVAL=6
mkdir -p "$MODPATH/data"
arc_log_info "$TAG" "Net State Manager started"

GAME_PKGS="com.dts.freefireth com.dts.freefiremax com.tencent.ig com.activision.callofduty
com.madfingergames.legends com.vng.pubgmobile com.garena.game.codm com.moonton.mlbb
com.epicgames.fortnite com.tencent.tmgp.sgame com.pearlabyss.blackdesertm
com.proximabeta.mia com.battlegroundsmobileindia.alpha"

STREAM_PKGS="com.google.android.youtube com.netflix.mediaclient com.amazon.avod.thirdpartyclient
com.disney.disneyplus com.hbo.hbonow com.plexapp.android com.twitch.android.viewer
tv.twitch.android.app com.zhiliaoapp.musically com.spotify.music com.apple.android.music"

VOIP_PKGS="com.whatsapp com.viber.voip org.telegram.messenger com.discord com.google.android.apps.meetings
com.skype.raider com.microsoft.teams"

_get_fg() {
    local FG; FG=$(arc_exec "dumpsys activity 2>/dev/null | grep mCurrentFocus | grep -oE '[a-z][a-zA-Z0-9_]+\.[a-zA-Z0-9_.]+' | head -1" 2>/dev/null || echo "")
    echo "${FG:-unknown}"; echo "${FG:-unknown}" > "$FG_FILE" 2>/dev/null
}
_in_list() { local p="$1" l="$2"; for x in $l; do [ "$p" = "$x" ] && return 0; done; return 1; }
_detect() {
    local FG; FG=$(_get_fg)
    local DISP; DISP=$(arc_exec "dumpsys power 2>/dev/null | grep -c 'Display Power: state=ON'" 2>/dev/null || echo 1)
    [ "$DISP" -eq 0 ] 2>/dev/null && echo "SCREEN_OFF" && return
    local BAT; BAT=$(cat /sys/class/power_supply/battery/capacity 2>/dev/null || echo 100)
    local PLUG; PLUG=$(cat /sys/class/power_supply/battery/status 2>/dev/null || echo "")
    [ "$PLUG" = "Charging" ] 2>/dev/null && echo "CHARGING" && return
    _in_list "$FG" "$GAME_PKGS"   && echo "GAMING"    && return
    _in_list "$FG" "$STREAM_PKGS" && echo "STREAMING" && return
    _in_list "$FG" "$VOIP_PKGS"   && echo "VOIP"      && return
    echo "BROWSING"
}
PREV=""
while true; do
    NEW=$(_detect)
    [ "$NEW" != "$PREV" ] && { arc_log_info "$TAG" "$PREV→$NEW"; echo "$NEW" > "$STATE_FILE"; PREV="$NEW"; }
    sleep "$INTERVAL"
done
