#!/system/bin/sh
# ATLASX NET — INTERFACE MANAGER
# Gerencia interfaces de rede, detecta troca (WiFi↔4G) e adapta tweaks.
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG="IFACE-MGR"; INTERVAL=15
arc_log_info "$TAG" "Interface Manager started"
PREV_IFACE=""
while true; do
    sleep "$INTERVAL"
    sh "$MODPATH/core/network_detector.sh" 2>/dev/null
    IFACE=$(cat "$MODPATH/data/active_iface.txt" 2>/dev/null || echo "unknown")
    NET_TYPE=$(cat "$MODPATH/data/net_type.txt" 2>/dev/null || echo "UNKNOWN")
    if [ "$IFACE" != "$PREV_IFACE" ]; then
        arc_log_info "$TAG" "Interface mudou: $PREV_IFACE→$IFACE ($NET_TYPE)"
        sh "$MODPATH/profiles/${NET_TYPE,,}_profile.sh" 2>/dev/null || sh "$MODPATH/profiles/browsing_profile.sh" 2>/dev/null
        PREV_IFACE="$IFACE"
    fi
done
