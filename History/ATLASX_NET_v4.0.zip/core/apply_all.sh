#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
arc_log_info "CORE-ALL" "=== Core: ALL ==="
sh "$MODPATH/core/hardware_detector.sh"  ; sleep 1
sh "$MODPATH/core/network_detector.sh"   ; sleep 1
arc_log_info "CORE-ALL" "=== Core: DONE ==="
