#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='ARC-DNS-C'
DNS=$(getprop net.dns1 2>/dev/null||echo '')
[ -z "$DNS" ] && { arc_exec "setprop net.dns1 1.1.1.1" 2>/dev/null; arc_log_warn "$TAG" 'DNS: corrigido'; }
arc_log_info "$TAG" "DNS consistency: $DNS"