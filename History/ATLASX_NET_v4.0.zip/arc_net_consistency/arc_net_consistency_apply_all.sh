#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='ARCCON-ALL'
arc_log_info "$TAG" '=== ARC Net Consistency: ALL ==='
for s in net_consistency_check net_tcp_consistency net_dns_consistency net_wifi_consistency net_profile_consistency; do
    sh "$MODPATH/arc_net_consistency/${s}.sh" 2>/dev/null; sleep 1
done
arc_log_info "$TAG" '=== ARC Net Consistency: DONE ==='