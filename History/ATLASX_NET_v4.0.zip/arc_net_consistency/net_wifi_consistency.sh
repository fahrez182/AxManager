#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='ARC-WIFI-C'
NET=$(cat "$MODPATH/data/net_type.txt" 2>/dev/null||echo UNKNOWN)
[ "$NET" = 'WIFI' ] && arc_exec "settings put system wifi_sleep_policy 2" 2>/dev/null
arc_log_info "$TAG" "WiFi consistency: type=$NET"