#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='ARC-BOOT'
sh "$MODPATH/core/hardware_detector.sh" 2>/dev/null
sh "$MODPATH/core/network_detector.sh" 2>/dev/null
sh "$MODPATH/brands/brand_router.sh" 2>/dev/null
arc_log_info "$TAG" 'Boot recheck: done.'