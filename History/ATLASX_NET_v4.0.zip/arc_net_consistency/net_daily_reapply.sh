#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='ARC-DAILY'
sh "$MODPATH/tcp/tcp_apply_all.sh" 2>/dev/null; sleep 2
sh "$MODPATH/dns/dns_apply_all.sh" 2>/dev/null; sleep 2
sh "$MODPATH/kernel_net/kernel_net_apply_all.sh" 2>/dev/null
arc_log_info "$TAG" 'Daily reapply: done.'