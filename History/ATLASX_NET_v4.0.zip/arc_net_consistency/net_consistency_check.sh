#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='ARC-CONS'
CONG=$(sysctl -n net.ipv4.tcp_congestion_control 2>/dev/null||echo ?)
KA=$(sysctl -n net.ipv4.tcp_keepalive_time 2>/dev/null||echo ?)
DNS=$(getprop net.dns1 2>/dev/null||echo ?)
arc_log_info "$TAG" "Consistency: cong=$CONG keepalive=${KA}s dns=$DNS"