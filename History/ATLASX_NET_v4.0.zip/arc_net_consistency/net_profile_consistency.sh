#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='ARC-PROF-C'
STATE=$(cat "$MODPATH/data/current_state.txt" 2>/dev/null||echo BROWSING)
sh "$MODPATH/smart_net/smart_profile_selector.sh" 2>/dev/null
arc_log_info "$TAG" "Profile consistency: state=$STATE"