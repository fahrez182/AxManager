#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='ARC-TCP-C'
FO=$(sysctl -n net.ipv4.tcp_fastopen 2>/dev/null||echo 0)
[ "$FO" != '3' ] && arc_exec "sysctl -w net.ipv4.tcp_fastopen=3" 2>/dev/null
KA=$(sysctl -n net.ipv4.tcp_keepalive_time 2>/dev/null||echo 7200)
[ "$KA" -gt 120 ] 2>/dev/null && arc_exec "sysctl -w net.ipv4.tcp_keepalive_time=60" 2>/dev/null
arc_log_info "$TAG" 'TCP consistency: done.'