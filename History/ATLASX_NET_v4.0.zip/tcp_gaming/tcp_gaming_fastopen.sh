#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='TCP-GAME-FO'
arc_exec 'sysctl -w net.ipv4.tcp_fastopen=3' 2>/dev/null
arc_exec 'sysctl -w net.ipv4.tcp_fastopen_key=0x$(head -c4 /dev/urandom|xxd -p|head -c8) 2>/dev/null' 2>/dev/null
arc_log_info "$TAG" 'TCP FastOpen: ativado.'