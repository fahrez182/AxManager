#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='TCP-GAME-PORT'
arc_exec "sysctl -w net.ipv4.ip_local_port_range='10000 65535'" 2>/dev/null
arc_exec 'sysctl -w net.ipv4.tcp_tw_reuse=1' 2>/dev/null
arc_log_info "$TAG" 'Gaming ports: otimizados.'