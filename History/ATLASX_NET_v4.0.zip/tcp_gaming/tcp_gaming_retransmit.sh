#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='TCP-GAME-RTX'
arc_exec 'sysctl -w net.ipv4.tcp_syn_retries=2' 2>/dev/null
arc_exec 'sysctl -w net.ipv4.tcp_retries1=2' 2>/dev/null
arc_exec 'sysctl -w net.ipv4.tcp_retries2=5' 2>/dev/null
arc_log_info "$TAG" 'Gaming retransmit: agressivo.'