#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='TCPG-ALL'
arc_log_info "$TAG" '=== TCP Gaming: ALL ==='
for s in tcp_gaming_low_latency tcp_gaming_buffers tcp_gaming_keepalive tcp_gaming_fastopen tcp_gaming_retransmit tcp_gaming_port_optimizer tcp_gaming_socket_prio tcp_gaming_no_delay; do
    sh "$MODPATH/tcp_gaming/${s}.sh" 2>/dev/null; sleep 1
done
arc_log_info "$TAG" '=== TCP Gaming: DONE ==='