#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='TCP-GAME-BUF'
arc_exec 'sysctl -w net.ipv4.tcp_rmem="4096 87380 8388608"' 2>/dev/null
arc_exec 'sysctl -w net.ipv4.tcp_wmem="4096 65536 8388608"' 2>/dev/null
arc_exec 'sysctl -w net.core.netdev_max_backlog=3000' 2>/dev/null
arc_log_info "$TAG" 'Gaming TCP buffers: done.'