#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='TCP-GAME-ND'
arc_exec "setprop net.tcp.default_init_rwnd 60" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_no_metrics_save=1" 2>/dev/null
arc_log_info "$TAG" 'TCP NoDelay + no metrics save: done.'