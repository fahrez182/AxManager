#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='MODOPT-DATA'
find "$MODPATH/data" -name '*.tmp' -delete 2>/dev/null
arc_log_info "$TAG" 'Data tmp files: cleaned.'