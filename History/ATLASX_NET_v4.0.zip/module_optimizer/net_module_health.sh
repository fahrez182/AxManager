#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='MODOPT-HEALTH'
arc_log_info "$TAG" 'Module health check...'
for d in core runtime tcp dns wifi mobile gaming_ping qos streaming; do
    [ -d "$MODPATH/$d" ] && arc_log_info "$TAG" "OK: $d" || arc_log_warn "$TAG" "MISSING: $d"
done