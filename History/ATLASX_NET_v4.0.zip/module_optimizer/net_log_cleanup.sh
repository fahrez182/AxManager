#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='MODOPT-LOG'
for LOG in "$MODPATH/logs"/*.log; do
    [ -f "$LOG" ] || continue
    SIZE=$(wc -c < "$LOG" 2>/dev/null || echo 0)
    [ "$SIZE" -gt 2097152 ] && { tail -500 "$LOG" > "${LOG}.tmp" 2>/dev/null && mv "${LOG}.tmp" "$LOG" 2>/dev/null; arc_log_info "$TAG" "Rotated: $LOG"; }
done