#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='MODOPT-ALL'
arc_log_info "$TAG" '=== Module Optimizer: ALL ==='
for s in net_module_health net_log_cleanup net_lock_cleanup net_data_cleanup net_pid_cleanup; do
    sh "$MODPATH/module_optimizer/${s}.sh" 2>/dev/null; sleep 1
done
arc_log_info "$TAG" '=== Module Optimizer: DONE ==='