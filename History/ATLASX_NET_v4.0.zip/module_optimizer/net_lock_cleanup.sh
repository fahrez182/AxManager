#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='MODOPT-LOCK'
. "$MODPATH/runtime/resource_lock.sh"
arc_lock_release_stale
arc_log_info "$TAG" 'Stale locks: cleared.'