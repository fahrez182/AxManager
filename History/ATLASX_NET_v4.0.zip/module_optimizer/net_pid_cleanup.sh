#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='MODOPT-PID'
for PID_FILE in "$MODPATH/pids"/*.pid; do
    [ -f "$PID_FILE" ] || continue
    PID=$(cat "$PID_FILE" 2>/dev/null)
    [ -n "$PID" ] && kill -0 "$PID" 2>/dev/null || rm -f "$PID_FILE"
done
arc_log_info "$TAG" 'PID files: cleaned.'