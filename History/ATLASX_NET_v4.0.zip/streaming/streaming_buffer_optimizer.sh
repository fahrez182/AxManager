#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='STR-BUF'
arc_exec "sysctl -w net.ipv4.tcp_rmem='4096 131072 67108864'" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_wmem='4096 65536 33554432'" 2>/dev/null
arc_exec "sysctl -w net.core.rmem_max=67108864" 2>/dev/null
arc_exec "sysctl -w net.core.wmem_max=33554432" 2>/dev/null
arc_log_info "$TAG" 'Streaming Buffers: 64MB rx / 32MB tx.'