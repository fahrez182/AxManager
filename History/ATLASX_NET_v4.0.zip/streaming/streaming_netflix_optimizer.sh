#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='STR-NFLX'
arc_exec "settings put global netflix_buffer_enabled 1" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_window_scaling=1" 2>/dev/null
arc_log_info "$TAG" 'Netflix optimizer: window scaling + buffers.'