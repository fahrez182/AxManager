#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='STR-SPOT'
arc_exec "settings put global music_cache_size 256" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_rmem='4096 65536 8388608'" 2>/dev/null
arc_log_info "$TAG" 'Spotify optimizer: cache 256MB.'