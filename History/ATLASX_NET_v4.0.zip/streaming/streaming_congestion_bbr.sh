#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='STR-BBR'
AVAIL=$(cat /proc/sys/net/ipv4/tcp_available_congestion_control 2>/dev/null||echo cubic)
echo "$AVAIL" | grep -q bbr && {
    arc_exec "sysctl -w net.ipv4.tcp_congestion_control=bbr" 2>/dev/null
    arc_exec "sysctl -w net.core.default_qdisc=fq" 2>/dev/null
    arc_log_info "$TAG" 'Streaming: BBR+fq ativo.'
} || arc_log_info "$TAG" 'Streaming: BBR indisponível, usando cubic.'