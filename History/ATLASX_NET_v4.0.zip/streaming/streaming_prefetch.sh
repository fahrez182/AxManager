#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='STR-PRE'
arc_log_info "$TAG" 'Streaming prefetch: CDN warmup...'
for cdn in cdn.netflix.com s.youtube.com cdnjs.cloudflare.com; do
    nslookup "$cdn" 1.1.1.1 >/dev/null 2>&1 &
done
wait; arc_log_info "$TAG" 'Streaming CDN prefetch: done.'