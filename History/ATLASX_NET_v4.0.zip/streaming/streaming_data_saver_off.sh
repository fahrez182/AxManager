#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='STR-DATASAVE'
arc_exec "settings put global data_saver 0" 2>/dev/null
arc_exec "settings put global video_quality_high 1" 2>/dev/null
arc_log_info "$TAG" 'Streaming: data saver OFF, qualidade alta.'