#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='STR-LIVE'
arc_exec "sysctl -w net.ipv4.tcp_low_latency=0" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_autocorking=1" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_window_scaling=1" 2>/dev/null
arc_log_info "$TAG" 'Live streaming: throughput mode.'