#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='STR-CORE'
arc_exec "sysctl -w net.ipv4.tcp_slow_start_after_idle=0" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_rmem='4096 131072 33554432'" 2>/dev/null
arc_exec "sysctl -w net.core.rmem_max=33554432" 2>/dev/null
arc_exec "settings put global video_streaming_wifi_only 0" 2>/dev/null
arc_exec "settings put global video_quality_auto 1" 2>/dev/null
arc_log_info "$TAG" 'Streaming Core: buffers máximos, idle slow-start off.'