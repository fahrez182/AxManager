#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='STR-ALL'
arc_log_info "$TAG" '=== Streaming Suite: ALL ==='
for s in streaming_core_optimizer streaming_buffer_optimizer streaming_congestion_bbr streaming_youtube_optimizer streaming_prefetch streaming_qos streaming_data_saver_off; do
    sh "$MODPATH/streaming/${s}.sh" 2>/dev/null; sleep 1
done
arc_log_info "$TAG" '=== Streaming Suite: DONE ==='