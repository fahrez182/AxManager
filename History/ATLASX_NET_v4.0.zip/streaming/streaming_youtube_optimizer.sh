#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='STR-YT'
arc_exec "settings put global youtube_buffer_size 32" 2>/dev/null
arc_exec "settings put global video_prefetch_enabled 1" 2>/dev/null
arc_exec "setprop net.youtube.buffer_scale 2" 2>/dev/null
arc_log_info "$TAG" 'YouTube optimizer: buffer x2, prefetch on.'