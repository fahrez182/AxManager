#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='BG-DATA'
STATE=$(cat "$MODPATH/data/current_state.txt" 2>/dev/null||echo BROWSING)
[ "$STATE" = "GAMING" ] || [ "$STATE" = "VOIP" ] && {
    arc_log_info "$TAG" 'Restringindo dados BG: GAMING/VOIP'
    arc_exec "settings put global background_data 0" 2>/dev/null
} || {
    arc_exec "settings put global background_data 1" 2>/dev/null
    arc_log_info "$TAG" 'BG data: liberado.'
}