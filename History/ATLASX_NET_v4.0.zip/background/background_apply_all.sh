#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='BG-ALL'
arc_log_info "$TAG" '=== Background Control: ALL ==='
for s in bg_data_manager bg_hog_killer bg_sync_optimizer bg_doze_optimizer bg_app_standby; do
    sh "$MODPATH/background/${s}.sh" 2>/dev/null; sleep 1
done
arc_log_info "$TAG" '=== Background Control: DONE ==='