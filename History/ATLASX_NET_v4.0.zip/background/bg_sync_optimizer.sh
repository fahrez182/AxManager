#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='BG-SYNC'
STATE=$(cat "$MODPATH/data/current_state.txt" 2>/dev/null||echo BROWSING)
case "$STATE" in
    GAMING|VOIP)
        arc_exec "settings put global sync_disabled_on_low_storage 1" 2>/dev/null
        arc_exec "content call --uri content://com.google.settings/partner --method set --arg sync --extra value:0" 2>/dev/null ;;
    SCREEN_OFF|CHARGING)
        arc_exec "am broadcast -a com.google.android.gms.gcm.ACTION_TRIGGER_TASK" 2>/dev/null ;;
esac
arc_log_info "$TAG" "BG Sync: estado=$STATE"
