#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='BG-METERED'
NET_TYPE=$(cat "$MODPATH/data/net_type.txt" 2>/dev/null||echo UNKNOWN)
{ [ "$NET_TYPE" = "4G" ] || [ "$NET_TYPE" = "5G" ]; } && {
    arc_exec "settings put global restrict_background 1" 2>/dev/null
    arc_log_info "$TAG" "BG metered restricted: $NET_TYPE"
}