#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='BG-DOZE'
STATE=$(cat "$MODPATH/data/current_state.txt" 2>/dev/null||echo BROWSING)
[ "$STATE" = "SCREEN_OFF" ] && {
    arc_exec "dumpsys deviceidle force-idle" 2>/dev/null
    arc_log_info "$TAG" 'Doze forçado: SCREEN_OFF.'
} || arc_log_info "$TAG" "Doze: aguardando (estado=$STATE)"
