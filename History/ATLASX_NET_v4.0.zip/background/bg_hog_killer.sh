#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='BG-HOG'
STATE=$(cat "$MODPATH/data/current_state.txt" 2>/dev/null||echo BROWSING)
[ "$STATE" = "GAMING" ] || [ "$STATE" = "VOIP" ] || exit 0
HOG_APPS="com.facebook.katana com.zhiliaoapp.musically com.instagram.android com.spotify.music"
for pkg in $HOG_APPS; do
    arc_exec "am set-inactive $pkg true" 2>/dev/null
    arc_log_info "$TAG" "BG throttled: $pkg"
done