#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='BG-POLICY'
arc_exec "settings put global background_data 1" 2>/dev/null
arc_exec "settings put global data_usage_network_type 1" 2>/dev/null
arc_log_info "$TAG" 'BG Network Policy: liberado (non-gaming).'