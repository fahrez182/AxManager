#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='BG-STANDBY'
arc_exec "am idle-maintenance" 2>/dev/null
arc_log_info "$TAG" 'App standby: idle-maintenance rodado.'