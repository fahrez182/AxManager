#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='BG-WAKELOCK'
STATE=$(cat "$MODPATH/data/current_state.txt" 2>/dev/null||echo BROWSING)
[ "$STATE" = "GAMING" ] || [ "$STATE" = "VOIP" ] && {
    arc_exec "settings put global net_wakelock_stats_enabled 0" 2>/dev/null
}
arc_log_info "$TAG" "Wakelock Guardian: estado=$STATE"
