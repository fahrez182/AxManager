#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='BG-PREFETCH'
STATE=$(cat "$MODPATH/data/current_state.txt" 2>/dev/null||echo BROWSING)
{ [ "$STATE" = "CHARGING" ] || [ "$STATE" = "SCREEN_OFF" ]; } && {
    sh "$MODPATH/dns/dns_prefetch.sh" 2>/dev/null
    sh "$MODPATH/streaming/streaming_prefetch.sh" 2>/dev/null
    arc_log_info "$TAG" 'BG Prefetch: DNS + CDN rodado.'
}