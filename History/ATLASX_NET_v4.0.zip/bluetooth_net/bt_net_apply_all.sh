#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='BTNET-ALL'
arc_log_info "$TAG" '=== BT NET Suite: ALL ==='
for s in bt_net_core bt_scan_optimizer bt_power_optimizer bt_audio_net; do sh "$MODPATH/bluetooth_net/${s}.sh" 2>/dev/null; sleep 1; done
arc_log_info "$TAG" '=== BT NET Suite: DONE ==='