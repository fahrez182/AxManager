#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='BT-AUD'
arc_exec "settings put global bluetooth_a2dp_buffer_size 2048" 2>/dev/null
arc_exec "sysctl -w net.core.rmem_default=262144" 2>/dev/null
arc_log_info "$TAG" 'BT Audio NET: buffer 2048.'