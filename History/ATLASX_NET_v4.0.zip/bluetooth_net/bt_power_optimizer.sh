#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='BT-PWR'
arc_exec "setprop bluetooth.power.optimize 1" 2>/dev/null
arc_exec "settings put global bluetooth_sleep_policy 2" 2>/dev/null
arc_log_info "$TAG" 'BT Power: optimized.'