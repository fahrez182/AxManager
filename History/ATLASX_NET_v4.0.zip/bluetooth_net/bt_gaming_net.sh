#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='BT-GAME'
arc_exec "setprop bluetooth.gaming.latency 1" 2>/dev/null
arc_exec "settings put global ble_scan_interval 4096" 2>/dev/null
arc_log_info "$TAG" 'BT Gaming NET: low latency mode.'