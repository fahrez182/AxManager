#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='BT-SCAN'
arc_exec "settings put global ble_scan_always_enabled 0" 2>/dev/null
arc_exec "setprop bluetooth.scan.interval 300" 2>/dev/null
arc_log_info "$TAG" 'BT Scan: reduced.'