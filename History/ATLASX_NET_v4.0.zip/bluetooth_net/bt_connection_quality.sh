#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='BT-QUAL'
arc_exec "setprop bluetooth.link_quality_report 1" 2>/dev/null
arc_log_info "$TAG" 'BT Connection Quality: monitoring on.'