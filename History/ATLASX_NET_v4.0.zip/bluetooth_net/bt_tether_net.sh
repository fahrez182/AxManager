#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='BT-TETH'
arc_exec "settings put global bluetooth_tether_enabled 1" 2>/dev/null
arc_exec "sysctl -w net.ipv4.ip_forward=1" 2>/dev/null
arc_log_info "$TAG" 'BT Tether NET: enabled.'