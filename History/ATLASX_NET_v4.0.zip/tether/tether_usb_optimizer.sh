#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='TETH-USB'
arc_exec "setprop persist.tethering.usb 1" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_fastopen=3" 2>/dev/null
arc_log_info "$TAG" 'USB Tether: otimizado.'