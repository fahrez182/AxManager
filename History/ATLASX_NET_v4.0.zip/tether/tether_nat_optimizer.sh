#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='TETH-NAT'
arc_exec "sysctl -w net.netfilter.nf_conntrack_max=32768" 2>/dev/null
arc_exec "sysctl -w net.netfilter.nf_conntrack_tcp_timeout_established=3600" 2>/dev/null
arc_log_info "$TAG" 'Tether NAT: conntrack 32768.'