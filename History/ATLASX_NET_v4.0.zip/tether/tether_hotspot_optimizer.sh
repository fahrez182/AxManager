#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='TETH-HS'
arc_exec "settings put global tether_dun_required 0" 2>/dev/null
arc_exec "settings put global wifi_tether_settings_enabled 1" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_fastopen=3" 2>/dev/null
arc_log_info "$TAG" 'Hotspot: tether + fastopen.'