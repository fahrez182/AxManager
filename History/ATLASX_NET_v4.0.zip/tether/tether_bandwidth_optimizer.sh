#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='TETH-BW'
arc_exec "sysctl -w net.core.netdev_max_backlog=5000" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_congestion_control=cubic" 2>/dev/null
arc_log_info "$TAG" 'Tether BW: cubic + backlog 5000.'