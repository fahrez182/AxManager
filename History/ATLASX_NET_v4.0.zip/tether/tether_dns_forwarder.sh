#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='TETH-DNS'
arc_exec "setprop net.tethering.dns1 1.1.1.1" 2>/dev/null
arc_exec "setprop net.tethering.dns2 8.8.8.8" 2>/dev/null
arc_log_info "$TAG" 'Tether DNS: CF+Google forwarded.'