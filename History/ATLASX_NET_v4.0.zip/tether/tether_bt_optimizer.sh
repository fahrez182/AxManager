#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='TETH-BT'
arc_exec "settings put global bluetooth_tether_enabled 1" 2>/dev/null
arc_log_info "$TAG" 'BT Tether: habilitado.'