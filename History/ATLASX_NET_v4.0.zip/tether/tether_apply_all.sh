#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='TETH-ALL'
arc_log_info "$TAG" '=== Tether Suite: ALL ==='
for s in tether_core_optimizer tether_hotspot_optimizer tether_dns_forwarder tether_bandwidth_optimizer tether_nat_optimizer; do sh "$MODPATH/tether/${s}.sh" 2>/dev/null; sleep 1; done
arc_log_info "$TAG" '=== Tether Suite: DONE ==='