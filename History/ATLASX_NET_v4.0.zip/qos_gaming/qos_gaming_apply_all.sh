#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='QGAME-ALL'
arc_log_info "$TAG" '=== QoS Gaming: ALL ==='
for s in qos_game_udp_first qos_game_fq_codel qos_game_ecn qos_game_burst qos_game_ping_boost; do sh "$MODPATH/qos_gaming/${s}.sh" 2>/dev/null; sleep 1; done
arc_log_info "$TAG" '=== QoS Gaming: DONE ==='