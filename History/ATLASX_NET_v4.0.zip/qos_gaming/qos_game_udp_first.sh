#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='QGAME-UDP'
IFACE=$(cat "$MODPATH/data/active_iface.txt" 2>/dev/null||echo '')
[ -n "$IFACE" ] && tc filter add dev "$IFACE" parent 1: protocol ip u32 match ip protocol 17 0xff flowid 1:1 2>/dev/null
arc_log_info "$TAG" 'QoS Gaming UDP first: done.'