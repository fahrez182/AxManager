#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='QGAME-BURST'
arc_exec "sysctl -w net.core.netdev_budget=600" 2>/dev/null
arc_exec "sysctl -w net.core.dev_weight=64" 2>/dev/null
arc_log_info "$TAG" 'QoS Gaming burst: máximo.'