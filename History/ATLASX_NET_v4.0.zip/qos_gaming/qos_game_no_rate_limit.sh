#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='QGAME-RL'
IFACE=$(cat "$MODPATH/data/active_iface.txt" 2>/dev/null||echo '')
[ -n "$IFACE" ] && tc qdisc del dev "$IFACE" root 2>/dev/null
arc_log_info "$TAG" 'QoS Gaming: rate limit removido.'