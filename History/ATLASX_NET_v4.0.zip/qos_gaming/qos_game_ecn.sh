#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='QGAME-ECN'
arc_exec "sysctl -w net.ipv4.tcp_ecn=1" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_ecn_fallback=1" 2>/dev/null
arc_log_info "$TAG" 'QoS ECN: gaming ativo.'