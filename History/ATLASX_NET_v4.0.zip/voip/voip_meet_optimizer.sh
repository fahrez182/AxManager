#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='VOIP-MEET'
arc_exec "am set-inactive com.google.android.apps.meetings false" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_rmem='4096 65536 8388608'" 2>/dev/null
arc_log_info "$TAG" 'VoIP Google Meet: buffers + BG.'