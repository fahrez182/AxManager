#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='VOIP-UDP'
arc_exec "sysctl -w net.ipv4.udp_rmem_min=32768" 2>/dev/null
arc_exec "sysctl -w net.ipv4.udp_wmem_min=32768" 2>/dev/null
arc_exec "sysctl -w net.core.rmem_default=524288" 2>/dev/null
arc_log_info "$TAG" 'VoIP UDP: buffers reforçados.'