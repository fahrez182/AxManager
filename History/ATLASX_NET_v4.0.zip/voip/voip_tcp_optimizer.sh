#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='VOIP-TCP'
arc_exec "sysctl -w net.ipv4.tcp_low_latency=1" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_keepalive_time=15" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_keepalive_intvl=5" 2>/dev/null
arc_exec "sysctl -w net.core.busy_read=100" 2>/dev/null
arc_exec "sysctl -w net.core.busy_poll=100" 2>/dev/null
arc_log_info "$TAG" 'VoIP TCP: baixíssima latência.'