#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='VOIP-KEEP'
arc_exec "sysctl -w net.ipv4.tcp_keepalive_time=15" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_keepalive_intvl=3" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_keepalive_probes=10" 2>/dev/null
arc_log_info "$TAG" 'VoIP Connection Keeper: 15s/3s/10 probes.'