#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='VOIP-ALL'
arc_log_info "$TAG" '=== VoIP Suite: ALL ==='
for s in voip_core_optimizer voip_tcp_optimizer voip_udp_optimizer voip_qos voip_whatsapp_optimizer voip_connection_keeper; do
    sh "$MODPATH/voip/${s}.sh" 2>/dev/null; sleep 1
done
arc_log_info "$TAG" '=== VoIP Suite: DONE ==='