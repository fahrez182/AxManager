#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='VOIP-TG'
arc_exec "am set-inactive org.telegram.messenger false" 2>/dev/null
arc_exec "sysctl -w net.ipv4.tcp_keepalive_time=20" 2>/dev/null
arc_log_info "$TAG" 'VoIP Telegram: otimizado.'