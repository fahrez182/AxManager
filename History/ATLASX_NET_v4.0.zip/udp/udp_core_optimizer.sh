#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='UDP-CORE'
arc_exec "sysctl -w net.core.rmem_max=16777216" 2>/dev/null
arc_exec "sysctl -w net.core.wmem_max=16777216" 2>/dev/null
arc_exec "sysctl -w net.ipv4.udp_rmem_min=8192" 2>/dev/null
arc_exec "sysctl -w net.ipv4.udp_wmem_min=8192" 2>/dev/null
arc_exec "sysctl -w net.core.netdev_max_backlog=5000" 2>/dev/null
arc_log_info "$TAG" 'UDP Core: done.'