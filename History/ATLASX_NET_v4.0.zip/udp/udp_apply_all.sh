#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='UDP-ALL'
arc_log_info "$TAG" '=== UDP Suite: ALL ==='
for s in udp_core_optimizer udp_buffer_optimizer udp_gaming_optimizer udp_latency_reducer udp_recv_optimizer udp_send_optimizer; do sh "$MODPATH/udp/${s}.sh" 2>/dev/null; sleep 1; done
arc_log_info "$TAG" '=== UDP Suite: DONE ==='