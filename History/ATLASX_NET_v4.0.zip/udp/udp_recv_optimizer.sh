#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='UDP-RECV'
arc_exec "sysctl -w net.core.rmem_default=262144" 2>/dev/null
arc_exec "sysctl -w net.core.netdev_budget_usecs=8000" 2>/dev/null
arc_log_info "$TAG" 'UDP recv: done.'