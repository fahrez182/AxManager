#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='UDP-BUF'
TIER=$(cat "$MODPATH/data/net_tier.txt" 2>/dev/null||echo MED)
case "$TIER" in HIGH) BUF=8388608;; MED) BUF=4194304;; *) BUF=2097152;; esac
arc_exec "sysctl -w net.core.rmem_max=$BUF" 2>/dev/null
arc_exec "sysctl -w net.core.wmem_max=$BUF" 2>/dev/null
arc_log_info "$TAG" "UDP buffers: TIER=$TIER BUF=${BUF}b"