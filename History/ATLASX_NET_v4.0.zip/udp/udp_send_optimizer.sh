#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='UDP-SEND'
arc_exec "sysctl -w net.core.wmem_default=262144" 2>/dev/null
arc_exec "sysctl -w net.ipv4.udp_wmem_min=8192" 2>/dev/null
arc_log_info "$TAG" 'UDP send: done.'