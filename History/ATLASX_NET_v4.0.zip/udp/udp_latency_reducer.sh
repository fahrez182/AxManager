#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='UDP-LAT'
arc_exec "sysctl -w net.core.busy_read=50" 2>/dev/null
arc_exec "sysctl -w net.core.busy_poll=50" 2>/dev/null
arc_log_info "$TAG" 'UDP Busy-poll latency: 50us.'