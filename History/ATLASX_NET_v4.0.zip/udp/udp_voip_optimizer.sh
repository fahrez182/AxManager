#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='UDP-VOIP'
arc_exec "sysctl -w net.ipv4.udp_rmem_min=4096" 2>/dev/null
arc_exec "sysctl -w net.core.netdev_budget=400" 2>/dev/null
arc_log_info "$TAG" 'UDP VoIP: done.'