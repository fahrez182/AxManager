#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='UDP-FLOOD'
arc_exec "sysctl -w net.ipv4.udp_rmem_min=4096" 2>/dev/null
arc_exec "sysctl -w net.core.netdev_max_backlog=1000" 2>/dev/null
arc_log_info "$TAG" 'UDP Flood protection: done.'