#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='CONF-RST'
sh "$MODPATH/stability/net_persistence_guard.sh" 2>/dev/null
arc_log_info "$TAG" 'Net reset guard: reapplied.'