#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='CONF-DNS'
. "$MODPATH/runtime/resource_lock.sh"
OWNER=$(arc_lock_owner 'dns_config')
arc_log_info "$TAG" "DNS lock owner: ${OWNER:-none}"