#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='CONF-WIFI'
. "$MODPATH/runtime/resource_lock.sh"
OWNER=$(arc_lock_owner 'wifi_config')
arc_log_info "$TAG" "WiFi lock owner: ${OWNER:-none}"