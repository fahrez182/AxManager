#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='CONF-TCP'
. "$MODPATH/runtime/resource_lock.sh"
OWNER=$(arc_lock_owner 'tcp_config')
arc_log_info "$TAG" "TCP lock owner: ${OWNER:-none}"