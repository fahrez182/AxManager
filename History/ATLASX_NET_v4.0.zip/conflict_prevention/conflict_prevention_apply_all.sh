#!/system/bin/sh
MODPATH="${MODPATH:-${0%/*}/..}"; . "$MODPATH/core/compat.sh"; . "$MODPATH/core/logger.sh"
TAG='CONF-ALL'
arc_log_info "$TAG" '=== Conflict Prevention: ALL ==='
for s in net_conflict_engine dns_conflict_guard tcp_conflict_guard wifi_conflict_guard net_reset_guard; do
    sh "$MODPATH/conflict_prevention/${s}.sh" 2>/dev/null; sleep 1
done
arc_log_info "$TAG" '=== Conflict Prevention: DONE ==='