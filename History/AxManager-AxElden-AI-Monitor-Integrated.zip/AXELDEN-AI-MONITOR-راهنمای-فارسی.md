# موتور پایش زنده AxElden برای خود AxManager

این افزونه یک زیرسامانهٔ واقعی و قابل اجرا برای خواندن وضعیت دستگاه و پایش پنجرهٔ خود AxManager است؛ ماژول نمایشی یا دادهٔ ساختگی تولید نمی‌کند.

## خروجی‌های زنده

- RAM کل و RAM در دسترس از `/proc/meminfo`
- بار CPU سیستم از اختلاف نمونه‌های متوالی `/proc/stat` (نمونهٔ اول فقط خط مبناست)
- زمان روشن‌بودن دستگاه
- دمای بهترین thermal zone قابل‌خواندن، با توجه به تفاوت سازندگان
- درصد باتری از Android Battery API
- نرخ نوسازی نمایشگر از Android Display API
- نرخ فریم پنجرهٔ خود AxManager، فقط پس از فراخوانی `attachOwnWindow(window)`
- پروفایل تطبیقی `BALANCED` یا `PROTECT` با هیسترزیس برای جلوگیری از نوسان
- خروجی JSON با `result.toJson()`

## راه‌اندازی در Activity خود AxManager

```kotlin
private lateinit var axMonitor: AxEldenMonitor

override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    axMonitor = AxEldenMonitor(this)
    axMonitor.attachOwnWindow(window)
    axMonitor.start { result ->
        val json = result.toJson()
        // json را به صفحهٔ Diagnostics خود AxManager متصل کن.
    }
}

override fun onDestroy() {
    axMonitor.close()
    super.onDestroy()
}
```

## سیاست عملکرد

موتور در شرایط فشار حرارتی، حافظهٔ کم یا باتری پایین، فقط نرخ نمونه‌برداری و بار کاری پایشگر خود AxManager را کاهش می‌دهد. این نسخه فرکانس CPU/GPU را قفل نمی‌کند، فایل‌های کرنل را تغییر نمی‌دهد و وارد فرایند برنامهٔ دیگر نمی‌شود.

## محدودیت مهم

عدد FPS فقط متعلق به پنجرهٔ AxManager است. نرخ Hz گزارش‌شده، حالت نمایشگر است و تضمین نمی‌کند بازی یا برنامهٔ دیگری با همان نرخ فریم رندر شود. هیچ FPS ثابتی روی همهٔ دستگاه‌ها قابل تضمین نیست.
