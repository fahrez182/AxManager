cmake_minimum_required(VERSION 3.22.1)

project(ax_turbo)

# Existing project libraries (kept intact).
add_library(emu_speed SHARED EmuTurbo.cpp)
add_library(ram_boost SHARED RamTurbo.cpp)
add_library(cpu_power SHARED CpuTurbo.cpp)
add_library(io_turbo SHARED IoTurbo.cpp)
add_library(net_turbo SHARED NetTurbo.cpp)
add_library(gfx_turbo SHARED GfxTurbo.cpp)

# Read-only diagnostics for AxManager itself. No game-process attachment,
# memory patching, frequency writes, or anti-cheat interaction.
add_library(axelden_monitor SHARED axelden_monitor.cpp)

foreach(target emu_speed ram_boost cpu_power io_turbo net_turbo gfx_turbo axelden_monitor)
    target_link_libraries(${target} log android)
endforeach()
