package frb.axeron.manager.core

import android.content.Context
import android.content.IntentFilter
import android.hardware.display.DisplayManager
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import android.view.Display
import android.view.Window
import android.view.WindowManager
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit

/**
 * Real, read-only device telemetry plus a conservative adaptive policy for AxManager's own work.
 * It deliberately does not attach to, inspect, or modify another app/game process.
 */
class AxEldenMonitor(private val context: Context) {
    companion object {
        init { System.loadLibrary("axelden_monitor") }
    }

    private external fun nativeSample(): String
    private val executor = Executors.newSingleThreadScheduledExecutor { r ->
        Thread(r, "AxElden-Monitor").apply { isDaemon = true }
    }
    private val mainHandler = Handler(Looper.getMainLooper())
    @Volatile private var task: ScheduledFuture<*>? = null
    @Volatile private var frameCount = 0L
    @Volatile private var lastFrameWindow: Window? = null
    @Volatile private var frameListener: Window.OnFrameMetricsAvailableListener? = null
    @Volatile private var lastFrameTimeNs = 0L
    @Volatile private var measuredAppFps = -1.0
    private var currentProfile = "BALANCED"
    private var severeSamples = 0
    private var coolSamples = 0

    data class Result(
        val timestampMs: Long,
        val memoryTotalMb: Long,
        val memoryAvailableMb: Long,
        val cpuBusyPercent: Double,
        val thermalC: Double?,
        val batteryPercent: Int?,
        val refreshRateHz: Float?,
        val appFps: Double?,
        val profile: String,
        val recommendedIntervalMs: Long,
        val actions: List<String>,
        val rawNative: String
    ) {
        fun toJson(): String = JSONObject().apply {
            put("timestamp_ms", timestampMs); put("memory_total_mb", memoryTotalMb)
            put("memory_available_mb", memoryAvailableMb); put("cpu_busy_percent", cpuBusyPercent)
            put("thermal_c", thermalC ?: JSONObject.NULL); put("battery_percent", batteryPercent ?: JSONObject.NULL)
            put("refresh_rate_hz", refreshRateHz ?: JSONObject.NULL); put("axmanager_app_fps", appFps ?: JSONObject.NULL)
            put("profile", profile); put("recommended_interval_ms", recommendedIntervalMs)
            put("actions", org.json.JSONArray(actions)); put("raw_native", JSONObject(rawNative))
        }.toString()
    }

    /** Attach only to AxManager's own Window to measure its rendered frames. */
    fun attachOwnWindow(window: Window) {
        if (Build.VERSION.SDK_INT < 24) return
        detachOwnWindow()
        lastFrameWindow = window
        val listener = Window.OnFrameMetricsAvailableListener { _, _, _ ->
            val now = System.nanoTime()
            synchronized(this) {
                if (lastFrameTimeNs != 0L && now > lastFrameTimeNs) {
                    val instantaneous = 1_000_000_000.0 / (now - lastFrameTimeNs)
                    measuredAppFps = if (measuredAppFps < 0) instantaneous else measuredAppFps * 0.8 + instantaneous * 0.2
                }
                lastFrameTimeNs = now
                frameCount++
            }
        }
        frameListener = listener
        window.addOnFrameMetricsAvailableListener(listener, mainHandler)
    }

    fun detachOwnWindow() {
        val w = lastFrameWindow
        val listener = frameListener
        if (Build.VERSION.SDK_INT >= 24 && w != null && listener != null) {
            try { w.removeOnFrameMetricsAvailableListener(listener) } catch (_: Throwable) { /* window may already be detached */ }
        }
        frameListener = null
        lastFrameWindow = null
        lastFrameTimeNs = 0L
        measuredAppFps = -1.0
    }

    fun sample(): Result {
        val raw = nativeSample()
        val n = JSONObject(raw)
        val batteryIntent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val battery = if (level >= 0 && scale > 0) (100 * level / scale) else null
        val power = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        val thermalStatus = if (Build.VERSION.SDK_INT >= 29) power.currentThermalStatus else 0
        val refresh = currentRefreshRate()
        val memTotal = n.optLong("mem_total_kb", -1L).coerceAtLeast(0) / 1024
        val memAvail = n.optLong("mem_available_kb", -1L).coerceAtLeast(0) / 1024
        val cpu = n.optDouble("cpu_busy_percent", -1.0)
        val thermalC = n.optLong("thermal_milli_c", -1L).takeIf { it > 0 }?.div(1000.0)
        val actions = mutableListOf<String>()

        // Hysteresis prevents rapid profile oscillation. This policy changes only AxManager's
        // own monitoring cadence; it does not force CPU/GPU clocks or alter another app.
        val hot = thermalStatus >= PowerManager.THERMAL_STATUS_SEVERE || (thermalC != null && thermalC >= 48.0)
        val memoryTight = memAvail > 0 && memTotal > 0 && memAvail * 100 / memTotal < 12
        val lowBattery = battery != null && battery <= 15
        if (hot || memoryTight || lowBattery) {
            severeSamples++
            coolSamples = 0
        } else {
            coolSamples++
            severeSamples = 0
        }
        if (severeSamples >= 2) {
            currentProfile = "PROTECT"
            actions += "Reduced AxManager sampling load due to device pressure"
        } else if (coolSamples >= 5) {
            currentProfile = "BALANCED"
            actions += "Restored normal AxManager sampling cadence"
        }
        if (cpu >= 0 && cpu > 85.0) actions += "High system CPU load observed"
        if (thermalStatus >= PowerManager.THERMAL_STATUS_CRITICAL) actions += "Critical thermal status: pause optional work"
        val interval = if (currentProfile == "PROTECT") 5000L else 1000L

        return Result(System.currentTimeMillis(), memTotal, memAvail, cpu, thermalC, battery,
            refresh, measuredAppFps.takeIf { it >= 0 }, currentProfile, interval, actions, raw)
    }

    /** Start a bounded, interruptible telemetry loop. Caller owns lifecycle and must call stop(). */
    @Synchronized fun start(onResult: (Result) -> Unit) {
        if (task?.isDone == false) return
        scheduleNext(onResult, 0L)
    }

    @Synchronized private fun scheduleNext(onResult: (Result) -> Unit, delayMs: Long) {
        if (executor.isShutdown) return
        task = executor.schedule({
            val nextDelay = try {
                val result = sample()
                mainHandler.post { onResult(result) }
                result.recommendedIntervalMs
            } catch (_: Throwable) {
                5000L // back off after a failed sample rather than spin
            }
            synchronized(this) {
                if (task?.isCancelled == false) scheduleNext(onResult, nextDelay)
            }
        }, delayMs, TimeUnit.MILLISECONDS)
    }

    @Synchronized fun stop() {
        task?.cancel(true)
        task = null
    }

    fun close() { stop(); detachOwnWindow(); executor.shutdownNow() }

    private fun currentRefreshRate(): Float? {
        return try {
            val dm = context.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
            val display = dm.getDisplay(Display.DEFAULT_DISPLAY) ?: return null
            display.refreshRate.takeIf { it > 0f }
        } catch (_: Throwable) {
            try {
                val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
                @Suppress("DEPRECATION")
                wm.defaultDisplay.refreshRate.takeIf { it > 0f }
            } catch (_: Throwable) { null }
        }
    }
}
