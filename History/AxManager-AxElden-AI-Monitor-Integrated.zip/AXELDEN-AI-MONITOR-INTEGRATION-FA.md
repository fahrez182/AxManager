# AxElden AI Monitor — safe native telemetry integration

This patch adds a real read-only native telemetry library and a Kotlin controller for AxManager itself.
It does **not** attach to Call of Duty or another app, patch another process, change game internals,
force CPU/GPU frequencies, bypass anti-cheat, or promise a fixed FPS.

## What is implemented

- `axelden_monitor.cpp`: JNI native sampling of `/proc/meminfo`, `/proc/stat`, uptime and best-effort thermal-zone data. All reads are read-only.
- `AxEldenMonitor.kt`: Android battery percentage, display refresh rate, Android thermal status, own-window frame pacing, a hysteresis-based protection policy, JSON output, and a bounded start/stop loop.
- `FrameMetrics` listener is explicitly attached only to a `Window` passed by AxManager. Its FPS value is AxManager's own window frame cadence, not a game's FPS.
- Adaptive policy changes only AxManager's own sampling cadence (1 s / 5 s). It does not write privileged kernel nodes or change hardware clocks.

## Build integration

The existing `manager/src/main/cpp/CMakeLists.txt` now builds `libaxelden_monitor.so` alongside the project's existing native libraries. The Kotlin bridge is in package `frb.axeron.manager.core`.

Example use from an AxManager Activity:

```kotlin
private lateinit var monitor: AxEldenMonitor

override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    monitor = AxEldenMonitor(this)
    monitor.attachOwnWindow(window)
    monitor.start { result ->
        val liveJson = result.toJson()
        // Send liveJson to AxManager's own diagnostics UI/log view.
    }
}

override fun onDestroy() {
    monitor.close()
    super.onDestroy()
}
```

Call `stop()` when the screen or feature is no longer active. Android may throttle background work;
this implementation intentionally does not claim an unrestricted always-on service.

## Important measurement limits

- Refresh rate is the display's reported mode, not a guarantee that a particular app renders at that rate.
- Frame rate is measured only for the AxManager window when `attachOwnWindow(window)` is called.
- Thermal-zone values vary by device; Android's thermal status is preferred for policy decisions.
- The first CPU sample establishes a baseline; CPU utilization becomes available on a subsequent sample.
- `-1` or JSON `null` means the device/API did not provide that metric.

## Validation status

The archive can be checked for ZIP integrity and source consistency. An Android NDK/Gradle build and on-device validation are separate steps; do not treat host-side checks as proof of an APK build or device performance.
